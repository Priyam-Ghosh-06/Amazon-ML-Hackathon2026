"""Label-free tables for a country without training labels (France), from "signature" pairs.

A query and an S1 on the same street (same street words) with near-identical names (token-set >= 90):
  * same house number                 -> positive signature  (a true match in most cases)
  * house number shifted by d in +-D  -> decoy signature     (rule-A decoy: 95% US / 89% India truly unmatched)
The word log-likelihood table learned from these two classes matches the truth-based table at Spearman 0.958 (US)
and 0.904 (India) on train (probe of 2026-09-27), so it can stand in for the missing labels. It finds the French
decoy words v2 could not see: holding, snc, international, distribution, participations, groupe, france.
"""
import re
import numpy as np, pandas as pd
from rapidfuzz import fuzz, process
import config as C
import features, text

D_ALL = [0] + sorted(features.D_SHIFTS) + [-d for d in sorted(features.D_SHIFTS)]
_num = re.compile(r'\d+')


def _street(acomps):
    """(street key, first number) from the first address component holding a number; ('', -1) if none."""
    keys, nums = [], []
    for a in acomps:
        k, n = '', -1
        for c in text.comps(a):
            m = _num.search(c)
            if m:
                k = ' '.join(sorted(t for t in c.split() if not t.isdigit() and len(t) > 1))
                n = int(m.group()[-9:])
                break
        keys.append(k); nums.append(n)
    return np.array(keys, dtype=object), np.array(nums, np.int64)


def signature_pairs(s1, q, qidx, sidx):
    """DataFrame(qi, si, d): for each query in qidx at most one signature S1 among sidx (same number preferred)."""
    if len(qidx) == 0 or len(sidx) == 0:
        return pd.DataFrame({'qi': [], 'si': [], 'd': []}, dtype=np.int64)
    sk, sn = _street(s1['acomp'].values[sidx])
    qk, qn = _street(q['acomp'].values[qidx])
    S = pd.DataFrame({'si': sidx, 'c': s1['country'].values[sidx], 'k': sk, 'n': sn})
    Q = pd.DataFrame({'qi': qidx, 'c': q['country'].values[qidx], 'k': qk, 'n': qn})
    S, Q = S[S.k != ''], Q[Q.k != '']
    code = pd.factorize(pd.concat([S.c + '|' + S.k, Q.c + '|' + Q.k]))[0]
    S, Q = S.assign(kc=code[:len(S)])[['si', 'kc', 'n']], Q.assign(kc=code[len(S):])[['qi', 'kc', 'n']]
    m = pd.concat([Q.assign(d=d, n=Q.n.values - d) for d in D_ALL]).merge(S, on=['kc', 'n'])
    if m.empty:
        return pd.DataFrame({'qi': [], 'si': [], 'd': []}, dtype=np.int64)
    sim = np.concatenate([process.cpdist(q['name'].values[m.qi.values[a:a + 5_000_000]].tolist(),
                                         s1['name'].values[m.si.values[a:a + 5_000_000]].tolist(),
                                         scorer=fuzz.token_set_ratio, workers=-1)
                          for a in range(0, len(m), 5_000_000)])
    m = m[sim >= 90]
    m = m.assign(o=(m.d.values != 0).astype(int)).sort_values(['qi', 'o']).drop_duplicates('qi')
    return m[['qi', 'si', 'd']].reset_index(drop=True)


def tables(s1, q, qidx, sidx, tag):
    """Label-free word table (v3 token handling) and place aliases for the queries qidx against the S1 sidx."""
    sig = signature_pairs(s1, q, qidx, sidx)
    pos = sig[sig.d == 0]
    y = (sig.d.values == 0).astype(int)
    llr = features.learn_llr(q, s1, sig.qi.values, sig.si.values, y, v3=True) if len(sig) else \
        {k: {} for k in ('name_extra', 'name_miss', 'addr_extra', 'addr_miss')}
    alias = text.learn_place_aliases(q['acomp'].values[pos.qi.values[:300_000]],
                                     s1['acomp'].values[pos.si.values[:300_000]]) if len(pos) else set()
    worst = sorted(llr['name_extra'], key=llr['name_extra'].get)[:10]
    C.log(f'  label-free tables {tag}: positive signatures={len(pos):,} decoy signatures={(sig.d != 0).sum():,} '
          f'name words={len(llr["name_extra"]):,} place aliases={len(alias):,}; most decoy-like: {worst}')
    return llr, alias


if __name__ == '__main__':
    C.SMOKE = True
    s1 = pd.DataFrame({'name': ['maison ligue', 'lycee mace', 'bar du port'], 'country': ['France'] * 3,
                       'acomp': ['19 rue alfred|nantes', '12 rue louis|nantes', '5 quai sud|lille']})
    q = pd.DataFrame({'name': ['maison ligue', 'maison ligue holding', 'lycee mace', 'bar du port'],
                      'country': ['France'] * 4,
                      'acomp': ['19 rue alfred|nantes', '22 rue alfred|nantes', '12 rue louis', '9 quai nord|lille']})
    sig = signature_pairs(s1, q, np.arange(4), np.arange(3))
    assert sig.values.tolist() == [[0, 0, 0], [1, 0, 3], [2, 1, 0]], sig        # q1: +3 shift, q3: other street
    print('ok')
