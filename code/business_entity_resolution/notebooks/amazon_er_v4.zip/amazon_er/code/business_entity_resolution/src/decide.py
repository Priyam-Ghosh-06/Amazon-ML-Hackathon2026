"""Stage F: from calibrated edge probabilities to one match set per S1.

1. Many-to-one: a record belongs to at most one S1, so each query keeps only its best edge.
2. Per S1, sort its kept edges by p and choose the prefix m maximising the EXACT expected F0.5:
     E[F | m > 0] = sum_{a,b} P(A=a) P(B=b) * 1.25 a / (0.25 (a + b) + m)
       A = true matches among the m selected edges, B = among the rest (both Poisson-binomial)
     E[F | m = 0] = P(A + B = 0)       (an S1 with no true match scores 1 for an empty prediction)
   Groups larger than KMAX_EXACT use only their top KMAX_EXACT edges (the tail has p ~ 0).
3. The rule is compared with fixed thresholds on the VALIDATION region and the better one is kept.
"""
import numpy as np
from sklearn.isotonic import IsotonicRegression
import config as C


def best_edges(qi, p):
    o = np.lexsort((-p, qi))
    first = np.r_[True, qi[o][1:] != qi[o][:-1]] if len(o) else np.zeros(0, bool)
    return o[first]


def _pb(ps):
    d = np.ones(1)
    for x in ps:
        d = np.convolve(d, [1 - x, x])
    return d


def best_prefix(pp):
    """pp sorted descending -> m (0 = select nothing) maximising exact E[F0.5]."""
    k = len(pp)
    suf = [None] * (k + 1)
    suf[k] = np.ones(1)
    for m in range(k - 1, -1, -1):
        suf[m] = np.convolve(suf[m + 1], [1 - pp[m], pp[m]])
    best_m, best_e = 0, suf[0][0]
    pre = np.ones(1)
    for m in range(1, k + 1):
        pre = np.convolve(pre, [1 - pp[m - 1], pp[m - 1]])
        a = np.arange(len(pre))[:, None]
        b = np.arange(len(suf[m]))[None, :]
        e = float((pre[:, None] * suf[m][None, :] * (1.25 * a / (0.25 * (a + b) + m))).sum())
        if e > best_e + 1e-12:
            best_m, best_e = m, e
    return best_m


def choose_expected_f(qi, si, p):
    sel = np.zeros(len(p), bool)
    b = best_edges(qi, p)
    b = b[np.lexsort((-p[b], si[b]))]                          # kept edges grouped by S1, p descending
    s = si[b]
    starts = np.flatnonzero(np.r_[True, s[1:] != s[:-1]]) if len(s) else np.zeros(0, int)
    ends = np.r_[starts[1:], len(s)]
    single = ends - starts == 1
    sel[b[starts[single]][p[b[starts[single]]] > 0.5]] = True   # one edge: E[F] = p vs 1 - p
    for a, e in zip(starts[~single], ends[~single]):
        g = b[a:e][:C.KMAX_EXACT]
        sel[g[:best_prefix(p[g])]] = True
    return sel


def choose_threshold(qi, p, tau):
    sel = np.zeros(len(p), bool)
    b = best_edges(qi, p)
    sel[b[p[b] >= tau]] = True
    return sel


def select(qi, si, p, rule):
    return choose_expected_f(qi, si, p) if rule['kind'] == 'expected_f' else choose_threshold(qi, p, rule['tau'])


def calibrate(p, y):
    rng = np.random.default_rng(C.SEED)
    k = rng.choice(len(p), min(5_000_000, len(p)), replace=False)
    return IsotonicRegression(out_of_bounds='clip', y_min=0, y_max=1).fit(p[k], y[k])


# ---------------------------------------------------------------- v3: per-country calibration + prior shift
def fit_best_iso(qi, p, y):
    """Isotonic calibration of each query's BEST edge (the only edge the decision can select). None if too few rows."""
    b = best_edges(qi, p)
    if len(b) < 50 or y[b].min() == y[b].max():
        return None, float(y[b].mean()) if len(b) else 0.5
    return calibrate(p[b], y[b]), float(y[b].mean())


def em_prior(p, pi0, iters=1000, tol=1e-9):
    """Saerens-Latinne-Decaestecker EM: the match rate pi of a set whose calibrated posteriors p were calibrated
    at rate pi0 (label shift: P(features | match) unchanged, only the mix of matches and decoys differs)."""
    p = np.clip(np.asarray(p, np.float64), 1e-6, 1 - 1e-6)
    pi = pi0
    for _ in range(iters):
        new = shift(p, pi, pi0).mean()
        if abs(new - pi) < tol:
            break
        pi = new
    return float(pi)


def shift(p, pi, pi0):
    """Posteriors re-weighted from match rate pi0 to pi (odds multiplied by (pi/(1-pi)) / (pi0/(1-pi0)))."""
    a, b = pi / pi0, (1 - pi) / (1 - pi0)
    p = np.clip(np.asarray(p, np.float64), 1e-9, 1 - 1e-9)
    return p * a / (p * a + (1 - p) * b)


def decoy_ratio(pi_test, pi0):
    """How many times more unmatched records per matched one the test set has than the calibration set."""
    return float(pi0 * (1 - pi_test) / max(pi_test * (1 - pi0), 1e-12))


def replicate_unmatched(qi, unmatched, r, seed=0):
    """Edge indices and new query ids of a copy of the edge set where every unmatched query appears r times on
    average (r > 1: extra copies; r < 1: dropped with probability 1 - r). Simulates test's decoy density on a
    labelled split, so a rule tuned on it is tuned for test conditions."""
    rng = np.random.default_rng(seed)
    qi = np.asarray(qi, np.int64)
    uq = np.unique(qi[unmatched])
    off = int(qi.max()) + 1 if len(qi) else 1
    if r < 1:
        drop = uq[rng.random(len(uq)) > r]
        keep = np.flatnonzero(~np.isin(qi, drop))
        return keep, qi[keep]
    extra = np.floor(r - 1).astype(int) + (rng.random(len(uq)) < (r - 1) % 1)
    idx, nq = [np.arange(len(qi))], [qi]
    for c in range(1, int(extra.max(initial=0)) + 1):
        e = np.flatnonzero(np.isin(qi, uq[extra >= c]))
        idx.append(e); nq.append(qi[e] + c * off)
    return np.concatenate(idx), np.concatenate(nq)


def f05_macro(sel_si, sel_ok, truth_si, s1_set):
    """Macro F0.5 over the S1 in s1_set (singletons included). sel_si: S1 of each predicted match; sel_ok: whether
    it is correct; truth_si: true S1 of every query (-1 for none)."""
    n = int(max(s1_set.max() if len(s1_set) else 0, sel_si.max() if len(sel_si) else 0,
                truth_si.max() if len(truth_si) else 0)) + 1
    tp = np.bincount(sel_si, weights=sel_ok, minlength=n)[s1_set]
    npred = np.bincount(sel_si, minlength=n)[s1_set]
    ntrue = np.bincount(truth_si[truth_si >= 0], minlength=n)[s1_set]
    den = 1.25 * tp + 0.25 * (ntrue - tp) + (npred - tp)
    f = np.where(ntrue == 0, (npred == 0).astype(float), 1.25 * tp / np.maximum(den, 1e-9))
    return float(f.mean()), f


if __name__ == '__main__':
    qi = np.array([0, 1, 2, 3, 3]); si = np.array([0, 0, 0, 0, 1]); p = np.array([.95, .9, .2, .3, .25])
    assert choose_expected_f(qi, si, p).tolist() == [True, True, False, False, False]
    assert choose_threshold(qi, p, 0.25).tolist() == [True, True, False, True, False]
    assert choose_expected_f(np.array([0]), np.array([1]), np.array([0.7])).tolist() == [True]
    assert not choose_expected_f(np.array([0, 1]), np.array([0, 0]), np.array([0.01, 0.02])).any()
    # brute-force check of the exact expectation on a 3-edge group
    import itertools
    pp = np.array([0.9, 0.6, 0.45])
    def ef(m):
        tot = 0.0
        for z in itertools.product([0, 1], repeat=3):
            pr = np.prod([x if zz else 1 - x for x, zz in zip(pp, z)])
            a, t = sum(z[:m]), sum(z)
            tot += pr * ((t == 0) if m == 0 else (1.25 * a / (0.25 * t + m)))
        return tot
    assert best_prefix(pp) == int(np.argmax([ef(m) for m in range(4)]))
    # PS worked example: P=2/3, R=1 -> 0.714; singleton predicted empty -> 1; singleton with an FP -> 0
    f, _ = f05_macro(np.array([0, 0, 0, 2]), np.array([1, 1, 0, 0]), np.array([0, 0, -1]), np.arange(3))
    assert abs(f - (0.7142857 + 1 + 0) / 3) < 1e-6
    # EM recovers a shifted match rate from calibrated posteriors alone
    rng = np.random.default_rng(0)
    z = np.r_[rng.normal(2, 1, 60000), rng.normal(-2, 1, 40000)]          # 60% matches at calibration time
    post = lambda z, pi: 1 / (1 + np.exp(-(z * 4 + np.log(pi / (1 - pi)))))  # exact posterior: LLR of N(2,1) vs N(-2,1) is 4z
    zt = np.r_[rng.normal(2, 1, 30000), rng.normal(-2, 1, 70000)]         # test: 30% matches
    pi = em_prior(post(zt, 0.6), 0.6)
    assert abs(pi - 0.3) < 0.01, pi
    assert abs(decoy_ratio(0.3, 0.6) - 3.5) < 1e-9
    assert np.allclose(shift(post(zt, 0.6), 0.3, 0.6), post(zt, 0.3))
    idx, nq = replicate_unmatched(np.array([0, 0, 1, 2]), np.array([True, True, False, False]), 3.0)
    assert idx.tolist() == [0, 1, 2, 3, 0, 1, 0, 1] and len(set(nq[4:6]) | set(nq[6:])) == 2
    idx, _ = replicate_unmatched(np.array([0, 1]), np.array([True, False]), 0.0)
    assert idx.tolist() == [1]
    print('ok')
