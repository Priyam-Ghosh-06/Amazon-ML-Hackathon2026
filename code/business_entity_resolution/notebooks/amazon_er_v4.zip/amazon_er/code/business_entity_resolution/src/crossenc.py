"""Stage D: cross-encoder (multilingual-e5-base, MIT) that reads query and S1 together, so attention can align
token against token and see WHICH edit happened (a pooled bi-encoder cannot).

Cascade: it only scores edges where stage-1 GBDT is unsure (CE_BAND), like a cheap drafter + expensive verifier.
Input is Ditto-style serialisation with one token per digit:
    [COL] name [VAL] c a l d o v a e r group llc [COL] addr [VAL] 3 0 5 1 4 2rd ave, pennsylvania
Two fold models (A trained on folds 0-1, B on folds 2-3) give out-of-fold scores on train; validation and test
use the mean of both, so train and test see a model of the same strength.
"""
import time
import numpy as np, torch, torch.nn.functional as F
from transformers import AutoModelForSequenceClassification, AutoTokenizer
import config as C, nnutil as N
from text import spaced_digits, flat


def side(df, idx):
    n, a = df['name'].values, df['acomp'].values
    return ['[COL] name [VAL] ' + spaced_digits(n[i]) + ' [COL] addr [VAL] ' + spaced_digits(flat(a[i])) for i in idx]


def load(name=None):
    tok = AutoTokenizer.from_pretrained(C.CE_MODEL)
    model = AutoModelForSequenceClassification.from_pretrained(C.CE_MODEL, num_labels=1)
    if name:
        N.load_state(model, C.WEIGHTS / name / 'best.pt')
    return tok, model.to(N.device())


def _logits(model, tok, A, B, pad_to_max=False):
    enc = tok(A, B, truncation='longest_first', max_length=C.CE_MAXLEN,
              padding='max_length' if pad_to_max else True, return_tensors='pt').to(N.device())
    with N.autocast():
        return model(**enc).logits.squeeze(-1).float()


def train(name, q, s1, tr, va):
    """tr / va: (qi, si, y) arrays. Saves WEIGHTS/<name>/best.pt under the checkpoint policy."""
    tok, model = load()
    model.train()
    rng = np.random.default_rng(C.SEED)
    qi, si, y = tr
    if len(qi) > C.CE_MAX_TRAIN:
        k = rng.choice(len(qi), C.CE_MAX_TRAIN, replace=False)
        qi, si, y = qi[k], si[k], y[k]
    opt = torch.optim.AdamW(model.parameters(), lr=C.CE_LR, weight_decay=0.01)
    B = min(C.CE_BATCH, max(2, len(qi)))
    while True:                                   # largest batch that fits at full length
        try:
            b = np.arange(B)
            F.binary_cross_entropy_with_logits(_logits(model, tok, side(q, qi[b]), side(s1, si[b]), True),
                                               torch.as_tensor(y[b], dtype=torch.float32, device=N.device())).backward()
            opt.zero_grad(set_to_none=True)
            B = max(2, B // 2) if torch.cuda.is_available() and B > 16 else B   # headroom: AdamW state is not allocated yet
            break
        except RuntimeError as e:
            if not N.is_oom(e) or B <= 4:
                raise
            opt.zero_grad(set_to_none=True); torch.cuda.empty_cache()
            B //= 2
            C.log(f'  {name}: out of memory, batch -> {B}')
    planned = max(1, len(qi) // B)
    if C.CE_MAX_STEPS:
        planned = min(planned, C.CE_MAX_STEPS)
    sched, scaler = N.linear_schedule(opt, planned), N.grad_scaler()
    ck = N.Checkpointer(name, planned)
    step = ck.resume(model, opt, sched)
    order = rng.permutation(len(qi))
    vqi, vsi, vy = va
    C.log(f'  {name}: batch={B} train edges={len(qi):,} (pos {y.mean():.3f}) val edges={len(vqi):,} '
          f'planned steps={planned} (cap {C.CE_MINUTES} min)')

    @torch.no_grad()
    def val_loss():
        model.eval()
        z = np.concatenate([_logits(model, tok, side(q, vqi[a:a + C.CE_SCORE_BATCH]),
                                    side(s1, vsi[a:a + C.CE_SCORE_BATCH])).cpu().numpy()
                            for a in range(0, len(vqi), C.CE_SCORE_BATCH)]) if len(vqi) else np.zeros(0)
        model.train()
        return float(F.binary_cross_entropy_with_logits(torch.as_tensor(z), torch.as_tensor(vy, dtype=torch.float64)))

    t0 = time.time()
    while step < planned and time.time() - t0 < C.CE_MINUTES * 60:
        a = (step * B) % max(1, len(order) - B + 1)
        b = order[a:a + B]
        try:
            loss = F.binary_cross_entropy_with_logits(_logits(model, tok, side(q, qi[b]), side(s1, si[b])),
                                                      torch.as_tensor(y[b], dtype=torch.float32, device=N.device()))
            N.train_step(loss, model, opt, sched, scaler)
        except RuntimeError as e:                      # a longer-than-usual batch can still exceed VRAM: halve, go on
            if not N.is_oom(e) or B <= 4:
                raise
            loss = None; opt.zero_grad(set_to_none=True); torch.cuda.empty_cache()
            B //= 2
            C.log(f'  {name}: out of memory at step {step}, batch -> {B}')
            continue
        step += 1
        if step % C.CE_EVAL_EVERY == 0 or step == planned:
            ck.update(model, opt, sched, step, val_loss())
    if time.time() - t0 >= C.CE_MINUTES * 60:
        C.log(f'  {name}: time cap reached at step {step}/{planned}')
    ck.finish(model)
    del model, opt
    if torch.cuda.is_available():
        torch.cuda.empty_cache()


@torch.no_grad()
def score(names, q, s1, qi, si):
    """Mean logit of the given fold models over edges (qi, si)."""
    out = np.zeros(len(qi), np.float64)
    if len(qi) == 0:
        return out.astype(np.float32)
    lens = np.fromiter((len(q['name'].values[a]) + len(q['acomp'].values[a]) for a in qi), np.int64, len(qi))
    order = np.argsort(lens, kind='stable')
    for name in names:
        tok, model = load(name)
        model.eval()
        for a in range(0, len(qi), C.CE_SCORE_BATCH):
            k = order[a:a + C.CE_SCORE_BATCH]
            out[k] += _logits(model, tok, side(q, qi[k]), side(s1, si[k])).cpu().numpy()
        del model
    return (out / len(names)).astype(np.float32)


@torch.no_grad()
def cls_embeddings(name, q, s1, qi, si):
    """[CLS] vectors of the final layer, for the optional t-SNE diagnosis."""
    tok, model = load(name)
    model.eval()
    out = []
    for a in range(0, len(qi), C.CE_SCORE_BATCH):
        enc = tok(side(q, qi[a:a + C.CE_SCORE_BATCH]), side(s1, si[a:a + C.CE_SCORE_BATCH]), truncation='longest_first',
                  max_length=C.CE_MAXLEN, padding=True, return_tensors='pt').to(N.device())
        with N.autocast():
            h = model(**enc, output_hidden_states=True).hidden_states[-1][:, 0]
        out.append(h.float().cpu().numpy())
    return np.concatenate(out) if out else np.zeros((0, 1))
