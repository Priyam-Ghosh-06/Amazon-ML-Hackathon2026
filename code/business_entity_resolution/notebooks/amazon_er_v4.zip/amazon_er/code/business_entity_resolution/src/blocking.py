"""Stage B: candidate generation inside (country, state) buckets.

Lemma (deep-dive §3.2): if the true S1 always shares the query's state, restricting the search to the state bucket
(plus S1 records that name no state) can only raise the true S1's rank. State agreement is checked per country
without labels (confident top-1 matches must agree >= 99%), so an unseen country such as France is only bucketed
when its state vocabulary is trustworthy. Queries with no (or an ambiguous) state search their whole country.

Channel 1 (here): char 3-gram TF-IDF. Name with spaces removed (catches 'wmelitedeli' vs 'wm elite deli') and
address with word-boundary 3-grams, each L2-normalised, combined as NAME_W*cos_name + (1-NAME_W)*cos_addr.
Channel 2 (bienc.py): fine-tuned multilingual bi-encoder. The two candidate lists are merged.
"""
import numpy as np, pandas as pd, scipy.sparse as sp
from sklearn.feature_extraction.text import TfidfVectorizer
from sparse_dot_topn import sp_matmul_topn
import config as C
from text import flat


def _vec(analyzer, n_docs):
    small = n_docs < 5000
    return TfidfVectorizer(analyzer=analyzer, ngram_range=(3, 3), sublinear_tf=True, lowercase=False,
                           dtype=np.float32, max_df=1.0 if small else C.CHAR_MAX_DF, min_df=1 if small else C.CHAR_MIN_DF)


class CharIndex:
    """Char TF-IDF fitted on one country's S1. Keeps that country's S1 matrix (built once, sliced per bucket)."""

    def __init__(self, s1, country):
        self.s_global = np.flatnonzero((s1['country'] == country).values)
        names, acomps = s1['name'].values[self.s_global], s1['acomp'].values[self.s_global]
        n = len(names)
        self.vn, self.va = _vec('char', n), _vec('char_wb', n)
        self.ok_n = self._fit(self.vn, [x.replace(' ', '') for x in names])
        self.ok_a = self._fit(self.va, [flat(x) for x in acomps])
        self.XS = self.transform(names, acomps)

    def rows(self, s_idx):
        """S1 matrix rows for global S1 indices (all of this country)."""
        return self.XS[np.searchsorted(self.s_global, s_idx)]

    @staticmethod
    def _fit(v, docs):
        try:
            v.fit(docs)
            return True
        except ValueError:                        # empty vocabulary (tiny or empty country)
            return False

    def transform(self, names, acomps):
        parts = []
        if self.ok_n:
            parts.append(np.sqrt(C.NAME_W) * self.vn.transform([x.replace(' ', '') for x in names]))
        if self.ok_a:
            parts.append(np.sqrt(1 - C.NAME_W) * self.va.transform([flat(x) for x in acomps]))
        if not parts:
            return sp.csr_matrix((len(names), 1), dtype=np.float32)
        return sp.hstack(parts, format='csr', dtype=np.float32)


def build_indexes(s1, countries):
    return {c: CharIndex(s1, c) for c in countries if (s1['country'] == c).any()}


def state_check(s1, q, index_by_country, truth=None):
    """Per country: share of confident country-level top-1 matches whose S1 names the same state as the query.
    Label-free, so it runs on test (France) too. With truth (train) the true agreement is logged as well."""
    ok = {}
    rng = np.random.default_rng(C.SEED)
    for c, idx in index_by_country.items():
        si = idx.s_global
        qi = np.flatnonzero(((q['country'] == c) & (q['state'] != '')).values)
        if len(qi) == 0:
            ok[c] = False
            continue
        qi = rng.choice(qi, min(len(qi), 20_000), replace=False)
        M = sp_matmul_topn(idx.transform(q['name'].values[qi], q['acomp'].values[qi]), idx.XS.T.tocsr(), top_n=1,
                           threshold=0.6, n_threads=C.N_PROC, sort=True)
        has = np.diff(M.indptr) > 0
        st_q = q['state'].values[qi[has]]
        st_s = s1['state'].values[si[M.indices]]
        known = st_s != ''
        agree = float((st_q[known] == st_s[known]).mean()) if known.sum() else 0.0
        ok[c] = bool(known.sum() >= (200 if not C.SMOKE else 5) and agree >= C.STATE_MIN_AGREE)
        msg = f'  state check {c}: confident top-1 with state={known.sum():,} agree={agree:.4f} -> buckets {"ON" if ok[c] else "OFF"}'
        if truth is not None:
            m = (truth >= 0) & (q['state'].values != '') & (q['country'].values == c)
            t = s1['state'].values[truth[m]]
            msg += f' | truth agreement (S1 has state) = {(t[t != ""] == q["state"].values[m][t != ""]).mean():.4f}'
        C.log(msg)
    return ok


def groups(s1, q, qmask, states_on):
    """[(country, state, s1_idx, q_idx)]: every query in qmask appears in exactly one group.
    State bucket = S1 of that state + S1 with no state; stateless queries search the whole country."""
    out = []
    for c in sorted(set(q['country'].values[qmask])):
        s_c = np.flatnonzero((s1['country'] == c).values)
        q_c = np.flatnonzero(qmask & (q['country'] == c).values)
        if len(s_c) == 0:
            continue
        if not states_on.get(c):
            out.append((c, '', s_c, q_c))
            continue
        s_st, q_st = s1['state'].values[s_c], q['state'].values[q_c]
        nostate = s_c[s_st == '']
        country_level = [q_c[q_st == '']]
        for st in sorted(set(q_st) - {''}):
            s_b = s_c[s_st == st]
            if len(s_b) == 0:                              # state unknown to S1: search the whole country
                country_level.append(q_c[q_st == st])
                continue
            out.append((c, st, np.concatenate([s_b, nostate]), q_c[q_st == st]))
        cl = np.concatenate(country_level)
        if len(cl):
            out.append((c, '', s_c, cl))
    return out


def char_channel(s1, q, grps, index_by_country):
    parts = []
    for c, st, s_idx, q_idx in grps:
        if len(q_idx) == 0:
            continue
        idx = index_by_country[c]
        XT = idx.rows(s_idx).T.tocsr()
        for a in range(0, len(q_idx), C.Q_CHUNK):
            b = q_idx[a:a + C.Q_CHUNK]
            M = sp_matmul_topn(idx.transform(q['name'].values[b], q['acomp'].values[b]), XT, top_n=C.K_CHAR,
                               threshold=1e-6, n_threads=C.N_PROC, sort=True)
            n = np.diff(M.indptr)
            parts.append(pd.DataFrame({'qi': np.repeat(b, n).astype(np.int32), 'si': s_idx[M.indices].astype(np.int32),
                                       'char_cos': M.data.astype(np.float32),
                                       'char_rank': np.concatenate([np.arange(k) for k in n]).astype(np.int8)
                                       if len(n) else np.zeros(0, np.int8)}))
        C.log(f'  char {c}|{st or "*"}: S1={len(s_idx):,} queries={len(q_idx):,}')
    if not parts:
        return pd.DataFrame({'qi': np.zeros(0, np.int32), 'si': np.zeros(0, np.int32),
                             'char_cos': np.zeros(0, np.float32), 'char_rank': np.zeros(0, np.int8)})
    return pd.concat(parts, ignore_index=True)


def merge(char, dense):
    """Union of both channels. dense carries dense_cos for every edge of the union (bienc.search computes it for
    char-only edges too); char_cos is NaN and char_rank = K_CHAR for edges the char channel did not return."""
    n = np.int64(max(int(char['si'].max()) if len(char) else 0, int(dense['si'].max()) if len(dense) else 0) + 1)
    kd = dense['qi'].values.astype(np.int64) * n + dense['si'].values
    kc = char['qi'].values.astype(np.int64) * n + char['si'].values
    oc = np.argsort(kc, kind='stable')
    kc = kc[oc]
    pos = np.minimum(np.searchsorted(kc, kd), max(len(kc) - 1, 0))
    hit = (kc[pos] == kd) if len(kc) else np.zeros(len(kd), bool)
    src = oc[pos] if len(kc) else pos
    del kc, pos
    o = np.argsort(kd, kind='stable')                     # sorted by (qi, si), integer keys only (low RAM)
    return pd.DataFrame({'qi': dense['qi'].values[o].astype(np.int32), 'si': dense['si'].values[o].astype(np.int32),
                         'dense_cos': dense['dense_cos'].values[o].astype(np.float32),
                         'dense_rank': dense['dense_rank'].values[o].astype(np.int8),
                         'char_cos': np.where(hit, char['char_cos'].values[src] if len(char) else np.nan, np.nan)[o].astype(np.float32),
                         'char_rank': np.where(hit, char['char_rank'].values[src] if len(char) else C.K_CHAR, C.K_CHAR)[o].astype(np.int8)})


def recall_report(pairs, truth, q):
    """R@k of the true S1 per country for each channel and for the merged candidate set."""
    pos = truth >= 0
    t = pairs[truth[pairs['qi'].values] == pairs['si'].values]
    for c in sorted(set(q['country'].values[pos])):
        m = pos & (q['country'].values == c)
        n = m.sum()
        tc = t[m[t['qi'].values]]
        found = len(tc) / max(n, 1)
        rc = [(tc['char_rank'] < k).sum() / max(n, 1) for k in (1, 3, C.K_CHAR)]
        rd = [(tc['dense_rank'] < k).sum() / max(n, 1) for k in (1, 3, C.K_DENSE)]
        C.log(f'  recall {c} (n={n:,}): char R@1/3/{C.K_CHAR}=' + '/'.join(f'{x:.4f}' for x in rc) +
              f'  dense R@1/3/{C.K_DENSE}=' + '/'.join(f'{x:.4f}' for x in rd) + f'  merged={found:.4f}')
    C.log(f'  candidates/query={len(pairs) / max(pairs["qi"].nunique(), 1):.2f}')


if __name__ == '__main__':
    C.SMOKE = True
    s1 = pd.DataFrame({'name': ['acme corp', 'zen labs', 'acme corp', 'zen labs'],
                       'acomp': ['1 main st|salem|ma', '5 elm rd|austin|tx', '9 oak ave|paris', '5 elm rd|austin'],
                       'country': ['US', 'US', 'France', 'US'], 'state': ['ma', 'tx', '', '']})
    q = pd.DataFrame({'name': ['acme corporation', 'zen lab', 'acme corp'],
                      'acomp': ['1 main street|salem|ma', '5 elm rd|austin|tx', '9 oak ave|paris'],
                      'country': ['US', 'US', 'France'], 'state': ['ma', 'tx', '']})
    idx = build_indexes(s1, ['US', 'France'])
    g = groups(s1, q, np.ones(3, bool), {'US': True, 'France': False})
    assert [(c, st, sorted(s), list(qq)) for c, st, s, qq in g] == \
        [('France', '', [2], [2]), ('US', 'ma', [0, 3], [0]), ('US', 'tx', [1, 3], [1])], g
    p = char_channel(s1, q, g, idx)
    top = p[p['char_rank'] == 0].set_index('qi')['si'].to_dict()
    assert top == {0: 0, 1: 1, 2: 2}, p                       # France never retrieves a US S1; MA query never sees TX S1
    assert not ((p.qi == 0) & (p.si == 1)).any()
    print('ok')
