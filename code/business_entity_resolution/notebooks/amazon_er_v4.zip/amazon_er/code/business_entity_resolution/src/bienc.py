"""Channel 2 of blocking: a fine-tuned multilingual bi-encoder (multilingual-e5-small, MIT).

Used for RECALL only: a pooled embedding cannot express "house number is 3 higher", so the final decision is left
to the GBDT and the cross-encoder. Training is InfoNCE with:
  * large batches (default 4096; halved automatically on out-of-memory) -> many in-batch negatives;
  * batches grouped by the S1's (country, state) bucket -> in-batch negatives are same-region look-alikes;
  * one mined hard negative per query (the best wrong candidate of the char channel);
  * false-negative masking: another column holding the query's own true S1 is not treated as a negative.
Search: exact inner product on the GPU inside each blocking group (no FAISS needed).
"""
import time
import numpy as np, pandas as pd, torch, torch.nn.functional as F
from transformers import AutoModel, AutoTokenizer
import config as C, nnutil as N
from text import spaced_digits, SEP


def texts(df, idx):
    n, a = df['name'].values, df['acomp'].values
    return ['query: ' + spaced_digits(n[i]) + ' | ' + spaced_digits(a[i].replace(SEP, ', ')) for i in idx]


def load(weights=True):
    tok = AutoTokenizer.from_pretrained(C.BIENC_MODEL)
    model = AutoModel.from_pretrained(C.BIENC_MODEL)
    if weights:
        N.load_state(model, C.WEIGHTS / 'bienc' / 'best.pt')
    return tok, model.to(N.device())


def embed(model, tok, txt, pad_to_max=False):
    enc = tok(txt, padding='max_length' if pad_to_max else True, truncation=True, max_length=C.BIENC_MAXLEN,
              return_tensors='pt').to(N.device())
    with N.autocast():
        h = model(**enc).last_hidden_state
    m = enc['attention_mask'].unsqueeze(-1).to(h.dtype)
    return F.normalize(((h * m).sum(1) / m.sum(1).clamp(min=1)).float(), dim=-1)


def _loss(model, tok, s1, q, qi, si, hn, truth_si, pad_to_max=False):
    ok = hn >= 0
    cols = np.concatenate([si, hn[ok]])
    eq = embed(model, tok, texts(q, qi), pad_to_max)
    es = embed(model, tok, texts(s1, cols), pad_to_max)
    logits = eq @ es.T / C.BIENC_TEMP
    mask = torch.as_tensor(cols[None, :] == truth_si[:, None], device=logits.device)
    mask[torch.arange(len(qi)), torch.arange(len(qi))] = False            # keep each row's own positive
    logits = logits.masked_fill(mask, -1e4)
    return F.cross_entropy(logits, torch.arange(len(qi), device=logits.device))


def train(s1, q, pos_tr, pos_va, truth, hardneg, bucket_of_s1):
    """pos_tr/pos_va: query indices of true pairs (train / validation regions). hardneg: per query, an S1 index or -1."""
    tok, model = load(weights=False)
    dev = N.device()
    if dev.type == 'cuda':
        model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant': False})
    model.train()
    rng = np.random.default_rng(C.SEED)

    # order: grouped by bucket, bucket-sized runs shuffled, so consecutive batches are same-region
    def ordering(idx, B):
        o = idx[np.lexsort((rng.random(len(idx)), bucket_of_s1[truth[idx]]))]
        runs = [o[a:a + B] for a in range(0, len(o), B)]
        rng.shuffle(runs)
        return np.concatenate(runs) if runs else o

    # find the largest batch that fits: probe one full-length step, halve on out-of-memory
    B = min(C.BIENC_BATCH, max(2, len(pos_tr)))
    opt = torch.optim.AdamW(model.parameters(), lr=C.BIENC_LR, weight_decay=0.01)
    while True:
        try:
            b = pos_tr[:B]
            _loss(model, tok, s1, q, b, truth[b], hardneg[b], truth[b], pad_to_max=True).backward()
            opt.zero_grad(set_to_none=True)
            B = max(2, B // 2) if torch.cuda.is_available() and B > 16 else B   # headroom: AdamW state is not allocated yet
            break
        except RuntimeError as e:
            if not N.is_oom(e) or B <= 8:
                raise
            opt.zero_grad(set_to_none=True); torch.cuda.empty_cache()
            B //= 2
            C.log(f'  bienc: out of memory, batch -> {B}')
    steps_per_epoch = max(1, len(pos_tr) // B)
    planned = steps_per_epoch * C.BIENC_EPOCHS
    if C.BIENC_MAX_STEPS:
        planned = min(planned, C.BIENC_MAX_STEPS)
    sched, scaler = N.linear_schedule(opt, planned), N.grad_scaler()
    ck = N.Checkpointer('bienc', planned)
    step = ck.resume(model, opt, sched)
    C.log(f'  bienc: batch={B} train pairs={len(pos_tr):,} planned steps={planned} (cap {C.BIENC_MINUTES} min)')

    va = pos_va[:min(len(pos_va), 4 * min(B, 512))]
    Bv = max(1, min(B, 512))

    @torch.no_grad()
    def val_loss():
        model.eval()
        ls = [_loss(model, tok, s1, q, va[a:a + Bv], truth[va[a:a + Bv]], hardneg[va[a:a + Bv]],
                    truth[va[a:a + Bv]]).item() for a in range(0, len(va), Bv)]
        model.train()
        return float(np.mean(ls)) if ls else float('nan')

    t0, order = time.time(), ordering(pos_tr, B)
    while step < planned and time.time() - t0 < C.BIENC_MINUTES * 60:
        a = (step % steps_per_epoch) * B
        if a == 0 and step:
            order = ordering(pos_tr, B)
        b = order[a:a + B]
        try:
            N.train_step(_loss(model, tok, s1, q, b, truth[b], hardneg[b], truth[b]), model, opt, sched, scaler)
        except RuntimeError as e:                      # a longer-than-usual batch can still exceed VRAM: halve, go on
            if not N.is_oom(e) or B <= 8:
                raise
            opt.zero_grad(set_to_none=True); torch.cuda.empty_cache()
            B //= 2
            steps_per_epoch = max(1, len(pos_tr) // B)
            order = ordering(pos_tr, B)
            C.log(f'  bienc: out of memory at step {step}, batch -> {B}')
            continue
        step += 1
        if step % C.BIENC_EVAL_EVERY == 0 or step == planned:
            ck.update(model, opt, sched, step, val_loss())
    if time.time() - t0 >= C.BIENC_MINUTES * 60:
        C.log(f'  bienc: time cap reached at step {step}/{planned}')
    ck.finish(model)
    return tok, model.eval()


@torch.no_grad()
def encode(model, tok, txt):
    """Embeddings (float16) for texts, length-sorted batches; the next batches are tokenised on a background
    thread while the GPU embeds the current one (v2 was tokenizer-bound at ~8k texts/s)."""
    from concurrent.futures import ThreadPoolExecutor
    import collections
    model.eval()
    dev = N.device()
    out = np.empty((len(txt), model.config.hidden_size), np.float16)
    order = np.argsort([len(t) for t in txt], kind='stable')
    batches = [order[a:a + C.ENC_BATCH] for a in range(0, len(txt), C.ENC_BATCH)]
    tokz = lambda idx: tok([txt[i] for i in idx], padding=True, truncation=True, max_length=C.BIENC_MAXLEN,
                           return_tensors='pt')
    t0 = time.time()
    with ThreadPoolExecutor(2) as ex:
        ahead = collections.deque(ex.submit(tokz, b) for b in batches[:3])
        for j, idx in enumerate(batches):
            enc = ahead.popleft().result().to(dev)
            if j + 3 < len(batches):
                ahead.append(ex.submit(tokz, batches[j + 3]))
            with N.autocast():
                h = model(**enc).last_hidden_state
            m = enc['attention_mask'].unsqueeze(-1).to(h.dtype)
            out[idx] = F.normalize(((h * m).sum(1) / m.sum(1).clamp(min=1)).float(), dim=-1).cpu().numpy()
            if len(batches) > 50 and (j + 1) % 50 == 0:
                done = min(len(txt), (j + 1) * C.ENC_BATCH)
                C.log(f'    encoded {done:,}/{len(txt):,} ({done / (time.time() - t0):,.0f} texts/s)')
    return out


def _rows_for(sorted_qi, ids):
    """Row numbers of sorted_qi equal to each id in ids, and which id they belong to."""
    lo, hi = np.searchsorted(sorted_qi, ids, 'left'), np.searchsorted(sorted_qi, ids, 'right')
    n = hi - lo
    rows = np.repeat(lo - np.r_[0, np.cumsum(n)[:-1]], n) + np.arange(n.sum())
    return rows, np.repeat(np.arange(len(ids)), n)


@torch.no_grad()
def search(model, tok, s1, q, grps, char, s1_emb_path):
    """Top-K_DENSE S1 per query inside its group, plus dense_cos for every char-channel edge.
    Returns the union edge set with columns qi, si, dense_cos, dense_rank (K_DENSE when not in the dense top-K)."""
    dev = N.device()
    if s1_emb_path.exists():
        E = np.load(s1_emb_path)
    else:
        E = encode(model, tok, texts(s1, np.arange(len(s1))))
        C.atomic(s1_emb_path, lambda t: np.save(open(t, 'wb'), E))
    dt = torch.float16 if dev.type == 'cuda' else torch.float32
    S = torch.as_tensor(E, device=dev).to(dt)
    del E
    char = char.sort_values('qi', kind='stable')
    cqi, csi = char['qi'].values, char['si'].values
    D, X = [[], [], []], [[], [], []]              # (qi, si, cos) of dense top-K / of char edges; numpy only (low RAM)
    for c, st, s_idx, q_idx in grps:
        if len(q_idx) == 0:
            continue
        Sb = S[torch.as_tensor(s_idx, device=dev)]
        k = min(C.K_DENSE, len(s_idx))
        for a in range(0, len(q_idx), 200_000):
            qb = q_idx[a:a + 200_000]
            Q = torch.as_tensor(encode(model, tok, texts(q, qb)), device=dev).to(dt)
            step = int(max(64, min(C.SEARCH_CHUNK, 1e9 // max(len(s_idx), 1))))   # score block <= ~2 GB (fp16)
            for b in range(0, len(qb), step):
                Qs = Q[b:b + step]
                sc, ix = (Qs @ Sb.T).topk(k, dim=1)
                sc = sc.float()
                ids = qb[b:b + step]
                D[0].append(np.repeat(ids, k).astype(np.int32))
                D[1].append(s_idx[ix.cpu().numpy().ravel()].astype(np.int32))
                D[2].append(sc.cpu().numpy().ravel().astype(np.float32))
                rows, owner = _rows_for(cqi, ids)
                if len(rows):
                    cs = (Qs[torch.as_tensor(owner, device=dev)].float() *
                          S[torch.as_tensor(csi[rows], device=dev)].float()).sum(-1)
                    X[0].append(cqi[rows].astype(np.int32)); X[1].append(csi[rows].astype(np.int32))
                    X[2].append(cs.cpu().numpy().astype(np.float32))
        C.log(f'  dense {c}|{st or "*"}: S1={len(s_idx):,} queries={len(q_idx):,}')
    del S, char
    cat = lambda L, dt: np.concatenate(L).astype(dt) if L else np.zeros(0, dt)
    dq, ds, dc = cat(D[0], np.int32), cat(D[1], np.int32), cat(D[2], np.float32)
    D.clear()
    start = np.r_[True, dq[1:] != dq[:-1]] if len(dq) else np.zeros(0, bool)      # rank within each query's list
    rank = (np.arange(len(dq)) - np.maximum.accumulate(np.where(start, np.arange(len(dq)), 0))).astype(np.int8)
    xq, xs, xc = cat(X[0], np.int32), cat(X[1], np.int32), cat(X[2], np.float32)
    n = np.int64(len(s1))
    new = ~np.isin(xq.astype(np.int64) * n + xs, dq.astype(np.int64) * n + ds)   # char edges not already in dense top-K
    return pd.DataFrame({'qi': np.r_[dq, xq[new]], 'si': np.r_[ds, xs[new]], 'dense_cos': np.r_[dc, xc[new]],
                         'dense_rank': np.r_[rank, np.full(new.sum(), C.K_DENSE, np.int8)]})


def hard_negatives(char, truth, n_q):
    """Best-ranked wrong char candidate per query, or -1."""
    w = char[truth[char['qi'].values] != char['si'].values].sort_values(['qi', 'char_rank'])
    w = w.drop_duplicates('qi')
    hn = np.full(n_q, -1, np.int64)
    hn[w['qi'].values] = w['si'].values
    return hn


if __name__ == '__main__':
    r, o = _rows_for(np.array([1, 1, 3, 5, 5, 5]), np.array([5, 2, 1]))
    assert r.tolist() == [3, 4, 5, 0, 1] and o.tolist() == [0, 0, 0, 2, 2]
    print('ok')
