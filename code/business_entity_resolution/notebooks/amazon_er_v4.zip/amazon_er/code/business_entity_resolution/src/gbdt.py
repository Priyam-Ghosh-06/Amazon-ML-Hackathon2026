"""LightGBM stages. Out-of-fold predictions on the training region (folds grouped by the query's top-1 S1);
the validation region and test are scored by the MEAN of the fold models, so every prediction comes from models
of the same strength (no full refit that would be sharper on test than anything stage 2 was trained on).
Early stopping watches the validation REGION (whole buckets never seen in training), not a random edge split.
"""
import numpy as np, pandas as pd, lightgbm as lgb
import config as C


def rows(X, Z, idx):
    """Float32 rows of the float16 memmap X (plus stage-2 columns Z); callers pass sorted idx for disk locality."""
    a = np.asarray(X[idx], dtype=np.float32)
    return a if Z is None else np.hstack([a, np.asarray(Z[idx], dtype=np.float32)])


def fit(X, Z, y, tr, va, name, cols):
    rng = np.random.default_rng(C.SEED)
    tr = np.sort(rng.choice(tr, min(C.GBDT_ROWS, len(tr)), replace=False))
    va = np.sort(rng.choice(va, min(C.GBDT_VAL_ROWS, len(va)), replace=False))
    dtr = lgb.Dataset(rows(X, Z, tr), y[tr], feature_name=cols, free_raw_data=True)
    dva = lgb.Dataset(rows(X, Z, va), y[va], reference=dtr, free_raw_data=True)
    m = lgb.train(C.GBDT_PARAMS, dtr, C.GBDT_ROUNDS, valid_sets=[dva],
                  callbacks=[lgb.early_stopping(C.GBDT_ES, verbose=False), lgb.log_evaluation(0)])
    best = m.best_iteration or m.current_iteration()
    m.save_model(str(C.WEIGHTS / f'{name}.txt'), num_iteration=best)
    C.log(f'  {name}: rows={len(tr):,} (pos {y[tr].mean():.3f}) best_iter={best} '
          f'val logloss={m.best_score.get("valid_0", {}).get("binary_logloss", float("nan")):.5f}')
    return lgb.Booster(model_file=str(C.WEIGHTS / f'{name}.txt'))


def load(stage):
    return [lgb.Booster(model_file=str(C.WEIGHTS / f'gbdt{stage}_fold{k}.txt')) for k in range(C.NF)]


def predict(models, X, Z, idx, fast=False):
    """fast: LightGBM prediction early-exit (stop adding trees once |margin| > 10, i.e. p < 5e-5 or > 0.99995).
    Used on test (~90M edges): several times faster, and uncertain edges get exactly the same score."""
    kw = dict(pred_early_stop=True, pred_early_stop_freq=20, pred_early_stop_margin=10.0) if fast else {}
    out = np.empty(len(idx), np.float32)
    for a in range(0, len(idx), C.FEAT_CHUNK):
        R = rows(X, Z, idx[a:a + C.FEAT_CHUNK])
        out[a:a + len(R)] = np.mean([m.predict(R, **kw) for m in models], axis=0)
    return out


def run_stage(stage, X, Z, y, fold, tr, va, cols):
    """Fit NF fold models on the training region; return OOF p for tr, fold-mean p for va, and the models."""
    p_tr = np.empty(len(tr), np.float32)
    models = []
    for k in range(C.NF):
        m = fit(X, Z, y, tr[fold[tr] != k], va, f'gbdt{stage}_fold{k}', cols)
        models.append(m)
        sel = fold[tr] == k
        p_tr[sel] = predict([m], X, Z, tr[sel])
    p_va = predict(models, X, Z, va)
    imp = pd.Series(np.mean([m.feature_importance('gain') for m in models], axis=0), index=cols)
    C.log(f'  gbdt{stage} top features (gain share):\n' +
          (imp / max(imp.sum(), 1e-9)).sort_values(ascending=False).head(15).round(4).to_string())
    return p_tr, p_va, models


# ---------------------------------------------------------------- v3: weighted hard-negative sampling, parallel folds
def hard_sample(idx, y, hard_p, target, seed=0):
    """All positives + every negative the previous model found non-trivial (p >= V3_HARD_P) + a sample of the easy
    negatives weighted by 1/rate, so the trees spend their rows near the decision boundary but the loss (and hence
    calibration) still reflects the full edge distribution. Returns (sorted rows, weights)."""
    rng = np.random.default_rng(seed)
    easy_m = (y[idx] == 0) & ~(hard_p[idx] >= C.V3_HARD_P)
    core, easy = idx[~easy_m], idx[easy_m]
    if len(core) >= target:
        core = rng.choice(core, target, replace=False)
        return np.sort(core), np.ones(len(core), np.float32)
    rate = min(1.0, (target - len(core)) / max(len(easy), 1))
    e = easy[rng.random(len(easy)) < rate]
    rows_ = np.r_[core, e]
    w = np.r_[np.ones(len(core), np.float32), np.full(len(e), 1 / max(rate, 1e-9), np.float32)]
    o = np.argsort(rows_, kind='stable')
    return rows_[o], w[o]


def _fit_weighted(X, Z, y, tr, w, va, path, cols, threads):
    dtr = lgb.Dataset(rows(X, Z, tr), y[tr], weight=w, feature_name=cols, free_raw_data=True)
    dva = lgb.Dataset(rows(X, Z, va), y[va], reference=dtr, free_raw_data=True)
    m = lgb.train({**C.GBDT_PARAMS, 'num_threads': threads}, dtr, C.GBDT_ROUNDS, valid_sets=[dva],
                  callbacks=[lgb.early_stopping(C.GBDT_ES, verbose=False), lgb.log_evaluation(0)])
    best = m.best_iteration or m.current_iteration()
    path.parent.mkdir(parents=True, exist_ok=True)
    m.save_model(str(path), num_iteration=best)
    C.log(f'  {path.stem}: rows={len(tr):,} (pos {y[tr].mean():.3f}) best_iter={best} '
          f'val logloss={m.best_score.get("valid_0", {}).get("binary_logloss", float("nan")):.5f}')
    return lgb.Booster(model_file=str(path))


def run_stage3(stage, X, Z, y, fold, fit_idx, cal_idx, cols, hard_p, folder):
    """NF fold models fitted IN PARALLEL on hard-negative-weighted rows of fit_idx, early-stopped on a sample of
    cal_idx (held-out buckets of both countries). Returns (out-of-fold p for fit_idx, models)."""
    from concurrent.futures import ThreadPoolExecutor
    rng = np.random.default_rng(C.SEED)
    va = np.sort(rng.choice(cal_idx, min(2 * C.GBDT_VAL_ROWS, len(cal_idx)), replace=False))
    threads = max(1, C.N_PROC // C.NF)

    def one(k):
        tr, w = hard_sample(fit_idx[fold[fit_idx] != k], y, hard_p, C.V3_GBDT_ROWS * (C.NF - 1) // C.NF, seed=k)
        return _fit_weighted(X, Z, y, tr, w, va, folder / f'gbdt{stage}_fold{k}.txt', cols, threads)
    with ThreadPoolExecutor(C.NF) as ex:
        models = list(ex.map(one, range(C.NF)))
    p = np.empty(len(fit_idx), np.float32)
    for k, m in enumerate(models):
        sel = fold[fit_idx] == k
        p[sel] = predict([m], X, Z, fit_idx[sel], fast=True)
    imp = pd.Series(np.mean([m.feature_importance('gain') for m in models], axis=0), index=cols)
    C.log(f'  v3 gbdt{stage} top features (gain share):\n' +
          (imp / max(imp.sum(), 1e-9)).sort_values(ascending=False).head(15).round(4).to_string())
    return p, models


def load3(stage, folder):
    return [lgb.Booster(model_file=str(folder / f'gbdt{stage}_fold{k}.txt')) for k in range(C.NF)]


if __name__ == '__main__':
    y_ = np.array([1, 0, 0, 0, 0, 0, 0, 0, 0, 0]); hp = np.array([.9, .5, 0, 0, 0, 0, 0, 0, 0, 0.])
    r_, w_ = hard_sample(np.arange(10), y_, hp, 6)
    assert set(r_[:2]) == {0, 1} and len(r_) >= 3 and np.isclose(w_[2:], 1 / 0.5).all()   # 4 of 8 easy, weight 2
    X = np.arange(12, dtype=np.float16).reshape(6, 2)
    assert rows(X, None, np.array([4, 1, 3])).tolist() == [[8, 9], [2, 3], [6, 7]]
    assert rows(X, np.ones((6, 1)), np.array([0, 5])).shape == (2, 3)
    print('ok')
