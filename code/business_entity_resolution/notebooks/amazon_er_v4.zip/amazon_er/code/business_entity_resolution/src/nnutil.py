"""Shared pieces for the two transformer models: device/precision, checkpoint policy, model loading.

Checkpoint policy (the same for the bi-encoder and the cross-encoder):
  * validate every BIENC_EVAL_EVERY / CE_EVAL_EVERY optimiser steps on a fixed validation sample;
  * no best.pt before SAVE_AFTER x planned steps: early loss falls fast and every eval would "improve";
  * after that, overwrite best.pt only when validation loss is >= MIN_REL_IMPROVE lower than the best so far;
  * every write goes to a temp file first and is renamed over the old one (a crash cannot corrupt best.pt);
  * last.pt (model + optimiser + scheduler + step) is written at every validation for --resume, and deleted once
    training finishes, so it never costs disk after the run.
"""
import json, time, contextlib
import torch
import transformers
import config as C

transformers.logging.set_verbosity_error()          # keep the run log readable (no per-tensor load bars)
transformers.utils.logging.disable_progress_bar()


def device():
    return torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def amp_dtype():
    """bf16 on Ampere+ (A100, RTX 30xx/40xx, L4, H100); fp16 + loss scaling on older GPUs (T4, V100); None on CPU."""
    if not torch.cuda.is_available():
        return None
    return torch.bfloat16 if torch.cuda.get_device_capability()[0] >= 8 else torch.float16


def grad_scaler():
    return torch.amp.GradScaler('cuda', enabled=amp_dtype() == torch.float16)


def train_step(loss, model, opt, sched, scaler):
    scaler.scale(loss).backward()
    scaler.unscale_(opt)
    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
    scaler.step(opt); scaler.update(); sched.step(); opt.zero_grad(set_to_none=True)


def autocast():
    if amp_dtype() is not None:
        return torch.autocast('cuda', dtype=amp_dtype())
    return contextlib.nullcontext()


def is_oom(e):
    return isinstance(e, torch.cuda.OutOfMemoryError) or 'out of memory' in str(e).lower()


def vram_gb():
    return torch.cuda.get_device_properties(0).total_memory / 2 ** 30 if torch.cuda.is_available() else 0.0


def half_state(model):
    return {k: v.detach().to('cpu', torch.bfloat16) if v.is_floating_point() else v.detach().cpu()
            for k, v in model.state_dict().items()}


def load_state(model, path):
    sd = torch.load(path, map_location='cpu', weights_only=True)
    model.load_state_dict({k: v.float() if v.is_floating_point() else v for k, v in sd.items()})
    return model


class Checkpointer:
    def __init__(self, name, planned_steps):
        self.dir = C.WEIGHTS / name
        self.dir.mkdir(parents=True, exist_ok=True)
        self.best_path, self.last_path = self.dir / 'best.pt', self.dir / 'last.pt'
        self.gate = int(C.SAVE_AFTER * planned_steps)
        self.best = float('inf')
        self.name = name
        self.warm_best = (float('inf'), None)       # best weights seen before the gate, kept in RAM as a fallback

    def resume(self, model, opt, sched):
        """Returns the step to continue from (0 when there is nothing to resume)."""
        if not self.last_path.exists():
            return 0
        st = torch.load(self.last_path, map_location='cpu', weights_only=False)
        model.load_state_dict(st['model'])
        opt.load_state_dict(st['opt'])
        sched.load_state_dict(st['sched'])
        self.best = st['best']
        C.log(f'  {self.name}: resumed at step {st["step"]} (best val loss {self.best:.4f})')
        return st['step']

    def update(self, model, opt, sched, step, val_loss):
        saved = False
        if step >= self.gate and val_loss < self.best * (1 - C.MIN_REL_IMPROVE):
            self.best = val_loss
            C.atomic(self.best_path, lambda t: torch.save(half_state(model), t))
            self._manifest(step, val_loss)
            saved = True
        if step < self.gate and val_loss < self.warm_best[0]:
            self.warm_best = (val_loss, half_state(model))
        C.atomic(self.last_path, lambda t: torch.save({'model': model.state_dict(), 'opt': opt.state_dict(),
                                                      'sched': sched.state_dict(), 'step': step, 'best': self.best}, t))
        C.log(f'  {self.name} step {step}: val loss {val_loss:.4f}' + ('  -> best.pt' if saved else
                                                                       '  (warm-up, not saved)' if step < self.gate else ''))

    def finish(self, model):
        """Keep the best weights. If the time cap stopped training before the gate, keep the lowest-validation-loss
        weights seen during warm-up (not the final ones, which can be worse)."""
        if not self.best_path.exists():
            loss, st = self.warm_best
            C.atomic(self.best_path, lambda t: torch.save(st if st is not None else half_state(model), t))
            self._manifest(-1, loss)
        self.last_path.unlink(missing_ok=True)
        return load_state(model, self.best_path)

    def _manifest(self, step, val_loss):
        path = C.WEIGHTS / 'manifest.json'
        m = json.loads(path.read_text()) if path.exists() else {}
        m[self.name] = {'step': step, 'val_loss': val_loss, 'saved_at': time.strftime('%Y-%m-%d %H:%M:%S')}
        C.atomic(path, lambda t: open(t, 'w').write(json.dumps(m, indent=1)))


def linear_schedule(opt, total, warmup_frac=0.05):
    warm = max(1, int(warmup_frac * total))
    return torch.optim.lr_scheduler.LambdaLR(
        opt, lambda s: min(1.0, (s + 1) / warm) * max(0.0, 1 - max(0, s - warm) / max(1, total - warm)))


if __name__ == '__main__':
    import tempfile, pathlib
    C.WEIGHTS = pathlib.Path(tempfile.mkdtemp())
    C.SAVE_AFTER, C.MIN_REL_IMPROVE = 0.3, 0.01
    m = torch.nn.Linear(2, 1)
    opt = torch.optim.SGD(m.parameters(), lr=0.1)
    sch = linear_schedule(opt, 100)
    ck = Checkpointer('t', 100)
    ck.update(m, opt, sch, 10, 1.0)
    assert not ck.best_path.exists() and ck.last_path.exists()          # warm-up gate: nothing saved at step 10
    ck.update(m, opt, sch, 40, 0.9); assert ck.best == 0.9
    ck.update(m, opt, sch, 50, 0.895); assert ck.best == 0.9             # < 1% better: not significant
    ck.update(m, opt, sch, 60, 0.80); assert ck.best == 0.8
    m2 = torch.nn.Linear(2, 1)
    assert Checkpointer('t', 100).resume(m2, torch.optim.SGD(m2.parameters(), lr=.1), linear_schedule(opt, 100)) == 60
    ck.finish(m)
    assert not ck.last_path.exists() and ck.best_path.exists()
    print('ok')
