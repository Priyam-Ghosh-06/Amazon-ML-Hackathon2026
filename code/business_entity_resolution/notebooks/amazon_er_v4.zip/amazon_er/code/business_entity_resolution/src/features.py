"""Stage C: comparison vector for every (query r, S1 s) candidate edge, and stage E: sibling features.

Pair features are computed in worker processes (spawn, data passed explicitly per task, so workers never copy the
parent's tables) and stored as a float16 memmap on disk (~2 bytes per value; values are clipped to +-60000).

Stage E (one synchronous Jacobi round, sequence-neutral): an edge (r, s) is re-priced by what the OTHER confident
records of the same (S1, source) star say. The generator has a per-source address view, so an extra number or
address token (a landmark, a street name) that r has but s lacks is trustworthy when a confident same-source
sibling repeats it, and suspicious when confident siblings agree with s instead.
"""
import json, multiprocessing as mp, re
import numpy as np, pandas as pd
from rapidfuzz import fuzz, process
from rapidfuzz.distance import JaroWinkler
import config as C
from text import flat, comps, has_digit, numbers, ordinal_ok, LEGAL, LANDMARK, CANON, name_tokens3, addr_tokens3

D_SHIFTS = {1, 2, 3, 4, 5, 7, 9, 11, 13, 21}      # decoy house-number shifts (rule A, deep-dive §4.5)
LLR_MIN_COUNT = 30
_digits = re.compile(r'\d+')

PAIR_COLS = (['name_ratio', 'name_tset', 'name_tsort', 'name_partial', 'name_jw', 'core_ratio', 'core_tset',
              'addr_ratio', 'addr_tset', 'addr_tsort', 'addr_partial', 'name_len_q', 'name_len_s', 'addr_len_q',
              'addr_len_s'] +
             ['name_extra_n', 'name_extra_llr_sum', 'name_extra_llr_min', 'name_miss_n', 'name_miss_llr_sum',
              'name_miss_llr_min', 'name_edge_append', 'name_edge_trunc', 'lf_conflict', 'lf_extra', 'lf_miss',
              'name_exact',
              'addr_extra_n', 'addr_extra_llr_sum', 'addr_extra_llr_min', 'addr_miss_n', 'addr_miss_llr_sum',
              'addr_miss_llr_min', 'place_conflict', 'place_one_sided', 'n_place_q', 'n_place_s', 'street_jacc',
              'state_rel', 'landmark_q', 'landmark_s',
              'num_common', 'num_extra', 'num_miss', 'shift_signed', 'shift_abs', 'shift_ratio', 'shift_in_d',
              'shift_in_d_neg', 'suffix_mismatch', 'ordinal_bad_q'])
GRAPH_COLS = ['char_cos', 'char_rank', 'dense_cos', 'dense_rank', 'char_gap', 'dense_gap', 'n_cand', 's_degree',
              's_top1_degree', 's_mean_dense', 's_name_group', 's_colo', 'q_bucketed', 'src']
STAR_COLS = ['n_sib_same', 'n_sib_cross', 'p_sib_sum', 'p_q_other', 'num_corr', 'num_frac', 'num_contra',
             'tok_corr', 'tok_frac', 'tok_contra', 'sib_addr_max']


def _toks(s):
    return {t for t in s.split() if not has_digit(t)}


# ---------------------------------------------------------------- learned tables
def learn_llr(q, s1, qi, si, y, v3=False):
    """Per token: log P(token extra|missing in a TRUE pair) - log P(... in a DECOY vs its near-duplicate S1).
    Class 0 is decoys only (not arbitrary wrong candidates), so the table prices decoy operators (Group, Holdings,
    legal-form swaps) rather than "looks like a different address". Digit tokens have their own channel.
    v3: country names folded to one token, street types canonicalised (same token handling as _edge in v3).
    Also used label-free (lf.py): y = 1 for positive-signature pairs, 0 for decoy-signature pairs."""
    tabs = {}
    nt = (lambda x: {t for t in name_tokens3(x) if not has_digit(t)}) if v3 else _toks
    at = (lambda x: {t for t in addr_tokens3(flat(x)) if not has_digit(t)}) if v3 else (lambda x: _toks(flat(x)))
    for col, f in (('name', nt), ('addr', at)):
        a = [f(x) for x in q[col if col == 'name' else 'acomp'].values[qi]]
        b = [f(x) for x in s1[col if col == 'name' else 'acomp'].values[si]]
        for kind in ('extra', 'miss'):
            d = [x - z for x, z in zip(a, b)] if kind == 'extra' else [z - x for x, z in zip(a, b)]
            t = pd.DataFrame({'t': [list(e) for e in d], 'y': y}).explode('t').dropna()
            c = t.groupby(['t', 'y']).size().unstack(fill_value=0).reindex(columns=[0, 1], fill_value=0)
            c = c[c.sum(axis=1) >= (LLR_MIN_COUNT if not C.SMOKE else 2)]
            n0, n1 = max((y == 0).sum(), 1), max((y == 1).sum(), 1)
            tabs[f'{col}_{kind}'] = (np.log((c[1] + 1) / n1) - np.log((c[0] + 1) / n0)).to_dict()
    return tabs


def s1_aux(s1):
    """Per S1: how many S1 share its exact name (country-wise) and its street+number component (co-located)."""
    grp = s1.groupby(['country', 'name'], observed=True)['name'].transform('size').values.astype(np.float32)
    key = [next((' '.join(sorted(c.split())) for c in comps(a) if has_digit(c)), '') for a in s1['acomp'].values]
    k = pd.Series(key)
    colo = (pd.DataFrame({'c': s1['country'].values, 'k': k}).groupby(['c', 'k'])['k'].transform('size').values - 1)
    colo = np.where(k.values == '', 0, colo).astype(np.float32)
    return {'name_group': grp, 'colo': colo}


# ---------------------------------------------------------------- per-edge features (worker side)
_T = {}


def _init(tables):
    _T.update(tables)


def _edge(qn, sn, qa, sa, qf, sf, qst, sst, ctry=''):
    v3 = _T.get('v3', False)
    llr = (_T['llr_by_country'].get(ctry) or _T['llr_by_country']['*']) if v3 else _T['llr']
    alias, legal = _T['alias'], _T.get('legal', LEGAL)
    Q, S = (name_tokens3(qn), name_tokens3(sn)) if v3 else (set(qn.split()), set(sn.split()))
    ex, mi = Q - S, S - Q
    out = []
    for toks, tab in ((ex, llr['name_extra']), (mi, llr['name_miss'])):
        v = [tab.get(t, 0.0) for t in toks if not has_digit(t)]
        out += [len(toks), sum(v), min(v, default=0.0)]
    app = sum(any(x.startswith(u) and 1 <= len(x) - len(u) <= 3 for u in mi) for x in ex)
    trn = sum(any(u.startswith(x) and 1 <= len(u) - len(x) <= 3 for u in mi) for x in ex)
    fq, fs = {legal[t] for t in Q if t in legal}, {legal[t] for t in S if t in legal}
    out += [app, trn, int(bool(fq) and bool(fs) and not fq & fs), len(fq - fs), len(fs - fq), int(qn == sn)]

    QA, SA = (addr_tokens3(qf), addr_tokens3(sf)) if v3 else (set(qf.split()), set(sf.split()))
    for toks, tab in ((QA - SA, llr['addr_extra']), (SA - QA, llr['addr_miss'])):
        v = [tab.get(t, 0.0) for t in toks if not has_digit(t)]
        out += [len(toks), sum(v), min(v, default=0.0)]
    cq, cs = comps(qa), comps(sa)
    A, B = {x for x in cq if not has_digit(x)}, {x for x in cs if not has_digit(x)}
    ua = [x for x in A - B if not any(fuzz.ratio(x, z) >= 85 for z in B)]
    ub = [z for z in B - A if not any(fuzz.ratio(x, z) >= 85 for x in A)]
    ua2 = [x for x in ua if not any((x, z) in alias for z in ub)]
    ub2 = [z for z in ub if not any((x, z) in alias for x in ua)]
    cn = (lambda t: CANON.get(t, t)) if v3 else (lambda t: t)
    sq = {cn(t) for c in cq if has_digit(c) for t in c.split() if not t.isdigit()}
    ss = {cn(t) for c in cs if has_digit(c) for t in c.split() if not t.isdigit()}
    jac = len(sq & ss) / len(sq | ss) if sq and ss else np.nan
    srel = (1 if qst == sst else -1) if qst and sst else 0
    out += [int(bool(ua2) and bool(ub2)), int(bool(ua2) != bool(ub2)), len(A), len(B), jac, srel,
            int(bool(LANDMARK & QA)), int(bool(LANDMARK & SA))]

    nq, ns = numbers(qf), numbers(sf)
    Nq, Ns = {v for v, _ in nq}, {v for v, _ in ns}
    e, m = Nq - Ns, Ns - Nq
    if e and m:
        _, x, y = min((abs(x - y), x, y) for x in e for y in m)
        d = x - y
        sh = [d, abs(d), max(x, y) / max(min(x, y), 1), int(d in D_SHIFTS), int(-d in D_SHIFTS)]
    else:
        sh = [np.nan, np.nan, np.nan, 0, 0]
    ords = ('', 'st', 'nd', 'rd', 'th')
    lq, ls = {}, {}
    for v, s_ in nq:
        if s_ not in ords:
            lq.setdefault(v, set()).add(s_)
    for v, s_ in ns:
        if s_ not in ords:
            ls.setdefault(v, set()).add(s_)
    smis = sum(1 for v in lq.keys() & ls.keys() if not lq[v] & ls[v])
    out += [len(Nq & Ns), len(e), len(m)] + sh + [smis, sum(not ordinal_ok(v, s_) for v, s_ in nq)]
    return out


def _pair_block(t):
    qn, sn, qa, sa, qst, sst = t[:6]
    ctry = t[6] if len(t) > 6 else [''] * len(qn)
    legal = _T.get('legal', LEGAL)
    qf, sf = [flat(a) for a in qa], [flat(a) for a in sa]
    en = np.array([not x or not z for x, z in zip(qn, sn)])
    ea = np.array([not x or not z for x, z in zip(qf, sf)])
    cols = []
    for sc in (fuzz.ratio, fuzz.token_set_ratio, fuzz.token_sort_ratio, fuzz.partial_ratio):
        cols.append(np.where(en, np.nan, process.cpdist(qn, sn, scorer=sc, workers=1)))
    cols.append(np.where(en, np.nan, process.cpdist(qn, sn, scorer=JaroWinkler.normalized_similarity, workers=1)))
    core = lambda s: ' '.join(t for t in s.split() if t not in legal)
    qc, sc_ = [core(x) for x in qn], [core(x) for x in sn]
    for sc in (fuzz.ratio, fuzz.token_set_ratio):
        cols.append(np.where(en, np.nan, process.cpdist(qc, sc_, scorer=sc, workers=1)))
    for sc in (fuzz.ratio, fuzz.token_set_ratio, fuzz.token_sort_ratio, fuzz.partial_ratio):
        cols.append(np.where(ea, np.nan, process.cpdist(qf, sf, scorer=sc, workers=1)))
    cols += [np.fromiter(map(len, v), np.float32, len(v)) for v in (qn, sn, qf, sf)]
    rest = np.array([_edge(*r) for r in zip(qn, sn, qa, sa, qf, sf, qst, sst, ctry)], dtype=np.float32)
    return np.hstack([np.column_stack(cols).astype(np.float32), rest.reshape(len(qn), -1)])


# ---------------------------------------------------------------- matrix building (main side)
def graph_features(pairs, aux, q, q_bucketed):
    qi, si = pairs['qi'].values, pairs['si'].values
    g = pd.DataFrame({'qi': qi, 'si': si, 'c': pairs['char_cos'].values, 'd': pairs['dense_cos'].values})
    f = {'char_cos': g['c'].values, 'char_rank': pairs['char_rank'].values.astype(np.float32),
         'dense_cos': g['d'].values, 'dense_rank': pairs['dense_rank'].values.astype(np.float32)}
    f['char_gap'] = g.groupby('qi')['c'].transform('max').values - g['c'].values
    f['dense_gap'] = g.groupby('qi')['d'].transform('max').values - g['d'].values
    f['n_cand'] = g.groupby('qi')['qi'].transform('size').values.astype(np.float32)
    f['s_degree'] = g.groupby('si')['si'].transform('size').values.astype(np.float32)
    t1 = top1_mask(pairs)
    f['s_top1_degree'] = np.bincount(si[t1], minlength=si.max() + 1 if len(si) else 1)[si].astype(np.float32)
    f['s_mean_dense'] = g.groupby('si')['d'].transform('mean').values
    f['s_name_group'] = aux['name_group'][si]
    f['s_colo'] = aux['colo'][si]
    f['q_bucketed'] = q_bucketed[qi].astype(np.float32)
    f['src'] = q['src'].values[qi].astype(np.float32)
    return pd.DataFrame(f)[GRAPH_COLS].astype(np.float32)


def top1_mask(pairs):
    """The query's best edge by bi-encoder cosine (defined for every edge of the union)."""
    o = np.lexsort((-pairs['dense_cos'].values, pairs['qi'].values))
    first = np.r_[True, pairs['qi'].values[o][1:] != pairs['qi'].values[o][:-1]] if len(o) else np.zeros(0, bool)
    m = np.zeros(len(pairs), bool)
    m[o[first]] = True
    return m


def build_X(name, pairs, G, s1, q, tables, folder=None):
    """Float16 memmap <folder>/<name>_X1.f16 with GRAPH_COLS + PAIR_COLS; returns (memmap, columns)."""
    folder = folder or C.WORK
    folder.mkdir(parents=True, exist_ok=True)
    path, cpath = folder / f'{name}_X1.f16', folder / f'{name}_X1.cols.json'
    cols = GRAPH_COLS + PAIR_COLS
    if len(pairs) == 0:
        return np.zeros((0, len(cols)), np.float16), cols
    if cpath.exists():
        return np.memmap(path, np.float16, 'r', shape=(len(pairs), len(cols))), cols
    X = np.memmap(path, np.float16, 'w+', shape=(len(pairs), len(cols)))
    qi, si = pairs['qi'].values, pairs['si'].values
    qn, qa, qs, qc = q['name'].values, q['acomp'].values, q['state'].values, q['country'].values
    sn, sa, ss = s1['name'].values, s1['acomp'].values, s1['state'].values

    def tasks(a, b):
        for x in range(a, b, C.SUB_CHUNK):
            y = min(b, x + C.SUB_CHUNK)
            i, j = qi[x:y], si[x:y]
            yield (qn[i].tolist(), sn[j].tolist(), qa[i].tolist(), sa[j].tolist(), qs[i].tolist(), ss[j].tolist(),
                   qc[i].tolist())

    pool = mp.get_context('spawn').Pool(C.N_PROC, initializer=_init, initargs=(tables,)) if C.N_PROC > 1 else None
    if pool is None:
        _init(tables)
    try:
        for a in range(0, len(pairs), C.FEAT_CHUNK):
            b = min(len(pairs), a + C.FEAT_CHUNK)
            P = np.vstack(list(pool.imap(_pair_block, tasks(a, b)) if pool else map(_pair_block, tasks(a, b))))
            X[a:b] = np.clip(np.hstack([G.values[a:b], P]), -60000, 60000).astype(np.float16)
            C.log(f'  features {name}: {b:,}/{len(pairs):,}')
    finally:
        if pool:
            pool.close(); pool.join()
    X.flush()
    C.atomic(cpath, lambda t: open(t, 'w').write(json.dumps(cols)))
    return np.memmap(path, np.float16, 'r', shape=(len(pairs), len(cols))), cols


# ---------------------------------------------------------------- stage E
def _items(kind, text):
    if kind == 'num':
        return {int(x[-15:]) for x in _digits.findall(text)}
    return {hash(t) for t in text.split() if len(t) >= 3 and not has_digit(t)}


def star_features(pairs, p, q, s1, tau=None):
    """Leave-one-out sibling features from confident members of the same (S1, source) star; reads only the
    previous round's p, so the result does not depend on row order and cannot reinforce itself.
      n_sib_same / n_sib_cross / p_sib_sum : support of the star from confident members (p >= tau)
      p_q_other     : the query's best p to any OTHER S1 (competing hypothesis)
      *_corr        : max p of a confident same-source sibling containing ALL of r's extra numbers / tokens
      *_frac        : share of r's extras found in ANY confident same-source sibling
      *_contra      : max p of a confident same-source sibling with no extras of its own and none of r's
      sib_addr_max  : best token-set similarity of r's address to a confident same-source sibling's
    num/tok features: -1 when r has no extras, -2 when p(r->s) < P_MIN (not computed)."""
    tau = C.SIB_TAU if tau is None else tau
    qi, si = pairs['qi'].values.astype(np.int64), pairs['si'].values.astype(np.int64)
    src = q['src'].values[qi].astype(np.int64)
    n_e = len(qi)
    out = {}
    conf = p >= tau
    key = si * 2 + src
    ns = np.bincount(key, weights=conf, minlength=2 * (si.max() + 1))[key]
    na = np.bincount(si, weights=conf)[si]
    pa = np.bincount(si, weights=p * conf)[si]
    f32 = lambda a: np.asarray(a, np.float32)                        # keep RAM low on ~90M test edges
    out.update(n_sib_same=f32(ns - conf), n_sib_cross=f32(na - ns), p_sib_sum=f32(pa - p * conf))
    del ns, na, pa
    o = np.lexsort((-p, qi))
    first = np.r_[True, qi[o][1:] != qi[o][:-1]]
    top, sec = np.zeros(qi.max() + 1), np.zeros(qi.max() + 1)
    top[qi[o][first]] = p[o][first]
    second = np.r_[False, ~first[1:] & first[:-1]]
    sec[qi[o][second]] = p[o][second]
    is_top = np.zeros(n_e, bool); is_top[o[first]] = True
    out['p_q_other'] = f32(np.where(is_top, sec[qi], top[qi]))

    ev = np.flatnonzero(p >= C.P_MIN)
    qflat = lambda i: flat(q['acomp'].values[i])
    sflat = lambda i: flat(s1['acomp'].values[i])
    for kind in ('num', 'tok'):
        qc, sc = {}, {}
        qit = lambda i: qc[i] if i in qc else qc.setdefault(i, _items(kind, qflat(i)))
        sit = lambda i: sc[i] if i in sc else sc.setdefault(i, _items(kind, sflat(i)))
        need = np.zeros(n_e, np.int64)
        xe, xi = [], []
        for e in ev:
            ex = qit(qi[e]) - sit(si[e])
            need[e] = len(ex)
            xe += [e] * len(ex); xi += list(ex)
        mem = ev[conf[ev]]
        me, mi = [], []
        for e in mem:
            it = qit(qi[e])
            me += [e] * len(it); mi += list(it)
        X = pd.DataFrame({'e': np.array(xe, np.int64), 'item': np.array(xi, np.int64)})
        X['si'], X['src'], X['qi'] = si[X['e'].values], src[X['e'].values], qi[X['e'].values]
        M = pd.DataFrame({'m': np.array(me, np.int64), 'item': np.array(mi, np.int64)})
        M['si'], M['src'], M['qj'], M['pj'] = si[M['m'].values], src[M['m'].values], qi[M['m'].values], p[M['m'].values]
        hit = X.merge(M, on=['si', 'src', 'item'])
        hit = hit[hit['qi'] != hit['qj']]
        cnt = hit.groupby(['e', 'm']).agg(k=('item', 'size'), pj=('pj', 'first')).reset_index()
        full = cnt[cnt['k'].values >= need[cnt['e'].values]].groupby('e')['pj'].max()
        frac = hit.drop_duplicates(['e', 'item']).groupby('e').size()
        base = np.full(n_e, -2.0, np.float32); base[ev] = np.where(need[ev] > 0, 0.0, -1.0)
        corr, fr, contra = base.copy(), base.copy(), base.copy()
        corr[full.index.values] = full.values
        fr[frac.index.values] = frac.values / need[frac.index.values]
        clean = pd.DataFrame({'m': mem[need[mem] == 0]})
        clean['si'], clean['src'], clean['qj'], clean['pj'] = (si[clean['m'].values], src[clean['m'].values],
                                                               qi[clean['m'].values], p[clean['m'].values])
        dirty = ev[need[ev] > 0]
        cdf = pd.DataFrame({'e': dirty, 'si': si[dirty], 'src': src[dirty], 'qi': qi[dirty]}).merge(clean, on=['si', 'src'])
        cdf = cdf[cdf['qi'] != cdf['qj']]
        shared = cnt[['e', 'm']].assign(sh=True)
        cdf = cdf.merge(shared, on=['e', 'm'], how='left')
        cm = cdf[cdf['sh'].isna()].groupby('e')['pj'].max()
        contra[cm.index.values] = cm.values
        out[f'{kind}_corr'], out[f'{kind}_frac'], out[f'{kind}_contra'] = f32(corr), f32(fr), f32(contra)

    # union of features: best address similarity to a confident same-source sibling
    E = pd.DataFrame({'e': ev, 'si': si[ev], 'src': src[ev], 'qi': qi[ev]})
    Mm = pd.DataFrame({'si': si[ev[conf[ev]]], 'src': src[ev[conf[ev]]], 'qj': qi[ev[conf[ev]]]})
    J = E.merge(Mm, on=['si', 'src'])
    J = J[J['qi'] != J['qj']]
    sib = np.full(n_e, -1.0, np.float32)
    qa, je, jq, jj = q['acomp'].values, J['e'].values, J['qi'].values, J['qj'].values
    del J
    for a in range(0, len(je), 2_000_000):                            # chunked: bounded RAM on ~90M test edges
        sim = process.cpdist([flat(qa[i]) for i in jq[a:a + 2_000_000]], [flat(qa[j]) for j in jj[a:a + 2_000_000]],
                             scorer=fuzz.token_set_ratio, workers=-1)
        np.maximum.at(sib, je[a:a + 2_000_000], sim.astype(np.float32))
    out['sib_addr_max'] = np.where(sib < 0, np.nan, sib).astype(np.float32)
    return pd.DataFrame(out)[STAR_COLS].astype(np.float32)


if __name__ == '__main__':
    C.SMOKE = True
    _init({'llr': {'name_extra': {'group': -3.0}, 'name_miss': {}, 'addr_extra': {}, 'addr_miss': {}},
           'alias': {('pennsylvania', 'pa')}})
    r = dict(zip(PAIR_COLS[15:], _edge('caldovaer group llc', 'caldova inc', '3051 42rd ave|pennsylvania',
                                       '3042 42nd avenue|pa', '3051 42rd ave pennsylvania', '3042 42nd avenue pa',
                                       'pa', 'pa')))
    assert r['name_extra_llr_min'] == -3.0 and r['name_edge_append'] == 1 and r['lf_conflict'] == 1
    assert r['shift_signed'] == 9 and r['shift_in_d'] == 1 and r['ordinal_bad_q'] == 1 and r['place_conflict'] == 0
    assert r['state_rel'] == 1 and r['num_common'] == 1
    b = _pair_block((['acme llc'], ['acme llc'], ['1 main st|boston'], ['1 main st|salem'], [''], ['']))
    assert b.shape == (1, len(PAIR_COLS)) and dict(zip(PAIR_COLS, b[0]))['place_conflict'] == 1
    # v3: France gets its own word table; country names fold to one token; 'ave' == 'avenue'; SNC is a legal form
    import text as _tx
    _T.clear()
    _init({'v3': True, 'legal': _tx.LEGAL3, 'alias': {('nord', 'hauts de france')},
           'llr_by_country': {'*': {'name_extra': {'<ctry>': -8.0}, 'name_miss': {}, 'addr_extra': {}, 'addr_miss': {}},
                              'France': {'name_extra': {'holding': -6.0, '<ctry>': -3.0}, 'name_miss': {},
                                         'addr_extra': {}, 'addr_miss': {}}}})
    r3 = dict(zip(PAIR_COLS[15:], _edge('maison holding france', 'maison snc', '12 r kepler|lille|nord',
                                        '12 rue kepler|lille|hauts de france', '12 r kepler lille nord',
                                        '12 rue kepler lille hauts de france', '', '', 'France')))
    assert r3['name_extra_llr_min'] == -6.0 and r3['name_extra_llr_sum'] == -9.0 and r3['lf_miss'] == 1
    assert r3['street_jacc'] == 1.0 and r3['place_conflict'] == 0 and r3['addr_extra_n'] == 1   # only 'nord' extra
    r4 = dict(zip(PAIR_COLS[15:], _edge('acme india', 'acme', '1 a st', '1 a st', '1 a st', '1 a st', '', '', 'India')))
    assert r4['name_extra_llr_min'] == -8.0                              # pooled table, folded country token
    _T.clear()
    # stage E: r0 has extra number 7, corroborated by same-source sibling r1 (p .8), not by the S3 sibling r2
    s1 = pd.DataFrame({'acomp': ['100 main']})
    q = pd.DataFrame({'src': [0, 0, 1, 0], 'acomp': ['100 main 7', '100|7 main', '7 100 main', '100 main 9']})
    pairs = pd.DataFrame({'qi': [0, 1, 2, 3], 'si': [0, 0, 0, 0]})
    p = np.array([0.9, 0.8, 0.9, 0.2])
    o = star_features(pairs, p, q, s1)
    assert np.allclose(o['num_corr'], [0.8, 0.9, 0.0, 0.0]) and np.allclose(o['num_frac'], [1, 1, 0, 0]), o
    assert o['n_sib_same'].tolist() == [1, 1, 0, 2] and o['n_sib_cross'].tolist() == [1, 1, 2, 1]
    perm = np.array([2, 0, 3, 1])                                        # row order does not change the output
    o2 = star_features(pairs.iloc[perm].reset_index(drop=True), p[perm], q, s1)
    assert np.allclose(o2.fillna(-9).values, o.fillna(-9).values[perm])
    print('ok')
