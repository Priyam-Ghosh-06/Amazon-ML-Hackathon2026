"""Paths, knobs and small shared helpers (logging, stage timing, atomic writes, stage cache).

Every path is derived from this file's location, so the project can be unzipped anywhere:
    <root>/code/business_entity_resolution/src/config.py  ->  <root> = parents[3]
Override any path with an environment variable (ER_DATA, ER_WORK, ER_WEIGHTS, ER_EVAL, ER_OUT).
"""
import os, json, time, pickle, contextlib
from pathlib import Path

os.environ.setdefault('PYTORCH_CUDA_ALLOC_CONF', 'expandable_segments:True')   # less GPU memory fragmentation
os.environ.setdefault('PYTORCH_ALLOC_CONF', 'expandable_segments:True')

ROOT = Path(__file__).resolve().parents[3]


def _path(env, default):
    return Path(os.environ.get(env, default)).resolve()


def _num(name, default):
    """Knob overridable from the environment as ER_<name> (used to shrink the run on Kaggle)."""
    return type(default)(os.environ.get(f'ER_{name}', default))


DATA = _path('ER_DATA', ROOT / 'data' / 'student_resource' / 'dataset')     # contains train/ and test/
WORK = _path('ER_WORK', ROOT / 'work')                                        # caches, feature memmaps
WEIGHTS = _path('ER_WEIGHTS', ROOT / 'weights')                               # model weights + learned tables
EVAL = _path('ER_EVAL', ROOT / 'eval')                                        # validation outputs + report
OUT = _path('ER_OUT', ROOT / 'output')                                        # test submission files
VALIDATOR = _path('ER_VALIDATOR', DATA.parent / 'utils' / 'validate_submission.py')

SMOKE = os.environ.get('ER_SMOKE') == '1'
N_PROC = int(os.environ.get('ER_PROCS', max(1, (os.cpu_count() or 4) - 1)))
SEED = 0

# ---- regions: search the FULL index, fit models on whole (country, state) buckets ----
TRAIN_FRAC, VAL_FRAC = _num('TRAIN_FRAC', 0.40), _num('VAL_FRAC', 0.12)       # share of train S1 whose buckets are used for fitting / validation

# ---- blocking ----
K_CHAR, K_DENSE = 6, 6                   # candidates kept per query from each channel (union ~8-10)
CHAR_MAX_DF, CHAR_MIN_DF = 0.05, 2       # char 3-grams in >5% of a country's S1 are dropped (scale-free pruning)
NAME_W = 0.5                             # char score = NAME_W * cos(name) + (1 - NAME_W) * cos(address)
Q_CHUNK = 200_000                        # queries per sparse product
STATE_MIN_AGREE = 0.99                   # state buckets are used for a country only if confident matches agree this often

# ---- bi-encoder (retrieval channel) ----
BIENC_MODEL = os.environ.get('ER_BIENC_MODEL', 'intfloat/multilingual-e5-small')   # MIT
BIENC_MAXLEN, BIENC_BATCH, BIENC_LR, BIENC_TEMP = 64, _num('BIENC_BATCH', 4096), 2e-5, 0.05   # 5e-5 drifted on T4
BIENC_EPOCHS, BIENC_MINUTES, BIENC_MAX_STEPS = 1, _num('BIENC_MINUTES', 30), None
ENC_BATCH = _num('ENC_BATCH', 4096)     # inference batch for encoding
SEARCH_CHUNK = 4096                      # queries per GPU similarity block

# ---- cross-encoder (matcher on the uncertain band) ----
CE_MODEL = os.environ.get('ER_CE_MODEL', 'intfloat/multilingual-e5-base')          # MIT
CE_MAXLEN, CE_BATCH, CE_LR = 128, _num('CE_BATCH', 128), 3e-5
CE_MINUTES, CE_MAX_STEPS = _num('CE_MINUTES', 30), None      # per fold model (two fold models)
CE_BAND = (0.02, 0.98)                   # stage-1 p range the cross-encoder scores
CE_MAX_TRAIN = 3_000_000                 # training edges per fold model (time cap usually binds first)
CE_SCORE_BATCH = _num('CE_SCORE_BATCH', 2048)   # inference only (v2 used 3 of 32 GB VRAM)
CE_VAL_EDGES = 20_000                    # fixed validation sample for checkpointing

# ---- checkpointing (both neural models) ----
BIENC_EVAL_EVERY, CE_EVAL_EVERY = 100, 500   # optimiser steps between validations
SAVE_AFTER = 0.30                        # no best.pt before 30% of planned steps (early loss drops fast)
MIN_REL_IMPROVE = 0.005                  # overwrite best.pt only on a >= 0.5% lower validation loss

# ---- GBDT ----
NF = 4                                   # OOF folds, grouped by the query's top-1 S1
GBDT_ROWS, GBDT_VAL_ROWS = _num('GBDT_ROWS', 3_000_000), 1_000_000
GBDT_PARAMS = dict(objective='binary', learning_rate=0.08, num_leaves=127, min_data_in_leaf=200, feature_fraction=0.8,
                   bagging_fraction=0.8, bagging_freq=1, lambda_l2=1.0, verbose=-1, seed=SEED,
                   num_threads=N_PROC)
GBDT_ROUNDS, GBDT_ES = 3000, 60
FEAT_CHUNK = 1_000_000                   # edges per feature-building chunk
SUB_CHUNK = 25_000                       # edges per worker task

# ---- stage E / decision ----
P_MIN = 0.01                             # edges below this p get no sibling features (cost bound)
SIB_TAU = 0.5                            # a sibling counts as a confident member at p >= SIB_TAU
TAUS = [round(t, 2) for t in [0.3, 0.35, 0.4, 0.45, 0.5, 0.55, 0.6, 0.65, 0.7, 0.75, 0.8, 0.85, 0.9]]
KMAX_EXACT = 40                          # larger S1 groups use only their top-40 edges in the exact E[F]

if SMOKE:                                # tiny run that exercises every code path in minutes, CPU is fine
    CHAR_MAX_DF, CHAR_MIN_DF = 1.0, 1
    BIENC_BATCH, BIENC_MINUTES, BIENC_MAX_STEPS, ENC_BATCH = 32, 3, 30, 256
    CE_BATCH, CE_MINUTES, CE_MAX_STEPS, CE_MAX_TRAIN, CE_SCORE_BATCH, CE_VAL_EDGES = 16, 3, 30, 2000, 64, 300
    BIENC_EVAL_EVERY = CE_EVAL_EVERY = 10
    GBDT_PARAMS.update(num_leaves=15, min_data_in_leaf=5)
    GBDT_ROUNDS, GBDT_ES = 200, 20
    FEAT_CHUNK, SUB_CHUNK = 20_000, 2_000


# ---- v3 (runs on top of the v2 caches; see v3.py) ----
WORK3, WEIGHTS3 = WORK / 'v3', WEIGHTS / 'v3'          # v3 never overwrites a v2 file
T0 = float(os.environ.get('ER_T0', time.time()))      # clock start (run_v3.sh exports it)
DEADLINE_MIN = _num('DEADLINE_MIN', 330.0)             # output files must be final by T0 + DEADLINE_MIN
RESERVE_MIN = 15.0                                     # always kept for assembly + validator
V3_GBDT_ROWS = _num('V3_GBDT_ROWS', 10_000_000)        # hard-negative-weighted training rows per GBDT
V3_HARD_P = 1e-3                                       # negatives with v2 p >= this are always kept ("hard")
MIN_EVAL_S1 = 200                                      # a country needs this many held-out S1 to be gated
if SMOKE:
    V3_GBDT_ROWS, MIN_EVAL_S1 = 200_000, 5


def left_min():
    """Minutes left before assembly must start."""
    return DEADLINE_MIN - RESERVE_MIN - (time.time() - T0) / 60


def affordable(est_min, what=''):
    """True when a stage estimated at est_min minutes (x1.3 safety) still ends before the reserve."""
    if SMOKE:
        est_min *= 0.02                                  # estimates are real-machine minutes; smoke data is tiny
    ok = left_min() > 1.3 * est_min
    if not ok:
        log(f'  SKIP {what}: needs ~{est_min:.0f} min x1.3, only {left_min():.0f} min left before the reserve')
    return ok


# ---------------------------------------------------------------- helpers
_T0 = time.time()


def log(*a):
    msg = time.strftime('%H:%M:%S') + f' [{(time.time() - _T0) / 60:6.1f}m] ' + ' '.join(str(x) for x in a)
    print(msg, flush=True)
    WORK.mkdir(parents=True, exist_ok=True)
    with open(WORK / 'run.log', 'a', encoding='utf-8') as f:
        f.write(msg + '\n')


@contextlib.contextmanager
def stage(name):
    """Log start/end of a pipeline stage and append its wall time to WORK/timings.json."""
    log(f'>> {name}')
    t = time.time()
    yield
    dt = time.time() - t
    log(f'<< {name}: {dt / 60:.1f} min')
    path = WORK / 'timings.json'
    tim = json.loads(path.read_text()) if path.exists() else {}
    tim[name] = round(dt / 60, 2)
    path.write_text(json.dumps(tim, indent=1))


def atomic(path, write):
    """write(tmp_path) then rename over path, so a crash never leaves a half-written file."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.tmp')
    write(tmp)
    os.replace(tmp, path)


def save_pickle(obj, path):
    atomic(path, lambda t: pickle.dump(obj, open(t, 'wb'), protocol=5))


def load_pickle(path):
    with open(path, 'rb') as f:
        return pickle.load(f)


def cached(name, fn, folder=None):
    """Run fn() once and keep its result in WORK/<name>.pkl (delete the file to recompute)."""
    path = (folder or WORK) / f'{name}.pkl'
    if path.exists():
        return load_pickle(path)
    obj = fn()
    save_pickle(obj, path)
    return obj
