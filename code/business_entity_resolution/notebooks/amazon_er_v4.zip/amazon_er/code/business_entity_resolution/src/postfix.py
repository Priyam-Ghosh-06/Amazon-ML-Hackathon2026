"""Post-fix on top of a FINISHED v3 run (reads work/v3 caches only; ~25-40 min on the v2 machine; no retraining).

SINGLETONS. An S1 with no true match scores 1.0 only if nothing is predicted for it, and 0 after one false merge.
A false merge onto a singleton almost always comes from ONE lone claimant (a decoy of that S1): no sibling records
exist to contradict it, and for a lone claimant the expected-F rule reduces to "accept if p > 0.5". So the post-fix
learns, per country, a separate threshold for LONE claimants (the only non-negligible edge into its S1).

EMPTY ADDRESSES. Queries with no address are 97.8% true matches in train (71.6% with an address): the decoys that
test has ~1.7x more of carry (shifted) addresses. v3's prior shift re-weights every query of a country by the same
odds factor, which wrongly deflates the empty-address ones. The post-fix can run the EM prior shift separately for
queries with and without an address (each stratum with its own CAL match rate).

Both are chosen per country on CAL with decoys replicated to the test density, and kept only if EVAL (held-out, same
density) improves and plain EVAL does not drop. France follows only if both US and India improved.
Result: variants 'B+' / 'C+' next to 'B' / 'C'; choice.json updated; then run `assemble`.
"""
import json
import numpy as np, pandas as pd
import config as C
import v3, decide

LONE_P = 0.05                                     # an edge into the same S1 below this is negligible
TAUS = [None, 0.5, 0.55, 0.6, 0.65, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95]
NONE = (None, None)                               # (per-stratum CAL match rates or None, lone threshold): unchanged


def _lone(qi, si, p):
    """Kept (query-best) edges that are the ONLY non-negligible kept edge into their S1."""
    b = decide.best_edges(qi, p)
    b = b[p[b] >= LONE_P]
    cnt = np.bincount(si[b], minlength=int(si.max()) + 1 if len(si) else 1)
    m = np.zeros(len(p), bool)
    m[b[cnt[si[b]] == 1]] = True
    return m


def _select(qi, si, p, rule, tau_lone):
    sel = decide.select(qi, si, p, rule)
    if tau_lone is None:
        return sel
    lone = _lone(qi, si, p)
    return np.where(lone, p >= tau_lone, sel)


def _emp(D):
    """Per edge: its query has no address at all."""
    return D['q']['acomp'].values[D['pairs']['qi'].values] == ''


def _pi0s(U, e, pf, pi0):
    """Match rate of the CAL best edges among queries with (False) and without (True) an address."""
    b = e[decide.best_edges(U['pairs']['qi'].values[e], pf[e])]
    out = {}
    for s in (False, True):
        bb = b[U['emp'][b] == s]
        out[s] = float(U['y'][bb].mean()) if len(bb) >= 50 else pi0
    return out


def _shift(qi, pc, pi0, emp, pi0s):
    """EM prior shift; with pi0s, run separately for queries with and without an address."""
    if pi0s is None:
        return v3._em_shift(qi, pc, pi0)[0]
    out = pc.copy()
    for s in (False, True):
        m = emp == s
        if m.any():
            out[m] = v3._em_shift(qi[m], pc[m], pi0s[s])[0]
    return out


def _prep(U, e, r, key, cfg, pf, rr, pi0s, seed=0):
    ex, nq = v3._replica(U, e, rr, seed)
    pc = v3._cal(r['iso'][key], pf[ex])
    if cfg[0]:
        pc = _shift(nq, pc, r['pi0'][key], U['emp'][ex], pi0s)
    return ex, nq, pc


def _score(U, ex, nq, pc, rule, tau, s1s):
    si, y = U['pairs']['si'].values[ex], U['y'][ex]
    sel = _select(nq, si, pc, rule, tau)
    return decide.f05_macro(si[sel], y[sel], U['truth'], s1s)[0]


def fix_variant(tag, U, T, pf, pt, r, shared):
    """Split prior shift and lone-claimant threshold per test country for one variant.
    Returns (eval scores, test selection, test calibrated p, chosen fix per country)."""
    tq, ts = T['pairs']['qi'].values, T['pairs']['si'].values
    test_c = sorted(set(T['ctry_e']))
    fix, ev = {}, {}
    for c in test_c:
        key = c if c in v3.LAB and len(v3.cidx(U, 'cal', c)) else '*'
        cfg = r['config'].get(c)
        if cfg is None:
            continue
        e = v3.cidx(U, 'cal', None if key == '*' else key)
        e = e[np.isfinite(pf[e])]
        if len(e) == 0:
            fix[c] = NONE
            continue
        pi0s = _pi0s(U, e, pf, r['pi0'][key])
        s1s = v3.s1_set(U, 'cal', None if key == '*' else key)
        f = {}
        for split in ((False, True) if cfg[0] else (False,)):      # the split only matters when the prior is on
            ex, nq, pc = _prep(U, e, r, key, cfg, pf, shared['r'][c], pi0s if split else None)
            si = U['pairs']['si'].values[ex]
            base, lone = decide.select(nq, si, pc, cfg[1]), _lone(nq, si, pc)   # the expensive part: once per split
            for t in TAUS:                                                       # == _select(..., t), cheaply
                f[split, t] = _f(U, ex, base if t is None else np.where(lone, pc >= t, base), s1s)
        best = max(f, key=lambda k: (f[k], k == (False, None)))    # ties keep the unchanged rule
        fix[c] = (pi0s if best[0] else None, best[1])
        C.log(f'  [{tag}+] {c}: on CAL x -> split prior={best[0]} (CAL match rate with/without address '
              f'{pi0s[False]:.3f}/{pi0s[True]:.3f}), lone threshold={best[1]} '
              f'(F {f[False, None]:.5f} -> {f[best]:.5f})')
    for c in v3.LAB:                                                         # held-out check
        if fix.get(c, NONE) == NONE:
            continue
        e = v3.cidx(U, 'eval', c)
        e = e[np.isfinite(pf[e])]
        s1s = v3.s1_set(U, 'eval', c)
        if len(s1s) < C.MIN_EVAL_S1:
            continue
        cfg, sc = r['config'][c], {}
        for name, rr in (('eval', 1.0), ('evalx', shared['r'][c])):
            sc[name] = (_score(U, *_prep(U, e, r, c, cfg, pf, rr, None, seed=1), cfg[1], None, s1s),
                        _score(U, *_prep(U, e, r, c, cfg, pf, rr, fix[c][0], seed=1), cfg[1], fix[c][1], s1s))
        ok = sc['evalx'][1] > sc['evalx'][0] and sc['eval'][1] >= sc['eval'][0] - 0.0005
        ev[c] = {'eval': sc['eval'][1], 'evalx': sc['evalx'][1], 'base_evalx': sc['evalx'][0], 'kept': ok}
        C.log(f'  [{tag}+] {c} EVAL: {sc["eval"][0]:.5f} -> {sc["eval"][1]:.5f} | at test density '
              f'{sc["evalx"][0]:.5f} -> {sc["evalx"][1]:.5f} -> {"KEEP" if ok else "reject"}')
        if not ok:
            fix[c] = NONE
    lab_ok = all(ev.get(c, {}).get('kept') for c in v3.LAB if c in ev) and bool(ev)
    for c in test_c:                                                         # unlabelled countries follow both
        if c not in v3.LAB and not lab_ok:
            fix[c] = NONE
    sel, pct = np.zeros(len(pt), bool), np.zeros(len(pt))
    for c in test_c:
        key = c if c in v3.LAB and len(v3.cidx(U, 'cal', c)) else '*'
        et = np.flatnonzero(T['ctry_e'] == c)
        prior, rule = r['config'][c]
        pi0s, tau = fix.get(c, NONE)
        pc = v3._cal(r['iso'][key], pt[et])
        if prior:
            pc = _shift(tq[et], pc, r['pi0'][key], T['emp'][et], pi0s)
        pct[et] = pc
        sel[et[_select(tq[et], ts[et], pc, rule, tau)]] = True
    return ev, sel, pct, fix


# ---------------------------------------------------------------- singleton filter
SING_TAUS = [None, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 0.98]
SING_PARAMS = dict(objective='binary', learning_rate=0.05, num_leaves=31, min_data_in_leaf=200,
                   feature_fraction=0.9, verbose=-1, seed=C.SEED)


def _s1_rows(qi, si, src, emp, p, sel):
    """One row per S1 with >= 1 selected edge, aggregating its non-negligible candidate edges: how many records claim
    it, from which sources, how sure each claim is, and how strongly each claimant is also pulled to another S1.
    A true entity has ~3.5 members spread over S2 and S3; a singleton is claimed only by its decoys."""
    o = np.lexsort((-p, qi))
    first = np.r_[True, qi[o][1:] != qi[o][:-1]]
    second = np.r_[False, ~first[1:] & first[:-1]]
    top, sec = np.zeros(int(qi.max()) + 1), np.zeros(int(qi.max()) + 1)
    top[qi[o][first]], sec[qi[o][second]] = p[o][first], p[o][second]
    m = (p >= LONE_P) | sel
    d = pd.DataFrame({'si': si[m], 'p': p[m], 'sel': sel[m], 's2': src[m] == 0, 'emp': emp[m],
                      'oth': np.where(p[m] >= top[qi[m]], sec[qi[m]], top[qi[m]])})   # claimant's best other S1
    d = d[d.si.isin(d.si[d.sel])].sort_values(['si', 'p'], ascending=[True, False])
    d['ps'], d['os'] = d.p.where(d.sel), d.oth.where(d.sel)
    d['s2s'], d['es'] = d.sel & d.s2, d.sel & d.emp
    g = d.groupby('si', sort=True)
    t = pd.DataFrame({'n_sel': g.sel.sum(), 'n_edge': g.size(), 'p_sum': g.p.sum(), 'p_max': g.p.max(),
                      'p_sel_min': g.ps.min(), 'n_s2_sel': g.s2s.sum(), 'n_emp_sel': g.es.sum(),
                      'oth_max': g.os.max(), 'oth_mean': g.os.mean()})
    t['p_2nd'] = d[g.cumcount().values == 1].set_index('si').p.reindex(t.index).fillna(0.0)
    t['n_s3_sel'] = t.n_sel - t.n_s2_sel
    t['n_src_sel'] = (t.n_s2_sel > 0).astype(int) + (t.n_s3_sel > 0)
    return t.astype(np.float32)


def _drop(si, sel, t, prob, tau):
    """Selection with every edge into an S1 flagged as a singleton (prob >= tau) removed."""
    if tau is None:
        return sel
    return sel & ~np.isin(si, t.index.values[prob >= tau])


def _f(U, ex, sel, s1s):
    si = U['pairs']['si'].values[ex]
    return decide.f05_macro(si[sel], U['y'][ex][sel], U['truth'], s1s)[0]


def singleton_step(tag, U, T, pf, r, shared, fix, sel_t, pct):
    """S1-level classifier 'this S1 has no true match', trained on CAL S1s that currently get >= 1 match (at test
    decoy density). Every match of an S1 it is sure about (prob >= tau, tau per country on out-of-fold CAL) is
    removed: an S1 predicted empty scores 1.0 if it is a singleton and 0 otherwise, so removal pays when the
    classifier is right more often than wrong. Kept per country only if EVAL improves (as for the other fixes)."""
    import lightgbm as lgb
    qi_u, si_u = U['pairs']['qi'].values, U['pairs']['si'].values
    src_u = U['q']['src'].values.astype(np.int64)
    single = np.bincount(U['truth'][U['truth'] >= 0], minlength=len(U['s1'])) == 0
    sel_on = lambda split, c, rr, seed: _sel_on(U, split, c, r, pf, rr, fix.get(c, NONE), seed)
    cal = {}
    for c in v3.LAB:
        if c not in r['config'] or len(v3.s1_set(U, 'cal', c)) < C.MIN_EVAL_S1:
            continue
        ex, nq, pc, sel = sel_on('cal', c, shared['r'].get(c, 1.0), 0)
        cal[c] = (ex, sel, _s1_rows(nq, si_u[ex], src_u[qi_u[ex]], U['emp'][ex], pc, sel))
    if not cal:
        return {}, sel_t, {}
    X = pd.concat([v[2] for v in cal.values()])
    y = single[X.index.values].astype(np.int8)
    cols = list(X.columns)
    fold = X.index.values % 4
    oof = np.zeros(len(X))
    for k in range(4):
        m = lgb.train(SING_PARAMS, lgb.Dataset(X.values[fold != k], y[fold != k], feature_name=cols), 300)
        oof[fold == k] = m.predict(X.values[fold == k])
    model = lgb.train(SING_PARAMS, lgb.Dataset(X.values, y, feature_name=cols), 300)
    C.log(f'  [{tag}+] singleton classifier: {len(X):,} CAL S1s with >= 1 match, {y.mean():.4f} of them singletons; '
          f'OOF precision at p>=0.9: {y[oof >= 0.9].mean() if (oof >= 0.9).any() else float("nan"):.3f} '
          f'({(oof >= 0.9).sum():,} flagged)')
    taus, fcal, a = {}, {}, 0
    for c, (ex, sel, t) in cal.items():
        pr = oof[a:a + len(t)]; a += len(t)
        s1s = v3.s1_set(U, 'cal', c)
        fcal[c] = {tau: _f(U, ex, _drop(si_u[ex], sel, t, pr, tau), s1s) for tau in SING_TAUS}
        taus[c] = max(SING_TAUS, key=lambda tau: (fcal[c][tau], tau is None))
        C.log(f'  [{tag}+] {c}: singleton threshold on CAL x (out-of-fold) -> {taus[c]} '
              f'(F {fcal[c][None]:.5f} -> {fcal[c][taus[c]]:.5f})')
    n = {c: len(v3.s1_set(U, 'cal', c)) for c in cal}
    tau_all = max(SING_TAUS, key=lambda tau: (sum(fcal[c][tau] * n[c] for c in cal), tau is None))
    ev = {}
    for c in cal:                                                            # held-out check
        s1s = v3.s1_set(U, 'eval', c)
        if taus[c] is None or len(s1s) < C.MIN_EVAL_S1:
            taus[c] = None
            continue
        sc = {}
        for name, rr in (('eval', 1.0), ('evalx', shared['r'].get(c, 1.0))):
            ex, nq, pc, sel = sel_on('eval', c, rr, 1)
            t = _s1_rows(nq, si_u[ex], src_u[qi_u[ex]], U['emp'][ex], pc, sel)
            pr = model.predict(t.values) if len(t) else np.zeros(0)
            sc[name] = (_f(U, ex, sel, s1s), _f(U, ex, _drop(si_u[ex], sel, t, pr, taus[c]), s1s))
        ok = sc['evalx'][1] > sc['evalx'][0] and sc['eval'][1] >= sc['eval'][0] - 0.0005
        ev[c] = {'eval': sc['eval'][1], 'evalx': sc['evalx'][1], 'base_evalx': sc['evalx'][0], 'kept': ok}
        C.log(f'  [{tag}+] {c} singleton filter EVAL: {sc["eval"][0]:.5f} -> {sc["eval"][1]:.5f} | at test density '
              f'{sc["evalx"][0]:.5f} -> {sc["evalx"][1]:.5f} -> {"KEEP" if ok else "reject"}')
        if not ok:
            taus[c] = None
    lab_ok = bool(ev) and all(v['kept'] for v in ev.values())
    tq, ts = T['pairs']['qi'].values, T['pairs']['si'].values
    src_t = T['q']['src'].values.astype(np.int64)
    sel_t = sel_t.copy()
    for c in sorted(set(T['ctry_e'])):
        tau = taus.get(c) if c in v3.LAB else (tau_all if lab_ok else None)
        taus[c] = tau
        if tau is None:
            continue
        et = np.flatnonzero(T['ctry_e'] == c)
        t = _s1_rows(tq[et], ts[et], src_t[tq[et]], T['emp'][et], pct[et], sel_t[et])
        pr = model.predict(t.values) if len(t) else np.zeros(0)
        sel_t[et] = _drop(ts[et], sel_t[et], t, pr, tau)
        C.log(f'  [{tag}+] {c} test: {int((pr >= tau).sum()):,} of {len(t):,} matched S1s emptied (threshold {tau})')
    return ev, sel_t, taus


def _sel_on(U, split, c, r, pf, rr, fx, seed):
    """Replicated edges of one labelled country's split, their calibrated (+shifted) p and the current selection."""
    cfg = r['config'][c]
    e = v3.cidx(U, split, c)
    e = e[np.isfinite(pf[e])]
    ex, nq, pc = _prep(U, e, r, c, cfg, pf, rr, fx[0], seed)
    return ex, nq, pc, _select(nq, U['pairs']['si'].values[ex], pc, cfg[1], fx[1])


def run_postfix():
    res = v3._load('results')
    if not res or not (v3.W3 / 'choice.json').exists():
        raise SystemExit('postfix needs a finished v3 run (work/v3/results.pkl and choice.json)')
    shared = res.pop('_shared', {})
    res.pop('_proxy', None)
    orig = v3.W3 / 'choice_v3.json'                  # the v3 run's own choice: every postfix run starts from it
    if not orig.exists():
        C.atomic(orig, lambda t: open(t, 'w').write((v3.W3 / 'choice.json').read_text()))
    choice = json.loads(orig.read_text())
    choice.pop('postfix', None)
    U, T = v3.train_universe(), v3.test_state()
    U['emp'], T['emp'] = _emp(U), _emp(T)
    C.log(f'  empty-address queries: train universe {U["emp"].mean():.4f} of edges, test {T["emp"].mean():.4f}')
    sources = {'B': lambda: (v3._load('p2_v2_heldout')[0], v3._load('p2_v2_test')), 'C': lambda: v3._load('p2_v3')}
    used = set(choice['countries'].values()) | {choice['unlabelled_countries']}
    upd = dict(choice['countries']), choice['unlabelled_countries']
    for tag in ('B', 'C'):
        if tag not in res or tag not in used:
            continue
        with C.stage(f'postfix: split prior + lone-claimant thresholds + singleton filter for variant {tag}'):
            pf, pt = sources[tag]()
            ev, sel, pct, fix = fix_variant(tag, U, T, pf, pt, res[tag], shared)
            ev2, sel, taus = singleton_step(tag, U, T, pf, res[tag], shared, fix, sel, pct)
            v3.save_variant(tag + '+', T, sel)
            changed = {c: fix.get(c, NONE) != NONE or taus.get(c) is not None for c in set(T['ctry_e'])}
            choice.setdefault('postfix', {})[tag] = {
                'fix': {c: {'split_prior_by_address': v[0], 'lone_tau': v[1]} for c, v in fix.items()},
                'eval': ev, 'singleton_taus': taus, 'singleton_eval': ev2, 'changed': changed,
                'test_stats': v3._test_stats(T, sel)}
            for c in v3.LAB:
                if upd[0].get(c) == tag and changed.get(c):
                    upd[0][c] = tag + '+'
            if upd[1] == tag and any(changed.get(c) for c in changed if c not in v3.LAB):
                upd = upd[0], tag + '+'
    choice['countries'], choice['unlabelled_countries'] = upd
    C.atomic(v3.W3 / 'choice.json', lambda t: open(t, 'w').write(json.dumps(choice, indent=1, default=str)))
    C.log(f'postfix: choice now {choice["countries"]}, unlabelled -> {choice["unlabelled_countries"]}')


NEEDED = ['results.pkl', 'choice.json', 'p2_v3.pkl', 'train_v0_pairs.pkl']


def run_check4():
    """Pre-flight for v4: the finished v3 state it runs on."""
    import shutil, psutil
    miss = [f for f in NEEDED if not (v3.W3 / f).exists() and not (f == 'choice.json' and (v3.W3 / 'choice_v3.json').exists())]
    miss += [str(p) for p in v3.missing_v2()]
    ok = not miss
    print('[PASS] v3 state present in ' + str(v3.W3) if ok else '[FAIL] missing:\n  ' + '\n  '.join(miss))
    res = v3._load('results') if (v3.W3 / 'results.pkl').exists() else {}
    has_c = 'C' in (res or {})
    print(f'[{"PASS" if has_c else "FAIL"}] v3 variant C finished (results.pkl has C: {has_c})')
    ram = psutil.virtual_memory().total / 2 ** 30
    print(f'[{"PASS" if ram >= 60 else "FAIL"}] RAM: {ram:.0f} GB')
    free = shutil.disk_usage(v3.W3).free / 2 ** 30 if v3.W3.exists() else 0
    print(f'[{"PASS" if free >= 5 else "FAIL"}] disk: {free:.0f} GB free (v4 writes < 1 GB)')
    print(f'[{"PASS" if C.VALIDATOR.exists() else "FAIL"}] validator: {C.VALIDATOR}')
    if not (ok and has_c and ram >= 60 and free >= 5 and C.VALIDATOR.exists()):
        raise SystemExit('\nv4 check FAILED')
    print('\nv4 check passed')


def run_smoke4():
    """smoke3 (v2 + v3 on tiny data), then postfix + assemble on top of it."""
    import os, sys, subprocess, time
    from pathlib import Path
    v3.run_smoke3()
    base = C.WORK / 'smoke'
    env = dict(os.environ, ER_SMOKE='1', ER_DATA=str(base / 'data'), ER_WORK=str(base / 'work'),
               ER_WEIGHTS=str(base / 'weights'), ER_EVAL=str(base / 'eval'), ER_OUT=str(base / 'output'),
               ER_VALIDATOR=str(C.VALIDATOR), ER_T0=str(time.time()), ER_DEADLINE_MIN='120')
    for cmd in ('postfix', 'postfix', 'assemble'):           # twice: a rerun must start from the v3 choice again
        r = subprocess.run([sys.executable, str(Path(__file__).resolve().parent / 'run.py'), cmd], env=env)
        if r.returncode != 0:
            raise SystemExit(f'smoke4 {cmd} FAILED (see {base / "work" / "run.log"})')
    print(f'\nsmoke4 passed: {base / "output"}')


if __name__ == '__main__':
    # split shift: an address-less stratum whose match rate did not move keeps its posteriors, while the one-rate
    # shift drags it down with the decoy-heavy addressed stratum
    rng = np.random.default_rng(0)
    post = lambda z, pi: 1 / (1 + np.exp(-(z * 4 + np.log(pi / (1 - pi)))))
    lab = lambda n, pi: rng.random(n) < pi
    ya, ye = lab(80000, 0.3), lab(5000, 0.97)                 # test: addressed 30% matched (70% at CAL), empty 97%
    z = np.r_[np.where(ya, rng.normal(2, 1, 80000), rng.normal(-2, 1, 80000)),
              np.where(ye, rng.normal(2, 1, 5000), rng.normal(-2, 1, 5000))]
    emp = np.r_[np.zeros(80000, bool), np.ones(5000, bool)]
    pi0s = {False: 0.7, True: 0.97}
    pc = np.where(emp, post(z, 0.97), post(z, 0.7))            # calibrated per stratum at CAL time
    qi = np.arange(len(z))
    split = _shift(qi, pc, 0.72, emp, pi0s)
    one = _shift(qi, pc, 0.72, emp, None)
    assert np.allclose(split[emp], post(z[emp], 0.97), atol=0.02)
    assert np.allclose(split[~emp], post(z[~emp], 0.3), atol=0.02)
    mid = emp & (split > 0.5) & (split < 0.95)                  # empty-address edges near the decision boundary
    assert mid.sum() > 20 and (one[mid] < split[mid] - 0.05).all()   # the one-rate shift deflates them
    # S1 table: S1 0 claimed by q0 (S2) and q1 (S3), S1 1 by the lone q2 which is also pulled to S1 0
    qi, si = np.array([0, 1, 2, 2]), np.array([0, 0, 1, 0])
    p, sel = np.array([0.9, 0.8, 0.6, 0.3]), np.array([True, True, True, False])
    t = _s1_rows(qi, si, np.array([0, 1, 0, 0]), np.array([False, False, True, True]), p, sel)   # per edge
    assert t.n_sel.tolist() == [2, 1] and t.n_edge.tolist() == [3, 1] and t.n_src_sel.tolist() == [2, 1]
    assert np.allclose(t.p_2nd, [0.8, 0]) and np.allclose(t.oth_max, [0, 0.3]) and t.n_emp_sel.tolist() == [0, 1]
    assert _drop(si, sel, t, np.array([0.1, 0.99]), 0.98).tolist() == [True, True, False, False]
    assert _drop(si, sel, t, np.array([0.1, 0.99]), None).tolist() == sel.tolist()
    print('ok')
