"""Pipeline v3: runs ON TOP OF the v2 caches and weights, under a hard deadline. v2 files are only ever read.

    Phase 0  install the v2 output as the fallback submission (a valid file exists from minute 1)
    Phase 1  V0 = the 46% of train S1 v2 never used (both countries): search its queries with the frozen v2
             models, score it and the test set with the v2 models, then the v3 DECISION LAYER:
               * per-country calibration of each query's best edge (fitted on held-out CAL buckets)
               * per-country prior-shift correction (EM on the test set's own predictions): test has ~1.7x more
                 decoys per true match than train, so v2 was over-confident on test
               * per-country rule (expected-F or a threshold) chosen on CAL with decoys replicated to test's rate
             -> variant B = v2 predictions + v3 decisions. Assembled into output/ if it beats v2 on EVAL.
    Phase 2  v3 MODELS: word tables with country-name folding and street-type canonicalisation, France
             label-free tables (lf.py), French legal forms, GBDT1/GBDT2 refitted on hard-negative-weighted rows
             (parallel folds), cross-encoder re-used (only new uncertain edges are scored)
             -> variant C. India-as-France check decides whether France may use its label-free tables.
    Gates    per country, the variant with the best F0.5 on EVAL x (held-out buckets, decoys replicated to the
             test rate) wins, provided plain EVAL does not drop; France follows US/India (+ the India check).
Every stage checks the clock (config.affordable); run_v3.sh kills the process before the reserve and then runs
`assemble`, which always writes a valid submission from the best finished variant (v2 at worst).
"""
import os, sys, json, shutil, subprocess, time
from pathlib import Path
import numpy as np, pandas as pd
import config as C

W3, K3 = C.WORK3, C.WEIGHTS3
LAB = ('US', 'India')                                   # countries with labels
RULES = [{'kind': 'expected_f'}] + [{'kind': 'tau', 'tau': t} for t in C.TAUS]
V2_WORK = ['train_records.pkl', 'train_pairs.pkl', 'train_p1.pkl', 'train_ce.pkl', 'train_states_on.pkl',
           'regions.pkl', 'test_records.pkl', 'test_pairs.pkl', 'test_p1.pkl', 'test_ce.pkl', 'test_states_on.pkl',
           'test_X1.f16', 'test_X1.cols.json']
V2_WEIGHTS = ['tables.pkl', 'decision.pkl', 'bienc/best.pt', 'ce_a/best.pt', 'ce_b/best.pt'] + \
             [f'gbdt{s}_fold{k}.txt' for s in (1, 2) for k in range(4)]


def missing_v2():
    m = [C.WORK / f for f in V2_WORK if not (C.WORK / f).exists()]
    m += [C.WEIGHTS / f for f in V2_WEIGHTS if not (C.WEIGHTS / f).exists()]
    have_out = (C.OUT / 'matching_results.tsv').exists() or (C.OUT / 'v2' / 'matching_results.tsv').exists()
    return m + ([] if have_out else [C.OUT / 'matching_results.tsv'])


def _save(obj, name):
    C.save_pickle(obj, W3 / f'{name}.pkl')


def _load(name):
    p = W3 / f'{name}.pkl'
    return C.load_pickle(p) if p.exists() else None


def cached3(name, fn):
    return C.cached(name, fn, folder=W3)


# ---------------------------------------------------------------- phase 0
def install_fallback():
    """Copy the v2 submission to output/v2/ once; output/ keeps the v2 files until a better variant is assembled."""
    bk = C.OUT / 'v2'
    bk.mkdir(parents=True, exist_ok=True)
    for f in ('matching_results.tsv', 'candidate_pairs.tsv'):
        if not (bk / f).exists():
            shutil.copy2(C.OUT / f, bk / f)
    C.log(f'  fallback: v2 submission backed up in {bk}')


# ---------------------------------------------------------------- the train universe (FIT / CAL / EVAL)
def train_universe():
    """All train queries with candidates: v2's cached candidates + V0 queries searched now with the frozen models.
    Splits (by the S1 of the query's top-1 candidate, whole buckets):
      fit  = v2's train region (GBDT training; v2's cached OOF p1 / cross-encoder scores align with it)
      cal  = v2's val region + half of the never-used buckets (calibration, early stopping, rule choice)
      eval = the other half of the never-used buckets (reporting and gating only)"""
    import run, blocking, features
    s1, q, truth = C.load_pickle(C.WORK / 'train_records.pkl')
    reg = C.load_pickle(C.WORK / 'regions.pkl')
    states_on = C.load_pickle(C.WORK / 'train_states_on.pkl')
    s1_key = run.region_key(s1)
    s1_reg = np.array([reg.get(b, 'none') for b in s1_key])
    q_bucket = run.bucket_of(q, states_on)
    qmask_v2 = np.array([b.endswith('|') or reg.get(b, 'train') != 'none' for b in q_bucket])

    def _v0():
        with C.stage('v3: V0 candidate search (frozen v2 models)'):
            idx = blocking.build_indexes(s1, sorted(set(q['country'])))
            m = ~qmask_v2
            C.log(f'  V0 queries to search: {m.sum():,}')
            return _block(s1, q, m, states_on, idx, 'train')
    pv0 = cached3('train_v0_pairs', _v0)
    pv2 = C.load_pickle(C.WORK / 'train_pairs.pkl')
    pairs = pd.concat([pv2, pv0], ignore_index=True)
    del pv2, pv0
    pairs = pairs.iloc[np.lexsort((pairs['si'].values, pairs['qi'].values))].reset_index(drop=True)
    qi, si = pairs['qi'].values, pairs['si'].values
    t1 = features.top1_mask(pairs)
    top1 = np.full(len(q), -1, np.int64); top1[qi[t1]] = si[t1]

    # S1 split: never-used buckets alternate cal / eval within each country (largest first)
    none_keys = pd.Series(s1_key[s1_reg == 'none']).value_counts()
    half = {}
    for c in sorted(set(k.split('|')[0] for k in none_keys.index)):
        ks = [k for k in none_keys.index if k.split('|')[0] == c]
        for i, k in enumerate(ks):
            half[k] = 'cal' if i % 2 == 0 else 'eval'
    s1_split = np.where(s1_reg == 'train', 'fit', np.where(s1_reg == 'val', 'cal',
                        np.array([half.get(k, 'x') for k in s1_key])))
    q_split = np.where(top1 >= 0, s1_split[np.maximum(top1, 0)], 'x')
    e_split = q_split[qi]
    in_v2 = qmask_v2[qi]
    e_split = np.where((e_split == 'fit') & ~in_v2, 'x', e_split)
    y = (truth[qi] == si).astype(np.int8)
    fold = (np.random.default_rng(1).permutation(len(s1))[top1[qi]] % C.NF).astype(np.int8)   # same folds as v2

    # v2's cached OOF p1 and cross-encoder scores are aligned with v2's kept edge set: rebuild it and check
    q_reg_v2 = np.where(top1 >= 0, s1_reg[np.maximum(top1, 0)], 'none')
    k2 = np.flatnonzero(in_v2 & np.isin(q_reg_v2[qi], ['train', 'val']))
    p1_v2, ce_v2 = C.load_pickle(C.WORK / 'train_p1.pkl'), C.load_pickle(C.WORK / 'train_ce.pkl')
    hard = np.full(len(pairs), np.nan, np.float32); ce_cache = np.full(len(pairs), np.nan, np.float32)
    if len(k2) == len(p1_v2) == len(ce_v2):
        hard[k2], ce_cache[k2] = p1_v2, ce_v2
        C.log(f'  v2 train caches aligned: {len(k2):,} edges')
    else:
        C.log(f'  WARNING: v2 train caches do not align ({len(k2):,} vs {len(p1_v2):,}); v3 samples uniformly')
    ctry_codes, ctry_names = pd.factorize(q['country'].values)
    s1_ctry = s1['country'].values
    U = dict(s1=s1, q=q, truth=truth, pairs=pairs, y=y, fold=fold, e_split=e_split, hard=hard, ce_cache=ce_cache,
             ctry_e=ctry_codes[qi].astype(np.int8), ctry_names=list(ctry_names), s1_split=s1_split, s1_ctry=s1_ctry,
             q_bucketed=q_bucket != np.array([c + '|' for c in q['country'].values]))
    for sp in ('fit', 'cal', 'eval', 'x'):
        U[f'{sp}_idx'] = np.flatnonzero(e_split == sp)
    C.log('  train universe: ' + ', '.join(f'{sp}={len(U[sp + "_idx"]):,} edges' for sp in ('fit', 'cal', 'eval', 'x')) +
          ' | held-out S1: ' + str(pd.crosstab(s1_split, s1_ctry).loc[['cal', 'eval']].to_dict('index')
                                   if {'cal', 'eval'} <= set(s1_split) else {}))
    return U


def _block(s1, q, qmask, states_on, idx, split):
    """Char + bi-encoder candidates for the queries in qmask (frozen v2 bi-encoder)."""
    import blocking, bienc
    grps = blocking.groups(s1, q, qmask, states_on)
    char = blocking.char_channel(s1, q, grps, idx)
    tok, model = bienc.load()
    dense = bienc.search(model, tok, s1, q, grps, char, C.WORK / f'{split}_s1_emb.npy')
    del model
    return blocking.merge(char, dense)


def graph(U):
    """Graph (search) features of every train-universe edge, computed once per process."""
    if 'G' not in U:
        import features
        U['G'] = features.graph_features(U['pairs'], features.s1_aux(U['s1']), U['q'], U['q_bucketed'])
    return U['G']


def cidx(U, split, country=None):
    e = U[f'{split}_idx']
    if country is None:
        return e
    code = U['ctry_names'].index(country) if country in U['ctry_names'] else -1
    return e[U['ctry_e'][e] == code]


def s1_set(U, split, country=None):
    m = U['s1_split'] == split
    if country is not None:
        m &= U['s1_ctry'] == country
    return np.flatnonzero(m)


# ---------------------------------------------------------------- test state
def test_state():
    s1, q, _ = C.load_pickle(C.WORK / 'test_records.pkl')
    pairs = C.load_pickle(C.WORK / 'test_pairs.pkl')
    states_on = C.load_pickle(C.WORK / 'test_states_on.pkl')
    import run
    qb = run.bucket_of(q, states_on) != np.array([c + '|' for c in q['country'].values])
    return dict(s1=s1, q=q, pairs=pairs, q_bucketed=qb, ctry_e=q['country'].values[pairs['qi'].values])


# ---------------------------------------------------------------- v2 predictions (phase 1)
def v2_heldout_p2(U):
    """v2's full model stack (v2 features, GBDT1, cross-encoder, sibling features, GBDT2) on CAL + EVAL edges."""
    import features, gbdt, crossenc, run
    ho = np.r_[U['cal_idx'], U['eval_idx']]
    ho.sort()
    P = U['pairs'].iloc[ho].reset_index(drop=True)
    tabs = C.load_pickle(C.WEIGHTS / 'tables.pkl')
    dec = C.load_pickle(C.WEIGHTS / 'decision.pkl')
    with C.stage('v3: v2 features on held-out buckets'):
        X, cols = features.build_X('ho_v2', P, graph(U).iloc[ho].reset_index(drop=True), U['s1'], U['q'],
                                   {'llr': tabs['llr'], 'alias': tabs['alias']}, folder=W3)
        assert cols == dec['cols'], 'v2 feature columns changed'
    with C.stage('v3: v2 models on held-out buckets'):
        allx = np.arange(len(P))
        p1 = gbdt.predict(gbdt.load(1), X, None, allx, fast=True)
        qi, si = P['qi'].values, P['si'].values
        band = np.flatnonzero(run.ce_mask(qi, p1))
        ce = np.full(len(P), np.nan, np.float32)
        cached_ce = U['ce_cache'][ho]
        have = band[np.isfinite(cached_ce[band])]
        ce[have] = cached_ce[have]
        new = band[~np.isfinite(cached_ce[band])]
        if dec['ce_models'] and len(new):
            ce[new] = crossenc.score(dec['ce_models'], U['q'], U['s1'], qi[new], si[new])
        C.log(f'  cross-encoder: {len(have):,} cached + {len(new):,} newly scored band edges')
        Z, _ = run.star_matrix(P, p1, ce, U['q'], U['s1'])
        p2 = gbdt.predict(gbdt.load(2), X, Z, allx, fast=True)
    out = np.full(len(U['pairs']), np.nan, np.float32)
    out[ho] = p2
    ce_full = U['ce_cache'].copy(); ce_full[ho] = np.where(np.isfinite(ce), ce, ce_full[ho])
    return out, ce_full


def v2_test_p2(T):
    """v2's stage-2 probability for every test edge (v2 cached p1, cross-encoder scores and features)."""
    import gbdt, run
    cols = json.loads((C.WORK / 'test_X1.cols.json').read_text())
    X = np.memmap(C.WORK / 'test_X1.f16', np.float16, 'r', shape=(len(T['pairs']), len(cols)))
    p1, ce = C.load_pickle(C.WORK / 'test_p1.pkl'), C.load_pickle(C.WORK / 'test_ce.pkl')
    Z, _ = run.star_matrix(T['pairs'], p1, ce, T['q'], T['s1'])
    return gbdt.predict(gbdt.load(2), X, Z, np.arange(len(T['pairs'])), fast=True)


# ---------------------------------------------------------------- decision layer
def _cal(iso, p):
    return np.asarray(p, np.float64) if iso is None else iso.predict(p).astype(np.float64)


def _em_shift(qi, pc, pi0):
    import decide
    b = decide.best_edges(qi, pc)
    pi = decide.em_prior(pc[b], pi0)
    return decide.shift(pc, pi, pi0), pi


def _f(qi, si, p, y, truth, s1s, rule):
    import decide
    sel = decide.select(qi, si, p, rule)
    return decide.f05_macro(si[sel], y[sel], truth, s1s)[0]


def _replica(U, e, r, seed=0):
    import decide
    qi = U['pairs']['qi'].values[e]
    idx, nq = decide.replicate_unmatched(qi, U['truth'][qi] < 0, r, seed)
    return e[idx], nq


def decision_layer(tag, U, p_full, T, p_test, shared):
    """Per-country calibration + prior shift + rule for one variant's probabilities. Returns scores, the chosen
    configuration per test country, and the test selection (bool per test edge)."""
    import decide
    qi, si, y, truth = U['pairs']['qi'].values, U['pairs']['si'].values, U['y'], U['truth']
    test_c = sorted(set(T['ctry_e']))
    iso, pi0 = {}, {}
    for c in list(LAB) + ['*']:
        e = cidx(U, 'cal', None if c == '*' else c)
        e = e[np.isfinite(p_full[e])]
        iso[c], pi0[c] = decide.fit_best_iso(qi[e], p_full[e], y[e]) if len(e) else (None, 0.5)
    key = {c: (c if c in LAB and len(cidx(U, 'cal', c)) else '*') for c in test_c}
    tq, ts = T['pairs']['qi'].values, T['pairs']['si'].values
    pi_t, r = {}, {}
    for c in test_c:
        et = np.flatnonzero(T['ctry_e'] == c)
        _, pi_t[c] = _em_shift(tq[et], _cal(iso[key[c]], p_test[et]), pi0[key[c]])
        r[c] = decide.decoy_ratio(pi_t[c], pi0[key[c]])
    if not shared.get('r'):
        shared['r'] = {c: float(np.clip(r[c], 0.5, 4.0)) for c in test_c}
        C.log(f'  test decoy density vs calibration (x unmatched per matched), from variant {tag}: ' +
              ', '.join(f'{c} {shared["r"][c]:.2f}' for c in test_c))
    res = {'tag': tag, 'config': {}, 'eval': {}, 'pi': {c: (pi0[key[c]], pi_t[c]) for c in test_c},
           'iso': iso, 'pi0': pi0}

    for c in test_c:                                    # rule + prior on/off, chosen on CAL x (test decoy density)
        e = cidx(U, 'cal', None if key[c] == '*' else key[c])
        e = e[np.isfinite(p_full[e])]
        if len(e) == 0:
            res['config'][c] = (False, {'kind': 'expected_f'})
            continue
        ex, nq = _replica(U, e, shared['r'][c])
        pc = _cal(iso[key[c]], p_full[ex])
        s1s = s1_set(U, 'cal', None if key[c] == '*' else key[c])
        best = None
        for prior in (False, True):
            pp = _em_shift(nq, pc, pi0[key[c]])[0] if prior else pc
            b = decide.best_edges(nq, pp)
            for rule in RULES:
                if rule['kind'] == 'tau':
                    sb = b[pp[b] >= rule['tau']]
                    f = decide.f05_macro(si[ex][sb], y[ex][sb], truth, s1s)[0]
                else:
                    f = _f(nq, si[ex], pp, y[ex], truth, s1s, rule)
                if best is None or f > best[0] + 1e-9:
                    best = (f, prior, rule)
        res['config'][c] = (best[1], best[2])
        C.log(f'  [{tag}] {c}: rule on CAL x -> prior={"on" if best[1] else "off"} {best[2]} (F={best[0]:.5f})')

    for c in LAB:                                       # held-out scores (plain and at the test decoy density)
        e = cidx(U, 'eval', c)
        e = e[np.isfinite(p_full[e])]
        s1s = s1_set(U, 'eval', c)
        if len(s1s) < C.MIN_EVAL_S1 or c not in res['config']:
            continue
        prior, rule = res['config'][c]
        sc = {}
        for name, rr in (('eval', 1.0), ('evalx', shared['r'][c])):
            ex, nq = _replica(U, e, rr, seed=1)
            pc = _cal(iso[key[c]], p_full[ex])
            if prior:
                pc = _em_shift(nq, pc, pi0[key[c]])[0]
            sc[name] = _f(nq, si[ex], pc, y[ex], truth, s1s, rule)
        res['eval'][c] = sc
        C.log(f'  [{tag}] {c} EVAL: F0.5={sc["eval"]:.5f} | at test decoy density: {sc["evalx"]:.5f}')

    sel = np.zeros(len(p_test), bool)                  # test decisions
    for c in test_c:
        et = np.flatnonzero(T['ctry_e'] == c)
        prior, rule = res['config'][c]
        pc = _cal(iso[key[c]], p_test[et])
        if prior:
            pc = _em_shift(tq[et], pc, pi0[key[c]])[0]
        sel[et[decide.select(tq[et], ts[et], pc, rule)]] = True
    res['test_stats'] = _test_stats(T, sel)
    return res, sel


def v2_asis_scores(U, p_full, shared):
    """v2 exactly as submitted (v2 isotonic + v2 rule) on the same held-out edges, for the gates."""
    dec = C.load_pickle(C.WEIGHTS / 'decision.pkl')
    qi, si, y, truth = U['pairs']['qi'].values, U['pairs']['si'].values, U['y'], U['truth']
    out = {'tag': 'A', 'eval': {}}
    for c in LAB:
        e = cidx(U, 'eval', c)
        e = e[np.isfinite(p_full[e])]
        s1s = s1_set(U, 'eval', c)
        if len(s1s) < C.MIN_EVAL_S1:
            continue
        sc = {}
        for name, rr in (('eval', 1.0), ('evalx', shared['r'].get(c, 1.0))):
            ex, nq = _replica(U, e, rr, seed=1)
            sc[name] = _f(nq, si[ex], dec['iso'].predict(p_full[ex]), y[ex], truth, s1s, dec['rule'])
        out['eval'][c] = sc
        C.log(f'  [A = v2 as submitted] {c} EVAL: F0.5={sc["eval"]:.5f} | at test decoy density: {sc["evalx"]:.5f}')
    return out


def _test_stats(T, sel):
    si = T['pairs']['si'].values
    cnt = np.bincount(si[sel], minlength=len(T['s1']))
    df = pd.DataFrame({'c': T['s1']['country'].values, 'n': cnt})
    return {c: {'matches_per_S1': round(float(g.n.mean()), 4), 'empty_share': round(float((g.n == 0).mean()), 4)}
            for c, g in df.groupby('c')}


def save_variant(tag, T, sel):
    """Matched (S1 id, record id) pairs of a variant, for `assemble`."""
    qi, si = T['pairs']['qi'].values[sel], T['pairs']['si'].values[sel]
    df = pd.DataFrame({'s1': T['s1']['entity_id'].values[si], 'q': T['q']['entity_id'].values[qi]})
    _save(df, f'test_matches_{tag}')


# ---------------------------------------------------------------- gates + assembly
def choose(results, proxy_ok):
    """Per labelled country: the variant with the best F at the test decoy density, as long as plain EVAL does
    not drop by more than 0.001 against v2. France (no labels) follows the variants that won in BOTH US and India."""
    base = results.get('A', {}).get('eval', {})
    pick = {}
    for c in LAB:
        cands = [('A', base.get(c))] + [(t, results[t]['eval'].get(c)) for t in ('B', 'C') if t in results]
        cands = [(t, s) for t, s in cands if s]
        if not cands:
            pick[c] = 'A'
            continue
        ok = [(t, s) for t, s in cands if not base.get(c) or s['eval'] >= base[c]['eval'] - 0.001]
        pick[c] = max(ok or cands, key=lambda ts: ts[1]['evalx'])[0]
    lab = [c for c in LAB if base.get(c)]
    beats = lambda t, u: bool(lab) and all(results.get(t, {}).get('eval', {}).get(c, {}).get('evalx', -1) >
                                           results.get(u, {}).get('eval', {}).get(c, {}).get('evalx', 2) for c in lab)
    if proxy_ok and beats('C', 'B') and beats('C', 'A'):
        fr = 'C'
    elif beats('B', 'A'):
        fr = 'B'
    else:
        fr = 'A'
    return pick, fr


def write_choice(results, proxy):
    pick, fr = choose(results, bool(proxy and proxy.get('pass')))
    choice = {'countries': pick, 'unlabelled_countries': fr, 'proxy': proxy,
              'scores': {t: r.get('eval', {}) for t, r in results.items()},
              'configs': {t: {c: [bool(v[0]), v[1]] for c, v in r.get('config', {}).items()} for t, r in results.items()},
              'test_stats': {t: r.get('test_stats') for t, r in results.items() if r.get('test_stats')},
              'priors': {t: r.get('pi') for t, r in results.items() if r.get('pi')}}
    C.atomic(W3 / 'choice.json', lambda t: open(t, 'w').write(json.dumps(choice, indent=1, default=str)))
    C.log(f'  choice: {pick}, unlabelled countries -> {fr}')
    return choice


def run_assemble():
    """Final submission from the chosen variant per country (v2 for anything not decided). Fast (~1-2 min)."""
    import run, text
    bk = C.OUT / 'v2'
    if not (bk / 'matching_results.tsv').exists():
        C.log('assemble: no v2 backup found; leaving output/ as it is')
        return
    choice = json.loads((W3 / 'choice.json').read_text()) if (W3 / 'choice.json').exists() else {}
    t1 = text.read_tsv(C.DATA / 'test' / 'test_source1.tsv')[['entity_id', 'country']]
    v2m = text.read_tsv(bk / 'matching_results.tsv').set_index('source1_entity_id')['matched_entity_ids']
    pick = choice.get('countries', {})
    variant = {c: pick.get(c, choice.get('unlabelled_countries', 'A')) for c in set(t1.country)}
    lists = {}
    for tag in set(variant.values()) - {'A'}:
        df = _load(f'test_matches_{tag}')
        if df is None:
            C.log(f'  assemble: variant {tag} missing -> v2 for its countries')
            variant = {c: ('A' if v == tag else v) for c, v in variant.items()}
            continue
        lists[tag] = df.groupby('s1')['q'].agg(','.join)
    rows = [v2m.get(s, '') if variant[c] == 'A' else lists[variant[c]].get(s, '')
            for s, c in zip(t1.entity_id.values, t1.country.values)]
    out = pd.DataFrame({'source1_entity_id': t1.entity_id.values, 'matched_entity_ids': rows})
    C.atomic(C.OUT / 'matching_results.tsv',
             lambda t: out.to_csv(t, sep='\t', index=False, quoting=3, lineterminator='\n'))
    shutil.copy2(bk / 'candidate_pairs.tsv', C.OUT / 'candidate_pairs.tsv')
    C.log(f'assemble: variant per country {variant}; matches={sum(len(r.split(",")) for r in rows if r):,}')
    try:
        run.validate(C.DATA / 'test')
    except SystemExit:
        C.log('assemble: validator FAILED on the v3 file -> restoring the v2 submission')
        for f in ('matching_results.tsv', 'candidate_pairs.tsv'):
            shutil.copy2(bk / f, C.OUT / f)
        run.validate(C.DATA / 'test')


# ---------------------------------------------------------------- phase 2: v3 models
def tables_v3(U, T):
    import features, text, lf
    tabs2 = C.load_pickle(C.WEIGHTS / 'tables.pkl')
    q, s1, qi, si, y, truth = U['q'], U['s1'], U['pairs']['qi'].values, U['pairs']['si'].values, U['y'], U['truth']
    fit = U['fit_idx']
    rng = np.random.default_rng(C.SEED)
    t1 = features.top1_mask(U['pairs'])
    cc = np.nan_to_num(U['pairs']['char_cos'].values)

    def truth_table(country=None):
        e = fit if country is None else fit[q['country'].values[qi[fit]] == country]
        dec = e[(truth[qi[e]] < 0) & t1[e] & (cc[e] >= 0.5)]
        pos = e[y[e] == 1]
        pos = rng.choice(pos, min(len(pos), 2_000_000), replace=False)
        ee = np.r_[pos, dec]
        return features.learn_llr(q, s1, qi[ee], si[ee], np.r_[np.ones(len(pos)), np.zeros(len(dec))].astype(int), v3=True), pos
    llr_all, _ = truth_table()
    llr_us, pos_us = truth_table('US')
    alias_us = text.learn_place_aliases(q['acomp'].values[qi[pos_us[:300_000]]], s1['acomp'].values[si[pos_us[:300_000]]])
    tq = T['q']
    fr_q = np.flatnonzero(tq['country'].values == 'France')
    fr_s = np.flatnonzero(T['s1']['country'].values == 'France')
    llr_fr, alias_fr = lf.tables(T['s1'], tq, fr_q, fr_s, 'France (test, label-free)')
    in_q = np.flatnonzero((q['country'].values == 'India') & np.isin(np.arange(len(q)), qi[np.r_[fit, U['cal_idx']]]))
    llr_in, alias_in = lf.tables(s1, q, in_q, np.flatnonzero(s1['country'].values == 'India'), 'India (for the France check)')
    merge = lambda base, over: {k: {**base[k], **over[k]} for k in base}
    base = {'v3': True, 'legal': text.LEGAL3}
    T3 = {**base, 'alias': set(tabs2['alias']) | alias_fr,
          'llr_by_country': {'*': llr_all, 'France': merge(llr_all, llr_fr)}}
    # India-as-France: India scored as if unlabelled (US-only tables +/- India's label-free tables)
    proxy = {'lf': {**base, 'alias': alias_us | alias_in, 'llr_by_country': {'*': merge(llr_us, llr_in)}},
             'none': {**base, 'alias': alias_us, 'llr_by_country': {'*': llr_us}}}
    return T3, proxy


def run_models_v3(U, T, T3):
    """X3 features, GBDT1, cross-encoder on new band edges, sibling features, GBDT2 -> p2 (train universe, test)."""
    import features, gbdt, crossenc, run
    q, s1, pairs = U['q'], U['s1'], U['pairs']
    qi, si = pairs['qi'].values, pairs['si'].values
    dec = C.load_pickle(C.WEIGHTS / 'decision.pkl')
    with C.stage('v3: features (train universe + test)'):
        X, cols = features.build_X('train3', pairs, graph(U), s1, q, T3, folder=W3)
        Gt = features.graph_features(T['pairs'], features.s1_aux(T['s1']), T['q'], T['q_bucketed'])
        Xt, _ = features.build_X('test3', T['pairs'], Gt, T['s1'], T['q'], T3, folder=W3)
        del Gt
    fit, cal = U['fit_idx'], U['cal_idx']
    rest = np.flatnonzero(U['e_split'] != 'fit')
    hard1 = np.where(np.isfinite(U['hard']), U['hard'], 1.0)       # unknown hardness -> keep the row
    with C.stage('v3: GBDT1'):
        def _p1():
            p, models = gbdt.run_stage3(1, X, None, U['y'], U['fold'], fit, cal, cols, hard1, K3)
            full = np.full(len(pairs), np.nan, np.float32)
            full[fit], full[rest] = p, gbdt.predict(models, X, None, rest, fast=True)
            return full, gbdt.predict(models, Xt, None, np.arange(len(T['pairs'])), fast=True)
        p1, p1t = cached3('p1_v3', _p1)
    with C.stage('v3: cross-encoder on new uncertain edges'):
        def _ce():
            ce = U['ce_cache'].copy()
            band = run.ce_mask(qi, p1)
            ce[~band] = np.nan
            need = np.flatnonzero(band & ~np.isfinite(U['ce_cache']))
            fo = U['fold'][need]
            fitm = U['e_split'][need] == 'fit'
            for names, m in ((['ce_b'], fitm & (fo < 2)), (['ce_a'], fitm & (fo >= 2)), (dec['ce_models'], ~fitm)):
                e = need[m]
                if dec['ce_models'] and len(e):
                    ce[e] = crossenc.score(names, q, s1, qi[e], si[e])
            tce = C.load_pickle(C.WORK / 'test_ce.pkl').copy()
            tq, ts = T['pairs']['qi'].values, T['pairs']['si'].values
            tb = run.ce_mask(tq, p1t)
            tn = np.flatnonzero(tb & ~np.isfinite(tce))
            if dec['ce_models'] and len(tn):
                tce[tn] = crossenc.score(dec['ce_models'], T['q'], T['s1'], tq[tn], ts[tn])
            tce[~tb] = np.nan
            C.log(f'  cross-encoder: newly scored train={len(need):,} test={len(tn):,}')
            return ce, tce
        ce, cet = cached3('ce_v3', _ce)
    with C.stage('v3: sibling features + GBDT2'):
        def _p2():
            Z, zcols = run.star_matrix(pairs, p1, ce, q, s1)
            Zt, _ = run.star_matrix(T['pairs'], p1t, cet, T['q'], T['s1'])
            hard2 = np.where(np.isfinite(p1), p1, 1.0)
            p, models = gbdt.run_stage3(2, X, Z, U['y'], U['fold'], fit, cal, cols + zcols, hard2, K3)
            full = np.full(len(pairs), np.nan, np.float32)
            full[fit], full[rest] = p, gbdt.predict(models, X, Z, rest, fast=True)
            return full, gbdt.predict(models, Xt, Zt, np.arange(len(T['pairs'])), fast=True)
        p2, p2t = cached3('p2_v3', _p2)
    return p2, p2t, (X, cols)


def india_proxy(U, proxy_tabs, res_c):
    """India scored as if it had no labels, like France: v3 models with (a) India's own truth tables, (b) US-only
    tables + India's label-free tables, (c) US-only tables. France may use its label-free tables only if (b) >= (c)."""
    import features, gbdt, crossenc, run, decide
    if 'India' not in res_c['config'] or 'India' not in U['ctry_names']:
        return None
    e = cidx(U, 'eval', 'India')
    if len(s1_set(U, 'eval', 'India')) < C.MIN_EVAL_S1:
        return None
    P = U['pairs'].iloc[e].reset_index(drop=True)
    qi, si = P['qi'].values, P['si'].values
    G = graph(U).iloc[e].reset_index(drop=True)
    m1, m2 = gbdt.load3(1, K3), gbdt.load3(2, K3)
    dec = C.load_pickle(C.WEIGHTS / 'decision.pkl')
    ce_cache = _load('ce_v3')[0][e]
    prior, rule = res_c['config']['India']
    s1s = s1_set(U, 'eval', 'India')
    f = {}
    for name, tabs in (('lf', proxy_tabs['lf']), ('none', proxy_tabs['none'])):
        X, cols = features.build_X(f'proxy_{name}', P, G, U['s1'], U['q'], tabs, folder=W3)
        allx = np.arange(len(P))
        p1 = gbdt.predict(m1, X, None, allx, fast=True)
        band = run.ce_mask(qi, p1)
        ce = np.where(band, ce_cache, np.nan).astype(np.float32)
        new = np.flatnonzero(band & ~np.isfinite(ce))
        if dec['ce_models'] and len(new):
            ce[new] = crossenc.score(dec['ce_models'], U['q'], U['s1'], qi[new], si[new])
        Z, _ = run.star_matrix(P, p1, ce, U['q'], U['s1'])
        p2 = gbdt.predict(m2, X, Z, allx, fast=True)
        pc = _cal(res_c['iso']['India'], p2)                  # India's calibration from CAL (variant C)
        if prior:
            pc = _em_shift(qi, pc, res_c['pi0']['India'])[0]
        f[name] = _f(qi, si, pc, U['y'][e], U['truth'], s1s, rule)
    out = {'F_india_own_tables': res_c['eval']['India']['eval'], 'F_label_free': f['lf'], 'F_no_word_tables': f['none'],
           'pass': f['lf'] >= f['none']}
    C.log(f'  India-as-France check: own tables {out["F_india_own_tables"]:.5f} | label-free {f["lf"]:.5f} | '
          f'no word tables {f["none"]:.5f} -> France label-free tables {"ALLOWED" if out["pass"] else "NOT allowed"}')
    return out


# ---------------------------------------------------------------- main
def run_v3():
    for d in (W3, K3):
        d.mkdir(parents=True, exist_ok=True)
    miss = missing_v2()
    if miss:
        raise SystemExit('v3 needs the v2 caches; missing:\n' + '\n'.join(map(str, miss)))
    C.log(f'==== v3 start: {C.left_min():.0f} min until the assembly reserve ({C.RESERVE_MIN:.0f} min) ====')
    install_fallback()
    results = _load('results') or {}
    shared = results.pop('_shared', {})

    def persist():
        _save({**results, '_shared': shared}, 'results')

    U = train_universe()
    T = test_state()
    # ---------------- phase 1: v2 predictions + v3 decision layer
    if 'B' not in results and C.affordable(40, 'phase 1'):
        with C.stage('v3: phase 1 (v2 predictions, v3 decision layer)'):
            p_ho, ce_full = cached3('p2_v2_heldout', lambda: v2_heldout_p2(U))
            U['ce_cache'] = ce_full
            p_te = cached3('p2_v2_test', lambda: v2_test_p2(T))
            dec = C.load_pickle(C.WEIGHTS / 'decision.pkl')
            import decide
            v2sel = decide.select(T['pairs']['qi'].values, T['pairs']['si'].values, dec['iso'].predict(p_te), dec['rule'])
            import text
            sub = text.read_tsv(C.OUT / 'v2' / 'matching_results.tsv')['matched_entity_ids']
            n_sub = int(sub.str.len().gt(0).sum() + sub.str.count(','). sum())
            C.log(f'  check: v2 re-scored from caches = {v2sel.sum():,} matches; submitted v2 file = {n_sub:,} '
                  f'({"caches intact" if abs(n_sub - v2sel.sum()) <= 0.001 * max(n_sub, 1) else "MISMATCH: v2 caches differ from the submitted run"})')
            rb, selb = decision_layer('B', U, p_ho, T, p_te, shared)
            results['A'] = v2_asis_scores(U, p_ho, shared)
            results['B'] = rb
            save_variant('B', T, selb)
            persist()
        write_choice(results, None)
        run_assemble()
    elif 'B' in results:
        U['ce_cache'] = (_load('p2_v2_heldout') or (None, U['ce_cache']))[1]
    # ---------------- phase 2: v3 models
    if 'C' not in results and C.affordable(110, 'phase 2 (v3 models)'):
        with C.stage('v3: phase 2 tables'):
            T3, proxy_tabs = cached3('tables_v3', lambda: tables_v3(U, T))
        p2, p2t, _ = run_models_v3(U, T, T3)
        with C.stage('v3: phase 2 decision layer'):
            rc, selc = decision_layer('C', U, p2, T, p2t, shared)
            save_variant('C', T, selc)
            results['C'] = rc
            persist()
        proxy = None
        if C.affordable(15, 'India-as-France check'):
            with C.stage('v3: India-as-France check'):
                proxy = india_proxy(U, proxy_tabs, rc)
        results['_proxy'] = proxy
        persist()
    proxy = results.pop('_proxy', None)
    write_choice(results, proxy)
    report(results, proxy)
    run_assemble()
    C.log(f'==== v3 done: {C.left_min():.0f} min to spare before the reserve ====')


def report(results, proxy):
    L = ['# v3 report', '', 'F0.5 on held-out buckets (EVAL: never used for fitting, calibration or rule choice).',
         '"at test density" = unmatched records replicated to the decoy rate estimated on test.', '',
         '| variant | country | EVAL F0.5 | at test density |', '|---|---|---|---|']
    names = {'A': 'A: v2 as submitted', 'B': 'B: v2 models + v3 decisions', 'C': 'C: v3 models + v3 decisions'}
    for t in ('A', 'B', 'C'):
        for c, s in results.get(t, {}).get('eval', {}).items():
            L.append(f'| {names[t]} | {c} | {s["eval"]:.5f} | {s["evalx"]:.5f} |')
    L += ['', '## Test statistics per variant (matches per S1, share of S1 left empty)', '']
    for t in ('B', 'C'):
        if results.get(t, {}).get('test_stats'):
            L.append(f'- {names[t]}: {json.dumps(results[t]["test_stats"])}')
    L += ['', f'India-as-France check: {json.dumps(proxy)}', '',
          f'Choice: {(W3 / "choice.json").read_text() if (W3 / "choice.json").exists() else "-"}']
    text = '\n'.join(L) + '\n'
    C.atomic(C.EVAL / 'report_v3.md', lambda t: open(t, 'w', encoding='utf-8').write(text))
    C.log('\n' + text)


def run_check3():
    """Pre-flight for v3 (before starting the clock)."""
    import run, psutil, torch
    miss = missing_v2()
    print('[PASS] v2 caches and weights present' if not miss else '[FAIL] missing v2 files:\n  ' + '\n  '.join(map(str, miss)))
    free = shutil.disk_usage(C.WORK).free / 2 ** 30
    print(f'[{"PASS" if free >= 45 else "FAIL"}] disk: {free:.0f} GB free (v3 writes ~40 GB of new caches)')
    ram = psutil.virtual_memory().total / 2 ** 30
    print(f'[{"PASS" if ram >= 60 else "FAIL"}] RAM: {ram:.0f} GB')
    print(f'[{"PASS" if torch.cuda.is_available() else "FAIL"}] GPU: '
          f'{torch.cuda.get_device_name(0) if torch.cuda.is_available() else "none"}')
    print(f'[{"PASS" if C.VALIDATOR.exists() else "FAIL"}] validator: {C.VALIDATOR}')
    ok = not miss and free >= 45 and ram >= 60 and torch.cuda.is_available() and C.VALIDATOR.exists()
    if not ok:
        raise SystemExit('\nv3 check FAILED')
    print('\nv3 check passed')


def run_smoke3():
    """v2 smoke (builds a v2 state like the one on the real machine) + v3 on top of it + assemble."""
    import run
    run.run_smoke()
    base = C.WORK / 'smoke'
    env = dict(os.environ, ER_SMOKE='1', ER_DATA=str(base / 'data'), ER_WORK=str(base / 'work'),
               ER_WEIGHTS=str(base / 'weights'), ER_EVAL=str(base / 'eval'), ER_OUT=str(base / 'output'),
               ER_VALIDATOR=str(C.VALIDATOR), ER_T0=str(time.time()), ER_DEADLINE_MIN='120')
    for cmd in ('v3', 'assemble'):
        r = subprocess.run([sys.executable, str(Path(__file__).resolve().parent / 'run.py'), cmd], env=env)
        if r.returncode != 0:
            raise SystemExit(f'smoke3 {cmd} FAILED (see {base / "work" / "run.log"})')
    print(f'\nsmoke3 passed: {base / "output"}, report {base / "eval" / "report_v3.md"}')
