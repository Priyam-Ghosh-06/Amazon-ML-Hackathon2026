"""Stage A: read the raw TSVs, normalise, split addresses into components, and learn the lookup tables
(Indic->Latin token dictionary, state vocabulary + aliases, place aliases) from training data only.

Rule: hard-code only rewrites that are pure noise (case, accents, punctuation, dotted acronyms, zero padding,
NULL pieces, web domains). Anything a decoy could use (numbers, legal forms, modifiers) stays visible and is
priced later by learned features.
"""
import re, unicodedata, collections, multiprocessing as mp
import numpy as np, pandas as pd, regex as rx
import config as C

_latin_marks = rx.compile(r'(?<=\p{Latin})\p{Mn}+')     # strip accents on Latin letters only; Indic matras survive
_nonword = rx.compile(r'[^\p{L}\p{M}\p{N}]+')
_nonlatin = rx.compile(r'(?!\p{Latin})\p{L}')
_acronym = rx.compile(r'\b(?:\p{L}\.){2,}')               # L.L.C. -> LLC, S.A.R.L -> SARL
_domain = re.compile(r'\bwww\.|\.(?:com|net|org|co|in|biz|info|us|fr|io)\b', re.I)
_zeropad = re.compile(r'(?<!\d)0+(?=\d)')                  # 007168 -> 7168
_half = re.compile(r'\b1/2\b')                             # "824 1/2 West St": the fraction is not a number
_ocr = [(re.compile(r'(?<=[a-z])1(?=[a-z])'), 'l'), (re.compile(r'(?<=[a-z])0(?=[a-z])'), 'o')]   # Ta1ent -> talent
_digit = re.compile(r'\d')
_num = re.compile(r'(\d+)([a-z]{0,2})\b')
NULLS = {'', 'null', 'n a', 'na', 'none', 'nan'}
SEP = '|'                                                 # component separator inside `acomp`

LEGAL = {'llc': 'llc', 'inc': 'inc', 'incorporated': 'inc', 'corp': 'corp', 'corporation': 'corp', 'co': 'co',
         'company': 'co', 'ltd': 'ltd', 'limited': 'ltd', 'pvt': 'pvt', 'private': 'pvt', 'llp': 'llp', 'lp': 'lp',
         'pllc': 'pllc', 'pc': 'pc', 'plc': 'plc', 'public': 'public', 'sarl': 'sarl', 'sas': 'sas', 'sasu': 'sas',
         'eurl': 'eurl', 'sa': 'sa', 'gmbh': 'gmbh'}
LANDMARK = {'near', 'nr', 'opp', 'opposite', 'behind', 'beside', 'next', 'adjacent'}

# ---- v3 token handling (features only; blocking and the v2 caches are untouched) ----
# French legal forms the v2 table lacked (snc showed up as a France decoy word in the label-free probe)
LEGAL3 = {**LEGAL, 'snc': 'snc', 'sci': 'sci', 'selarl': 'selarl', 'sca': 'sca', 'scop': 'scop', 'gie': 'gie',
          'cie': 'co', 'compagnie': 'co', 'societe': 'societe'}
# one token for a country name, so "inserted country name = decoy" learned on India ('india') transfers to France
CTRY = {'india': '<ctry>', 'indian': '<ctry>', 'france': '<ctry>', 'french': '<ctry>', 'usa': '<ctry>',
        'us': '<ctry>', 'america': '<ctry>', 'american': '<ctry>'}
# street-type spellings (US + French) -> one form, so 'ave' vs 'avenue' or 'r' vs 'rue' is not a word difference
CANON = {'st': 'street', 'str': 'street', 'rd': 'road', 'ave': 'avenue', 'av': 'avenue', 'blvd': 'boulevard',
         'bd': 'boulevard', 'bvd': 'boulevard', 'dr': 'drive', 'ln': 'lane', 'ct': 'court', 'pl': 'place',
         'sq': 'square', 'hwy': 'highway', 'pkwy': 'parkway', 'ter': 'terrace', 'cir': 'circle', 'r': 'rue',
         'imp': 'impasse', 'ch': 'chemin', 'rte': 'route', 'nr': 'near', 'opp': 'opposite', 'no': 'number',
         'apt': 'apartment', 'fl': 'floor', 'bldg': 'building', 'mkt': 'market', 'ngr': 'nagar'}


def name_tokens3(s):
    return {CTRY.get(t, t) for t in s.split()}


def addr_tokens3(s):
    return {CANON.get(t, t) for t in s.split()}


def norm(s):
    s = _domain.sub(' ', _acronym.sub(lambda m: m.group(0).replace('.', ''), s))
    s = unicodedata.normalize('NFD', s.lower().replace('&', ' '))
    s = _nonword.sub(' ', _latin_marks.sub('', s)).strip()
    s = _zeropad.sub('', s)
    return '' if s in NULLS else s


def norm_name(s):
    s = norm(s)
    for pat, rep in _ocr:
        s = pat.sub(rep, s)
    return ' '.join(t for t in s.split() if t != 'and')


def addr_comps(s):
    """Normalised comma components, NULL pieces dropped, joined by SEP."""
    return SEP.join(c for c in (norm(_half.sub(' ', x)) for x in s.split(',')) if c)


def flat(acomp):
    return acomp.replace(SEP, ' ')


def comps(acomp):
    return acomp.split(SEP) if acomp else []


def has_digit(s):
    return _digit.search(s) is not None


def has_nonlatin(s):
    return _nonlatin.search(s) is not None


def numbers(addr):
    """[(value, suffix)] for every number in a normalised address: '593a' -> (593, 'a'), '42rd' -> (42, 'rd')."""
    return [(int(n[-15:]), suf) for n, suf in _num.findall(addr)]


def ordinal_ok(n, suf):
    if suf not in ('st', 'nd', 'rd', 'th'):
        return True
    want = 'th' if n % 100 in (11, 12, 13) else {1: 'st', 2: 'nd', 3: 'rd'}.get(n % 10, 'th')
    return suf == want


def spaced_digits(s):
    """'2404 32nd' -> '2 4 0 4 3 2nd': one token per digit, so a transformer sees which digit changed."""
    return re.sub(r'(?<=\d)(?=\d)', ' ', s)


# ---------------------------------------------------------------- reading
def read_tsv(path):
    return pd.read_csv(path, sep='\t', dtype=str, keep_default_na=False, quoting=3)


def _norm_chunk(a):
    names, addrs = a
    return [norm_name(x) for x in names], [addr_comps(x) for x in addrs]


def _normalise(df):
    """Parallel normalisation of name/address; raw text columns are dropped to save RAM."""
    n = len(df)
    step = max(1, n // (C.N_PROC * 4) + 1)
    tasks = [(df['business_name'].values[a:a + step].tolist(), df['business_address'].values[a:a + step].tolist())
             for a in range(0, n, step)]
    if C.N_PROC > 1 and n > 50_000:
        with mp.get_context('spawn').Pool(C.N_PROC) as pool:
            res = pool.map(_norm_chunk, tasks)
    else:
        res = [_norm_chunk(t) for t in tasks]
    df['name'] = [x for r in res for x in r[0]]
    df['acomp'] = [x for r in res for x in r[1]]
    df['country'] = df['country'].str.strip()
    return df.drop(columns=['business_name', 'business_address'])


def load_raw(split, data=None):
    """S1 and the S2+S3 query table (S2 rows first), normalised."""
    d = data or C.DATA
    s1 = _normalise(read_tsv(d / split / f'{split}_source1.tsv'))
    q = _normalise(pd.concat([read_tsv(d / split / f'{split}_source{k}.tsv') for k in (2, 3)], ignore_index=True))
    q['src'] = (q['entity_id'].str[:2] == 'S3').astype(np.int8)
    return s1, q


def load_truth(s1, q, data=None):
    """For every query row: the S1 row index it matches, or -1 (decoy / unmatched)."""
    gt = read_tsv((data or C.DATA) / 'train' / 'train_ground_truth.tsv')
    g = gt.assign(r=gt['matched_entity_ids'].str.split(',')).explode('r')
    g = g[g['r'].fillna('') != '']
    s1_pos = pd.Series(np.arange(len(s1)), index=s1['entity_id'].values)
    q_pos = pd.Series(np.arange(len(q)), index=q['entity_id'].values)
    g = g[g['r'].isin(q_pos.index) & g['source1_entity_id'].isin(s1_pos.index)]
    truth = np.full(len(q), -1, np.int64)
    truth[q_pos[g['r']].values] = s1_pos[g['source1_entity_id']].values
    return truth


# ---------------------------------------------------------------- Indic dictionary (Dice alignment)
def learn_indic(s1, q, truth, min_pairs=3):
    """Word-level Indic->Latin table from true pairs: argmax_s Dice(q_tok, s_tok), count >= min_pairs.
    Dice = harmonic mean of P(s|q) and P(q|s), so hub words like 'limited' cannot win everywhere."""
    rows = []
    pos = np.flatnonzero(truth >= 0)
    for col, f in (('name', lambda x: x), ('acomp', flat)):
        qt = q[col].values[pos]
        m = np.fromiter((has_nonlatin(t) for t in qt), bool, len(qt))
        a = pd.DataFrame({'pair': pos[m] * 2 + (col == 'acomp'), 'q': [f(x) for x in qt[m]],
                          's': [f(x) for x in s1[col].values[truth[pos[m]]]]})
        a['q'] = a['q'].str.split(); a['s'] = a['s'].str.split()
        a = a.explode('q').explode('s').dropna()
        a = a[a['q'].map(has_nonlatin) & ~a['s'].map(has_nonlatin)].drop_duplicates()
        rows.append(a)
    a = pd.concat(rows, ignore_index=True)
    if a.empty:
        return {}
    c = a.groupby(['q', 's']).size().rename('c').reset_index()
    cq = a.drop_duplicates(['pair', 'q']).groupby('q').size()
    cs = a.drop_duplicates(['pair', 's']).groupby('s').size()
    c['dice'] = 2 * c['c'] / (c['q'].map(cq).values + c['s'].map(cs).values)
    c = c[c['c'] >= min_pairs].sort_values('dice', ascending=False).drop_duplicates('q')
    return dict(zip(c['q'], c['s']))


def apply_indic(texts, d):
    """Replace known Indic tokens; works on names and on SEP-joined address components alike."""
    return [SEP.join(' '.join(d.get(t, t) for t in c.split()) for c in s.split(SEP)) if s and has_nonlatin(s) else s
            for s in texts]


# ---------------------------------------------------------------- states (top level of the address hierarchy)
def learn_states(s1):
    """Per country, from S1 only (so it also works on unlabelled test countries such as France):
    candidates = digit-free components that are frequently the LAST component of an S1 address;
    a candidate contained in another one (P(b | a) >= 0.5 and P(b | a) > P(a | b)) is a city, not a state."""
    out = {}
    for c, g in s1.groupby('country'):
        cl = [comps(x) for x in g['acomp'].values]
        last = collections.Counter(x[-1] for x in cl if x and not has_digit(x[-1]))
        thr = max(20 if not C.SMOKE else 2, 2e-4 * len(g))
        cand = {k for k, v in last.items() if v >= thr}
        cnt, co = collections.Counter(), collections.Counter()
        for x in cl:
            p = sorted(cand.intersection(x))
            cnt.update(p)
            co.update((a, b) for a in p for b in p if a != b)
        drop = {a for (a, b), v in co.items() if v / cnt[a] >= 0.5 and v / cnt[a] > v / cnt[b]}   # a inside b
        out[c] = cand - drop
    return out


def learn_state_aliases(s1, q, truth, vocab):
    """Query-side spellings of a state (MH, Pennsylvania, महाराष्ट्र) -> the S1 state, from true pairs.
    Keep x -> st when x is almost always paired with st (>= 0.9) and x is rare in S1 itself (so cities,
    which also appear in S1 addresses, are not mistaken for state names)."""
    pos = np.flatnonzero(truth >= 0)
    rng = np.random.default_rng(C.SEED)
    pos = rng.choice(pos, min(len(pos), 2_000_000), replace=False)
    pair, nx = collections.Counter(), collections.Counter()
    for i in pos:
        c = q['country'].values[i]
        st = vocab.get(c, set()).intersection(comps(s1['acomp'].values[truth[i]]))
        if len(st) != 1:
            continue
        st = next(iter(st))
        for x in set(comps(q['acomp'].values[i])):
            if not has_digit(x) and x not in vocab.get(c, ()):
                pair[(c, x, st)] += 1
                nx[(c, x)] += 1
    cand = {(c, x) for (c, x, _), v in pair.items() if v >= 2}
    s1_freq = collections.Counter()                      # only for candidate spellings, keeps the Counter small
    for c, a in zip(s1['country'].values, s1['acomp'].values):
        s1_freq.update(k for k in ((c, x) for x in set(comps(a))) if k in cand)
    thr = 20 if not C.SMOKE else 2
    return {(c, x): st for (c, x, st), v in pair.items()
            if v >= thr and v >= 0.9 * nx[(c, x)] and s1_freq[(c, x)] <= 0.05 * v}


def detect_states(df, vocab, aliases):
    """The record's state if exactly one state is named (directly or via an alias), else ''."""
    out = []
    for c, a in zip(df['country'].values, df['acomp'].values):
        v = vocab.get(c, ())
        st = {aliases.get((c, x), x) for x in comps(a)}
        st = st.intersection(v) if v else set()
        out.append(next(iter(st)) if len(st) == 1 else '')
    return np.array(out, dtype=object)


def learn_state_merges(s1, q, truth, min_count=20, min_share=0.001):
    """States that true pairs systematically swap (Telangana <-> Andhra Pradesh: records keep the pre-2014 state)
    are merged into one bucket label, so the state lemma holds again. Returns {(country, state): label}."""
    m = (truth >= 0) & (q['state'].values != '')
    ss, qs, c = s1['state'].values[truth[m]], q['state'].values[m], q['country'].values[m]
    k = (ss != '') & (ss != qs)
    n_state = collections.Counter(zip(c[(ss != '')], ss[(ss != '')]))
    diff = collections.Counter(zip(c[k], ss[k], qs[k]))
    thr = 2 if C.SMOKE else min_count
    parent = {}

    def root(x):
        while parent.get(x, x) != x:
            x = parent[x]
        return x
    for (cc, a, b), v in diff.items():
        if v >= thr and v >= min_share * n_state[(cc, a)]:
            ra, rb = root((cc, a)), root((cc, b))
            if ra != rb:
                parent[max(ra, rb)] = min(ra, rb)
    return {x: root(x)[1] for x in parent}


def merge_states(df, merges):
    return np.array([merges.get((c, s), s) if s else s for c, s in zip(df['country'].values, df['state'].values)],
                    dtype=object)


# ---------------------------------------------------------------- place aliases (for per-level features)
def learn_place_aliases(q_acomp, s_acomp, min_count=30, min_dice=0.3):
    """Digit-free components left unmatched on both sides of true pairs, paired by Dice (PA<->pennsylvania,
    postal city <-> township). Learned on training-region pairs only."""
    from rapidfuzz import fuzz
    cnt, nq, ns = collections.Counter(), collections.Counter(), collections.Counter()
    for a, b in zip(q_acomp, s_acomp):
        A = {x for x in comps(a) if not has_digit(x)}
        B = {x for x in comps(b) if not has_digit(x)}
        ua = [x for x in A - B if not any(fuzz.ratio(x, z) >= 85 for z in B)]
        ub = [z for z in B - A if not any(fuzz.ratio(x, z) >= 85 for x in A)]
        nq.update(ua); ns.update(ub)
        cnt.update((x, z) for x in ua for z in ub)
    if C.SMOKE:
        min_count = 2
    return {(x, z) for (x, z), c in cnt.items() if c >= min_count and 2 * c / (nq[x] + ns[z]) >= min_dice}


if __name__ == '__main__':
    assert norm('Shiv TÉCHNOLOGY & Co.') == 'shiv technology co'
    assert norm('हाईटेक फाइनेंस') == 'हाईटेक फाइनेंस'                         # matras survive
    assert norm('Keystone L.L.C.') == 'keystone llc' and norm('wmelitedeli.com') == 'wmelitedeli'
    assert norm('007168 CORNWALLIS RD') == '7168 cornwallis rd' and norm('10 main') == '10 main'
    assert norm_name('Better Ta1ent & Sons') == 'better talent sons'
    assert addr_comps('17 Thatcher St, <NULL>, Boston, MA') == '17 thatcher st|boston|ma'
    assert addr_comps('824 1/2 West St, Garden Plain') == '824 west st|garden plain'
    assert numbers('593a 42rd st 7') == [(593, 'a'), (42, 'rd'), (7, '')]
    assert not ordinal_ok(42, 'rd') and ordinal_ok(42, 'nd') and ordinal_ok(13, 'th') and ordinal_ok(5, 'a')
    assert spaced_digits('2404 32nd') == '2 4 0 4 3 2nd'
    india = ['a|mumbai|maharashtra'] * 4 + ['b|pune|maharashtra'] * 3 + ['c|mumbai'] * 2
    s1 = pd.DataFrame({'country': ['US'] * 6 + ['India'] * 9,
                       'acomp': ['1 a st|salem|ma', '2 b st|boston|ma', '3 c st|boston|ma', '4 d st|austin|tx',
                                 '5 e st|dallas|tx', 'tx|6 f st|dallas'] + india})
    C.SMOKE = True
    v = learn_states(s1)
    assert v['US'] == {'ma', 'tx'} and 'maharashtra' in v['India'] and 'mumbai' not in v['India'], v
    q = pd.DataFrame({'country': ['US'] * 3, 'acomp': ['1 a st|salem|massachusetts'] * 2 + ['9 z st|austin|tx']})
    al = learn_state_aliases(s1, q, np.array([0, 1, 3]), v)
    assert al == {('US', 'massachusetts'): 'ma'}, al
    assert detect_states(q, v, al).tolist() == ['ma', 'ma', 'tx']
    s1m = pd.DataFrame({'country': ['India'] * 2, 'state': ['telangana', 'kerala']})
    qm = pd.DataFrame({'country': ['India'] * 5, 'state': ['andhra pradesh'] * 3 + ['telangana', 'kerala']})
    mg = learn_state_merges(s1m, qm, np.array([0, 0, 0, 0, 1]))
    assert mg == {('India', 'telangana'): 'andhra pradesh'}, mg
    assert merge_states(s1m, mg).tolist() == ['andhra pradesh', 'kerala']
    assert apply_indic(['हाईटेक x', 'a|महाराष्ट्र b', 'abc'], {'हाईटेक': 'hitech', 'महाराष्ट्र': 'maharashtra'}) ==         ['hitech x', 'a|maharashtra b', 'abc']
    print('ok')
