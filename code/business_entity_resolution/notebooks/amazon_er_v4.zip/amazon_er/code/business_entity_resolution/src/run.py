"""Business entity resolution pipeline v2: raw TSV -> candidates -> matches.

    python src/run.py check      # pre-flight: data files, GPU, RAM, disk, write access, model download (~1 min)
    python src/run.py smoke      # whole pipeline on a tiny sample (a few minutes) in WORK/smoke
    python src/run.py train      # fit everything on train; writes EVAL/report.md and validation outputs
    python src/run.py test       # score test; writes OUT/candidate_pairs.tsv and OUT/matching_results.tsv
    python src/run.py diagnose   # optional: t-SNE of cross-encoder embeddings (true match / decoy / wrong S1)

v3 (on top of the v2 caches; use run_v3.sh, which enforces the deadline):
    python src/run.py v3check    # v2 caches present, disk, RAM, GPU, validator
    python src/run.py smoke3     # v2 smoke + v3 on top of it, tiny data (~10 min)
    python src/run.py v3         # phases 1-2 under the clock (ER_T0, ER_DEADLINE_MIN)
    python src/run.py assemble   # final output/ from the best finished variant per country (always valid)

v4 (on top of a finished v3 run; frozen models, decision layer only; use run_v4.sh):
    python src/run.py v4check    # v3 state present, RAM, disk, validator
    python src/run.py smoke4     # smoke3 + postfix twice + assemble, tiny data (~20 min)
    python src/run.py postfix    # split prior shift, lone-claimant threshold, singleton filter (gated on EVAL)

Every stage caches its result in WORK and resumes from it; neural training resumes from last.pt.
"""
import os, sys, json, shutil, subprocess, hashlib
from pathlib import Path
import numpy as np, pandas as pd
import config as C


# ---------------------------------------------------------------- stage A
def prepare(split):
    import text
    path = C.WORK / f'{split}_records.pkl'
    tpath = C.WEIGHTS / 'tables.pkl'
    if path.exists():
        s1, q, truth = C.load_pickle(path)
        return s1, q, truth
    with C.stage(f'prepare {split}'):
        s1, q = text.load_raw(split)
        C.log(f'  {split}: S1={len(s1):,} S2+S3={len(q):,} countries={sorted(set(s1.country) | set(q.country))}')
        truth = text.load_truth(s1, q) if split == 'train' else None
        if split == 'train':
            tabs = {'indic': text.learn_indic(s1, q, truth)}
        else:
            tabs = C.load_pickle(tpath)
        q['name'] = text.apply_indic(q['name'].values, tabs['indic'])
        q['acomp'] = text.apply_indic(q['acomp'].values, tabs['indic'])
        vocab = text.learn_states(s1)                         # from this split's S1 only (label-free)
        if split == 'train':
            tabs['state_alias'] = text.learn_state_aliases(s1, q, truth, vocab)
        s1['state'] = text.detect_states(s1, vocab, tabs['state_alias'])
        q['state'] = text.detect_states(q, vocab, tabs['state_alias'])
        if split == 'train':
            tabs['state_merge'] = text.learn_state_merges(s1, q, truth)
            C.save_pickle(tabs, tpath)
            C.log(f'  merged states (true pairs swap them): {tabs["state_merge"]}')
        s1['state'] = text.merge_states(s1, tabs['state_merge'])
        q['state'] = text.merge_states(q, tabs['state_merge'])
        C.log(f'  indic dict={len(tabs["indic"]):,} state aliases={len(tabs["state_alias"]):,} states per country=' +
              str({c: len(v) for c, v in vocab.items()}) +
              f' | S1 with state={(s1.state != "").mean():.3f} queries with state={(q.state != "").mean():.3f}')
        C.save_pickle((s1, q, truth), path)
    return s1, q, truth


def bucket_of(df, states_on):
    on = df['country'].map(lambda c: bool(states_on.get(c))).values
    return np.where(on & (df['state'].values != ''), df['country'].values + '|' + df['state'].values,
                    df['country'].values + '|')


def region_key(df):
    return df['country'].values + '|' + df['state'].values


def assign_regions(s1_bucket):
    """Whole buckets, in a fixed pseudo-random order, until TRAIN_FRAC then VAL_FRAC of S1 is covered."""
    b = pd.Series(s1_bucket).value_counts()
    order = sorted(b.index, key=lambda k: hashlib.md5(k.encode()).hexdigest())
    cum, reg = 0, {}
    for k in order:
        f = cum / len(s1_bucket)
        reg[k] = 'train' if f < C.TRAIN_FRAC else 'val' if f < C.TRAIN_FRAC + C.VAL_FRAC else 'none'
        cum += b[k]
    if 'val' not in reg.values():                     # tiny data: make sure both regions exist
        reg[order[-1]] = 'val'
    return reg


def block(split, s1, q, truth, qmask, states_on, idx):
    """Char channel + bi-encoder channel -> merged candidate edges."""
    import blocking, bienc
    grps = blocking.groups(s1, q, qmask, states_on)
    with C.stage(f'{split}: char channel'):
        char = C.cached(f'{split}_char', lambda: blocking.char_channel(s1, q, grps, idx))
    if split == 'train' and not ((C.WEIGHTS / 'bienc' / 'best.pt').exists() and
                                 not (C.WEIGHTS / 'bienc' / 'last.pt').exists()):
        with C.stage('bi-encoder training'):
            hn = bienc.hard_negatives(char, truth, len(q))
            reg = C.load_pickle(C.WORK / 'regions.pkl')
            s1_bucket = region_key(s1)
            s1_reg = np.array([reg.get(b, 'none') for b in s1_bucket])
            pos = np.flatnonzero((truth >= 0) & qmask)
            rng = np.random.default_rng(C.SEED)
            pos = rng.permutation(pos)
            pos_tr, pos_va = pos[s1_reg[truth[pos]] == 'train'], pos[s1_reg[truth[pos]] == 'val']
            tok, model = bienc.train(s1, q, pos_tr, pos_va, truth, hn, pd.factorize(s1_bucket)[0])
    else:
        tok, model = bienc.load()
    with C.stage(f'{split}: dense channel'):
        dense = C.cached(f'{split}_dense', lambda: bienc.search(model, tok, s1, q, grps, char,
                                                                C.WORK / f'{split}_s1_emb.npy'))
    del model
    pairs = blocking.merge(char, dense)
    if truth is not None:
        blocking.recall_report(pairs, truth, q)
    return pairs


def ce_mask(qi, p1):
    """Edges the cross-encoder scores: stage-1 p inside CE_BAND and among the query's 2 best edges
    (only a query's best edge can ever be selected, so deeper edges are not worth GPU time)."""
    o = np.lexsort((-p1, qi))
    start = np.r_[True, qi[o][1:] != qi[o][:-1]]
    pos = np.arange(len(o)) - np.maximum.accumulate(np.where(start, np.arange(len(o)), 0))
    rank = np.empty(len(o), np.int64); rank[o] = pos
    return (p1 > C.CE_BAND[0]) & (p1 < C.CE_BAND[1]) & (rank < 2)


def star_matrix(pairs, p1, ce, q, s1):
    import features
    Z = features.star_features(pairs, p1, q, s1)
    Z.insert(0, 'ce_logit', ce)
    Z.insert(0, 'p1', p1)
    return Z.values.astype(np.float32), list(Z.columns)


# ---------------------------------------------------------------- train
def run_train():
    import blocking, features, gbdt, crossenc, decide, evaluate, text
    for d in (C.WORK, C.WEIGHTS, C.EVAL):
        d.mkdir(parents=True, exist_ok=True)
    s1, q, truth = prepare('train')
    countries = sorted(set(q['country']))
    with C.stage('train: state check + char index'):
        idx = blocking.build_indexes(s1, countries)
        states_on = C.cached('train_states_on', lambda: blocking.state_check(s1, q, idx, truth))
    s1_key = region_key(s1)                             # regions use the S1's state even where search is country-wide
    reg = C.cached('regions', lambda: assign_regions(s1_key))
    s1_reg = np.array([reg.get(b, 'none') for b in s1_key])
    C.log('  regions (share of S1): ' + str(pd.Series(s1_reg).value_counts(normalize=True).round(3).to_dict()))
    q_bucket = bucket_of(q, states_on)
    qmask = np.array([b.endswith('|') or reg.get(b, 'train') != 'none' for b in q_bucket])   # skip unused buckets
    C.log(f'  queries searched: {qmask.sum():,} of {len(q):,}')

    pairs = C.cached('train_pairs', lambda: block('train', s1, q, truth, qmask, states_on, idx))
    del idx
    with C.stage('train: regions, graph features, tables'):
        aux = features.s1_aux(s1)
        G = features.graph_features(pairs, aux, q, q_bucket != np.array([c + '|' for c in q['country'].values]))
        t1 = features.top1_mask(pairs)
        top1 = np.full(len(q), -1, np.int64); top1[pairs['qi'].values[t1]] = pairs['si'].values[t1]
        q_reg = np.where(top1 >= 0, s1_reg[np.maximum(top1, 0)], 'none')
        keep = np.isin(q_reg[pairs['qi'].values], ['train', 'val'])
        pairs, G = pairs[keep].reset_index(drop=True), G[keep].reset_index(drop=True)
        qi, si = pairs['qi'].values, pairs['si'].values
        y = (truth[qi] == si).astype(np.int8)
        e_reg = q_reg[qi]
        tr, va = np.flatnonzero(e_reg == 'train'), np.flatnonzero(e_reg == 'val')
        fold = (np.random.default_rng(1).permutation(len(s1))[top1[qi]] % C.NF).astype(np.int8)
        C.log(f'  edges: train={len(tr):,} val={len(va):,} positives: train={y[tr].mean():.3f} val={y[va].mean():.3f}')

        tpath = C.WEIGHTS / 'tables.pkl'
        tabs = C.load_pickle(tpath)
        if 'llr' not in tabs:
            t1e = t1[keep]
            dec = tr[(truth[qi[tr]] < 0) & t1e[tr] & (np.nan_to_num(pairs['char_cos'].values[tr]) >= 0.5)]
            pos = tr[y[tr] == 1]
            pos = np.random.default_rng(C.SEED).choice(pos, min(len(pos), 2_000_000), replace=False)
            e = np.concatenate([pos, dec])
            tabs['llr'] = features.learn_llr(q, s1, qi[e], si[e], np.r_[np.ones(len(pos)), np.zeros(len(dec))].astype(int))
            ps = pos[:300_000]
            tabs['alias'] = text.learn_place_aliases(q['acomp'].values[qi[ps]], s1['acomp'].values[si[ps]])
            C.save_pickle(tabs, tpath)
            C.log(f'  llr tables: decoy near-duplicates={len(dec):,} positives={len(pos):,}; place aliases={len(tabs["alias"]):,}')
    with C.stage('train: pair features'):
        X, cols = features.build_X('train', pairs, G, s1, q, {'llr': tabs['llr'], 'alias': tabs['alias']})
    del G

    with C.stage('train: GBDT stage 1'):
        p1 = C.cached('train_p1', lambda: _stage_p(1, X, None, y, fold, tr, va, cols))
    band = ce_mask(qi, p1)
    ce = np.full(len(p1), np.nan, np.float32)
    A, B = tr[band[tr] & (fold[tr] < 2)], tr[band[tr] & (fold[tr] >= 2)]
    vb = va[band[va]]
    vs = np.sort(np.random.default_rng(C.SEED).choice(vb, min(len(vb), C.CE_VAL_EDGES), replace=False))
    ce_models = []
    if min(len(A), len(B), len(vs)) >= 20:
        with C.stage('train: cross-encoder'):
            for name, idx_ in (('ce_a', A), ('ce_b', B)):
                if not ((C.WEIGHTS / name / 'best.pt').exists() and not (C.WEIGHTS / name / 'last.pt').exists()):
                    crossenc.train(name, q, s1, (qi[idx_], si[idx_], y[idx_]), (qi[vs], si[vs], y[vs]))
            ce_models = ['ce_a', 'ce_b']

            def _score():
                c = np.full(len(p1), np.nan, np.float32)
                c[B] = crossenc.score(['ce_a'], q, s1, qi[B], si[B])     # out-of-fold on train
                c[A] = crossenc.score(['ce_b'], q, s1, qi[A], si[A])
                c[vb] = crossenc.score(ce_models, q, s1, qi[vb], si[vb])
                return c
            ce = C.cached('train_ce', _score)
            C.log(f'  cross-encoder scored {int(np.isfinite(ce).sum()):,} band edges')
            C.save_pickle({'qi': qi[vs][:3000], 'si': si[vs][:3000], 'y': y[vs][:3000],
                           'decoy': truth[qi[vs][:3000]] < 0}, C.WORK / 'diag_sample.pkl')
    else:
        C.log(f'  cross-encoder skipped: too few band edges (A={len(A)}, B={len(B)}, val={len(vs)})')

    with C.stage('train: stage E + GBDT stage 2'):
        Z, zcols = C.cached('train_Z', lambda: star_matrix(pairs, p1, ce, q, s1))
        p2 = C.cached('train_p2', lambda: _stage_p(2, X, Z, y, fold, tr, va, cols + zcols))
        iso = decide.calibrate(p2[tr], y[tr])
        pc = iso.predict(p2).astype(np.float32)

    with C.stage('train: decision rule + validation report'):
        val_s1 = np.flatnonzero(s1_reg == 'val')
        qv, sv, pv = qi[va], si[va], pc[va]
        results = []
        for rule in [{'kind': 'expected_f'}] + [{'kind': 'tau', 'tau': t} for t in C.TAUS]:
            sel = decide.select(qv, sv, pv, rule)
            results.append((decide.f05_macro(sv[sel], y[va][sel], truth, val_s1)[0], json.dumps(rule), rule))
        best = max(results, key=lambda r: r[0])
        rule = best[2]
        C.save_pickle({'iso': iso, 'rule': rule, 'ce_models': ce_models, 'cols': cols, 'zcols': zcols},
                      C.WEIGHTS / 'decision.pkl')
        sel = decide.select(qv, sv, pv, rule)
        evaluate.report(pairs.iloc[va].reset_index(drop=True), sel, y[va], truth, s1, q, val_s1,
                        [(r[1], r[0]) for r in results])
        loc = np.full(len(s1), -1); loc[val_s1] = np.arange(len(val_s1))
        inv = loc[sv] >= 0
        qids = q['entity_id'].values
        evaluate.write_outputs(C.EVAL, 'val_', s1['entity_id'].values[val_s1], loc[sv[inv]], qids[qv[inv]],
                               loc[sv[inv & sel]], qids[qv[inv & sel]])
        C.log(f'  chosen rule: {rule}; validation outputs in {C.EVAL}')
    del X, Z
    import gc; gc.collect()                            # release the memmap before deleting its file
    if os.environ.get('ER_KEEP_WORK') != '1':          # free ~10-20 GB; models and tables stay in WEIGHTS
        for f in ['train_X1.f16', 'train_s1_emb.npy', 'train_char.pkl', 'train_dense.pkl', 'train_Z.pkl']:
            try:
                (C.WORK / f).unlink(missing_ok=True)
            except OSError as e:                       # never fail a finished run over cleanup
                C.log(f'  could not remove {f}: {e}')
        C.log('  removed large train caches (set ER_KEEP_WORK=1 to keep them)')


def _stage_p(stage, X, Z, y, fold, tr, va, cols):
    import gbdt
    p_tr, p_va, _ = gbdt.run_stage(stage, X, Z, y, fold, tr, va, cols)
    p = np.full(len(y), np.nan, np.float32)
    p[tr], p[va] = p_tr, p_va
    return p


# ---------------------------------------------------------------- test
def run_test():
    import blocking, features, gbdt, crossenc, decide, evaluate
    for d in (C.WORK, C.OUT):
        d.mkdir(parents=True, exist_ok=True)
    dec = C.load_pickle(C.WEIGHTS / 'decision.pkl')
    tabs = C.load_pickle(C.WEIGHTS / 'tables.pkl')
    s1, q, _ = prepare('test')
    with C.stage('test: state check + char index'):
        idx = blocking.build_indexes(s1, sorted(set(q['country'])))
        states_on = C.cached('test_states_on', lambda: blocking.state_check(s1, q, idx))
    pairs = C.cached('test_pairs', lambda: block('test', s1, q, None, np.ones(len(q), bool), states_on, idx))
    del idx
    qi, si = pairs['qi'].values, pairs['si'].values
    with C.stage('test: pair features'):
        q_bucket = bucket_of(q, states_on)
        G = features.graph_features(pairs, features.s1_aux(s1), q,
                                    q_bucket != np.array([c + '|' for c in q['country'].values]))
        X, cols = features.build_X('test', pairs, G, s1, q, {'llr': tabs['llr'], 'alias': tabs['alias']})
        del G
    allidx = np.arange(len(pairs))
    with C.stage('test: GBDT stage 1 + cross-encoder'):
        p1 = C.cached('test_p1', lambda: gbdt.predict(gbdt.load(1), X, None, allidx, fast=True))
        ce = np.full(len(p1), np.nan, np.float32)
        if dec['ce_models']:
            band = np.flatnonzero(ce_mask(qi, p1))
            ce = C.cached('test_ce', lambda: _fill(len(p1), band, crossenc.score(dec['ce_models'], q, s1, qi[band], si[band])))
    with C.stage('test: stage E + GBDT stage 2 + decision'):
        Z, _ = star_matrix(pairs, p1, ce, q, s1)
        p = dec['iso'].predict(gbdt.predict(gbdt.load(2), X, Z, allidx, fast=True)).astype(np.float32)
        sel = decide.select(qi, si, p, dec['rule'])
    qids = q['entity_id'].values
    evaluate.write_outputs(C.OUT, '', s1['entity_id'].values, si, qids[qi], si[sel], qids[qi[sel]])
    cnt = np.bincount(si[sel], minlength=len(s1))
    C.log(f'test: S1={len(s1):,} candidate edges={len(pairs):,} matches={sel.sum():,} '
          f'S1 with no match={(cnt == 0).mean():.3f}\n' +
          pd.DataFrame({'country': s1['country'].values, 'n': cnt}).groupby('country')['n']
          .agg(matches_per_S1='mean', empty_share=lambda x: (x == 0).mean()).round(3).to_string())
    validate(C.DATA / 'test')


def _fill(n, idx, v):
    out = np.full(n, np.nan, np.float32)
    out[idx] = v
    return out


def validate(test_dir):
    if not C.VALIDATOR.exists():
        C.log(f'validator not found at {C.VALIDATOR}; skipped')
        return
    r = subprocess.run([sys.executable, str(C.VALIDATOR), '--matching', str(C.OUT / 'matching_results.tsv'),
                        '--candidate', str(C.OUT / 'candidate_pairs.tsv'), '--test-dir', str(test_dir)],
                       capture_output=True, text=True, encoding='utf-8', errors='replace')
    C.log('validator:\n' + r.stdout + r.stderr)
    if r.returncode != 0:
        raise SystemExit('validator FAILED')


# ---------------------------------------------------------------- check
def run_check():
    import text, psutil, torch
    rows, bad = [], False

    def add(name, ok, msg):
        nonlocal bad
        rows.append(('PASS' if ok else 'FAIL', name, msg))
        bad |= not ok

    want = {'train': ['train_source1', 'train_source2', 'train_source3', 'train_ground_truth'],
            'test': ['test_source1', 'test_source2', 'test_source3']}
    for split, names in want.items():
        for n in names:
            p = C.DATA / split / f'{n}.tsv'
            if not p.exists():
                add(n, False, f'missing: {p}')
                continue
            head = pd.read_csv(p, sep='\t', nrows=5, dtype=str, quoting=3)
            cols = ['source1_entity_id', 'matched_entity_ids'] if 'truth' in n else \
                ['entity_id', 'business_name', 'business_address', 'country']
            add(n, list(head.columns) == cols, f'{p.stat().st_size / 2**20:,.0f} MB, columns {list(head.columns)}')
    add('validator', C.VALIDATOR.exists(), str(C.VALIDATOR))
    gpu = torch.cuda.is_available()
    add('GPU', gpu, f'{torch.cuda.get_device_name(0)}, {torch.cuda.get_device_properties(0).total_memory / 2**30:.0f} GB, '
        f'mixed precision={"bf16" if torch.cuda.get_device_capability()[0] >= 8 else "fp16 + loss scaling"}'
        if gpu else 'no CUDA GPU visible to torch (training would run on CPU and take days)')
    ram = psutil.virtual_memory().total / 2 ** 30
    add('RAM', ram >= 28, f'{ram:.0f} GB total (need ~30 GB; Kaggle GPU sessions have ~29-31 GB)')
    for d in (C.WORK, C.WEIGHTS, C.EVAL, C.OUT):
        try:
            d.mkdir(parents=True, exist_ok=True)
            (d / '.write_test').write_text('ok'); (d / '.write_test').unlink()
            add(f'write {d.name}/', True, str(d))
        except OSError as e:
            add(f'write {d.name}/', False, f'{d}: {e}')
    free = shutil.disk_usage(C.WORK).free / 2 ** 30
    add('disk', free >= 25, f'{free:.0f} GB free on the drive of {C.WORK} (peak use ~20-25 GB)')
    add('CPU cores', True, f'{os.cpu_count()} (ER_PROCS={C.N_PROC})')
    for m in (C.BIENC_MODEL, C.CE_MODEL):
        try:
            from transformers import AutoTokenizer, AutoConfig
            AutoConfig.from_pretrained(m); AutoTokenizer.from_pretrained(m)
            add(f'model {m}', True, 'downloaded / cached')
        except Exception as e:                     # noqa: BLE001  (report any download problem)
            add(f'model {m}', False, f'{type(e).__name__}: {e}'[:200])
    w = max(len(r[1]) for r in rows)
    print('\n'.join(f'[{s}] {n:<{w}}  {m}' for s, n, m in rows))
    if bad:
        raise SystemExit('\ncheck FAILED: fix the FAIL lines above')
    print('\ncheck passed')


# ---------------------------------------------------------------- smoke
def make_smoke_data(dst, n_s1=3000, n_test_s1=2000):
    """A tiny but structurally faithful copy of the data: whole S1 clusters + unmatched records, same file format."""
    import text
    rng = np.random.default_rng(C.SEED)
    src = C.DATA
    s1 = text.read_tsv(src / 'train' / 'train_source1.tsv')
    gt = text.read_tsv(src / 'train' / 'train_ground_truth.tsv')
    pick = gt.iloc[rng.choice(len(gt), min(n_s1, len(gt)), replace=False)]
    keep_q = set(x for v in pick['matched_entity_ids'] for x in v.split(',') if x)
    (dst / 'train').mkdir(parents=True, exist_ok=True)
    (dst / 'test').mkdir(parents=True, exist_ok=True)
    s1[s1['entity_id'].isin(set(pick['source1_entity_id']))].to_csv(dst / 'train' / 'train_source1.tsv', sep='\t', index=False, quoting=3)
    pick.to_csv(dst / 'train' / 'train_ground_truth.tsv', sep='\t', index=False, quoting=3)
    for k in (2, 3):
        d = text.read_tsv(src / 'train' / f'train_source{k}.tsv')
        m = d['entity_id'].isin(keep_q).values | (rng.random(len(d)) < 1500 / len(d))
        d[m].to_csv(dst / 'train' / f'train_source{k}.tsv', sep='\t', index=False, quoting=3)
    t1 = text.read_tsv(src / 'test' / 'test_source1.tsv')
    t1.iloc[rng.choice(len(t1), min(n_test_s1, len(t1)), replace=False)].to_csv(dst / 'test' / 'test_source1.tsv', sep='\t', index=False, quoting=3)
    for k in (2, 3):
        d = text.read_tsv(src / 'test' / f'test_source{k}.tsv')
        d.iloc[rng.choice(len(d), min(4000, len(d)), replace=False)].to_csv(dst / 'test' / f'test_source{k}.tsv', sep='\t', index=False, quoting=3)


def run_smoke():
    base = C.WORK / 'smoke'
    data = base / 'data'
    if not (data / 'test' / 'test_source3.tsv').exists():
        with C.stage('smoke: build tiny dataset'):
            make_smoke_data(data)
    for d in ('work', 'weights', 'eval', 'output'):
        shutil.rmtree(base / d, ignore_errors=True)
    env = dict(os.environ, ER_SMOKE='1', ER_DATA=str(data), ER_WORK=str(base / 'work'), ER_WEIGHTS=str(base / 'weights'),
               ER_EVAL=str(base / 'eval'), ER_OUT=str(base / 'output'), ER_VALIDATOR=str(C.VALIDATOR))
    for cmd in ('train', 'test'):
        r = subprocess.run([sys.executable, str(Path(__file__).resolve()), cmd], env=env)
        if r.returncode != 0:
            raise SystemExit(f'smoke {cmd} FAILED (see {base / "work" / "run.log"})')
    print(f'\nsmoke passed: outputs in {base / "output"}, report in {base / "eval" / "report.md"}')


# ---------------------------------------------------------------- diagnose
def run_diagnose():
    """t-SNE of cross-encoder [CLS] vectors for up to 3000 validation band edges: is 'decoy' separable from
    'true match'? Writes EVAL/tsne.csv (and tsne.png when matplotlib is installed)."""
    import crossenc
    from sklearn.manifold import TSNE
    d = C.load_pickle(C.WORK / 'diag_sample.pkl')
    s1, q, _ = C.load_pickle(C.WORK / 'train_records.pkl')
    E = crossenc.cls_embeddings('ce_a', q, s1, d['qi'], d['si'])
    xy = TSNE(n_components=2, init='pca', random_state=C.SEED).fit_transform(E)
    lab = np.where(d['y'] == 1, 'true match', np.where(d['decoy'], 'decoy', "another S1's record"))
    df = pd.DataFrame({'x': xy[:, 0], 'y': xy[:, 1], 'label': lab})
    C.EVAL.mkdir(parents=True, exist_ok=True)
    df.to_csv(C.EVAL / 'tsne.csv', index=False)
    try:
        import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
        for l, g in df.groupby('label'):
            plt.scatter(g.x, g.y, s=4, label=l)
        plt.legend(); plt.title('cross-encoder [CLS], validation band edges'); plt.savefig(C.EVAL / 'tsne.png', dpi=150)
    except ImportError:
        pass
    print(f'wrote {C.EVAL / "tsne.csv"}')


if __name__ == '__main__':
    import v3, postfix
    cmds = {'postfix': postfix.run_postfix, 'v4check': postfix.run_check4, 'smoke4': postfix.run_smoke4,
            'check': run_check, 'smoke': run_smoke, 'train': run_train, 'test': run_test, 'diagnose': run_diagnose,
            'v3check': v3.run_check3, 'smoke3': v3.run_smoke3, 'v3': v3.run_v3, 'assemble': v3.run_assemble}
    if len(sys.argv) != 2 or sys.argv[1] not in cmds:
        raise SystemExit(__doc__)
    cmds[sys.argv[1]]()
