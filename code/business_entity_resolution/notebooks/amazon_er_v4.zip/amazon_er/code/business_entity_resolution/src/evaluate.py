"""Output files and the validation report."""
import numpy as np, pandas as pd
import config as C
from decide import f05_macro


def write_lists(path, header, s1_ids, si, ids):
    """One row per S1 in s1_ids order (si indexes s1_ids); ids joined by commas, no duplicates."""
    si = np.asarray(si)
    o = np.argsort(si, kind='stable')
    groups = np.split(np.asarray(ids)[o], np.cumsum(np.bincount(si, minlength=len(s1_ids)))[:-1])

    def w(t):
        with open(t, 'w', encoding='utf-8', newline='\n') as f:
            f.write('\t'.join(header) + '\n')
            for s, g in zip(s1_ids, groups):
                f.write(f"{s}\t{','.join(dict.fromkeys(g))}\n")
    C.atomic(path, w)


def write_outputs(folder, prefix, s1_ids, cand_si, cand_q, sel_si, sel_q):
    """cand_si / sel_si index s1_ids (local positions); cand_q / sel_q are S2/S3 entity ids."""
    write_lists(folder / f'{prefix}candidate_pairs.tsv', ['source1_entity_id', 'candidate_entity_ids'],
                s1_ids, cand_si, cand_q)
    write_lists(folder / f'{prefix}matching_results.tsv', ['source1_entity_id', 'matched_entity_ids'],
                s1_ids, sel_si, sel_q)


def report(pairs, sel, y, truth, s1, q, val_s1, rules):
    """Validation report: macro-F0.5 overall / by country / singletons vs matched S1, recall, decoy acceptance,
    and an error budget. pairs: validation-region edges; sel: chosen edges; val_s1: S1 indices of the region."""
    qi, si = pairs['qi'].values, pairs['si'].values
    f_all, f = f05_macro(si[sel], y[sel], truth, val_s1)
    ntrue = np.bincount(truth[truth >= 0], minlength=len(s1))[val_s1]
    ctry = s1['country'].values[val_s1]
    L = ['# Validation report', '',
         f'Validation region: {len(val_s1):,} S1 (whole (country, state) buckets never used for fitting), '
         f'{len(np.unique(qi)):,} queries whose top-1 candidate lies in the region.', '',
         '## Decision rule on validation', '', '| rule | macro-F0.5 |', '|---|---|']
    L += [f'| {r} | {v:.5f} |' for r, v in rules]
    L += ['', f'## Macro-F0.5 = **{f_all:.5f}**', '', '| slice | S1 | macro-F0.5 |', '|---|---|---|']
    for name, m in [('all', np.ones(len(f), bool)), ('S1 with no true match (singletons)', ntrue == 0),
                    ('S1 with >= 1 true match', ntrue > 0)] + [(f'country {c}', ctry == c) for c in sorted(set(ctry))]:
        L.append(f'| {name} | {m.sum():,} | {f[m].mean() if m.any() else float("nan"):.5f} |')

    in_val = np.zeros(len(s1), bool); in_val[val_s1] = True
    vq = np.unique(qi)
    pos_q = vq[(truth[vq] >= 0) & in_val[np.maximum(truth[vq], 0)]]
    true_edge = set(zip(qi[y == 1], si[y == 1]))
    retrieved = np.array([(a, truth[a]) in true_edge for a in pos_q])
    chosen = dict(zip(qi[sel], si[sel]))
    got = np.array([chosen.get(a, -1) == truth[a] for a in pos_q])
    all_pos = np.flatnonzero((truth >= 0) & in_val[np.maximum(truth, 0)])
    dec_q = vq[truth[vq] < 0]
    fp_dec = np.isin(dec_q, qi[sel]).sum()
    wrong = sel & (y == 0)
    fp_other = int((truth[qi[wrong]] >= 0).sum())
    L += ['', '## Error budget (validation region)', '', '| quantity | count | share |', '|---|---|---|',
          f'| true matches of region S1 (all S2/S3) | {len(all_pos):,} | |',
          f'| ... whose query landed in the region | {len(pos_q):,} | {len(pos_q) / max(len(all_pos), 1):.4f} |',
          f'| ... true S1 among candidates (blocking recall) | {retrieved.sum():,} | {retrieved.mean() if len(pos_q) else 0:.4f} |',
          f'| ... selected correctly | {got.sum():,} | {got.mean() if len(pos_q) else 0:.4f} |',
          f'| missed: not retrieved | {(~retrieved).sum():,} | |',
          f'| missed: retrieved, not selected | {(retrieved & ~got).sum():,} | |',
          f'| decoy queries in region | {len(dec_q):,} | |',
          f'| **decoys accepted (false merges)** | {fp_dec:,} | {fp_dec / max(len(dec_q), 1):.4f} |',
          f'| false merges of another S1\'s record | {fp_other:,} | |', '',
          'Caveats: predictions from queries whose top-1 lies outside the region are not scored (slightly optimistic '
          'on precision), and their true matches count as misses (slightly pessimistic on recall).']
    text = '\n'.join(L) + '\n'
    C.atomic(C.EVAL / 'report.md', lambda t: open(t, 'w', encoding='utf-8').write(text))
    C.log('\n' + text)
    return f_all
