#!/usr/bin/env bash
# v3 on top of the v2 caches. HARD STOP: output/ is final by T0 + ER_DEADLINE_MIN minutes (default 330 = 5 h 30).
#   * output/ holds a valid submission at every moment (v2 until a better variant is assembled)
#   * the v3 process is killed 15 min before the deadline at the latest; `assemble` then writes the best finished
#     variant per country and runs the validator (1-2 min)
set -u
cd "$(dirname "$0")"
export ER_T0=${ER_T0:-$(date +%s)} ER_KEEP_WORK=1
# absolute deadline, e.g.  ER_DEADLINE_AT=10:45 bash run_v3.sh   (files final by 10:45 today)
# (24-hour clock, India time: ER_DEADLINE_AT=22:45 means 10:45 PM IST whatever the machine's timezone)
if [ -n "${ER_DEADLINE_AT:-}" ]; then
  export ER_DEADLINE_MIN=$(( ( $(TZ=Asia/Kolkata date -d "$ER_DEADLINE_AT" +%s) - ER_T0 ) / 60 ))
fi
export ER_DEADLINE_MIN=${ER_DEADLINE_MIN:-330}
if [ "$ER_DEADLINE_MIN" -lt 25 ]; then
  echo "ERROR: only $ER_DEADLINE_MIN min until the deadline (is ER_DEADLINE_AT in 24-hour India time, e.g. 22:45?)."
  echo "output/ still holds a valid submission."; exit 1
fi
echo "v3 clock started at $(date); files final by $(date -d @$(( ER_T0 + ER_DEADLINE_MIN*60 )))"
budget=$(( ER_DEADLINE_MIN*60 - 15*60 - ($(date +%s) - ER_T0) ))
timeout --signal=INT --kill-after=120 ${budget}s python src/run.py v3 \
  || echo "v3 stopped (time budget or error) -> assembling the best finished variant"
python src/run.py assemble
echo "done at $(date). Submission: ../../output/matching_results.tsv  Report: ../../eval/report_v3.md"
