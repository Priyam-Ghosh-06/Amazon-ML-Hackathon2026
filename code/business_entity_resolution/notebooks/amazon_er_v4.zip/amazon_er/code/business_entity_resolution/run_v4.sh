#!/usr/bin/env bash
# v4 on top of a FINISHED v3 run: frozen models, decision layer only (postfix.py), then assemble.
# HARD STOP: output/ is final by T0 + ER_DEADLINE_MIN minutes (default 150).
#   * output/ holds a valid submission at every moment (the v3 file, backed up in output/v3/)
#   * postfix writes choice.json only when it finishes; if it is killed, assemble rewrites the v3 submission
set -u
cd "$(dirname "$0")"
export ER_T0=${ER_T0:-$(date +%s)} ER_KEEP_WORK=1
# absolute deadline, e.g.  ER_DEADLINE_AT=22:45 bash run_v4.sh   (24-hour clock, India time)
if [ -n "${ER_DEADLINE_AT:-}" ]; then
  export ER_DEADLINE_MIN=$(( ( $(TZ=Asia/Kolkata date -d "$ER_DEADLINE_AT" +%s) - ER_T0 ) / 60 ))
fi
export ER_DEADLINE_MIN=${ER_DEADLINE_MIN:-150}
if [ "$ER_DEADLINE_MIN" -lt 20 ]; then
  echo "ERROR: only $ER_DEADLINE_MIN min until the deadline. output/ still holds the v3 submission."; exit 1
fi
OUT=../../output
mkdir -p $OUT/v3
for f in matching_results.tsv candidate_pairs.tsv; do
  [ -f $OUT/v3/$f ] || cp $OUT/$f $OUT/v3/$f
done
echo "v4 clock started at $(date); files final by $(date -d @$(( ER_T0 + ER_DEADLINE_MIN*60 )))"
budget=$(( ER_DEADLINE_MIN*60 - 10*60 - ($(date +%s) - ER_T0) ))
timeout --signal=INT --kill-after=120 ${budget}s python src/run.py postfix \
  || echo "postfix stopped (time budget or error) -> assembling from the v3 choice"
python src/run.py assemble
echo "done at $(date). Submission: $OUT/matching_results.tsv (v3 file kept in $OUT/v3/)"
