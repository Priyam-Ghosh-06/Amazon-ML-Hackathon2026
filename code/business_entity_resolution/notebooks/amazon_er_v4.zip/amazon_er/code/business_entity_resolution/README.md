# Business Entity Resolution: pipelines v2 and v3

- **v2** takes the raw TSVs and produces `candidate_pairs.tsv` and `matching_results.tsv` (sections 1–7 below).
- **v3** runs **on top of a finished v2 run**. It reuses v2's caches and weights, never modifies a v2 file, and finishes under a hard deadline (section 0).

---

## 0. v3: how to run (the timed run)

**Needs:** the folder from the v2 run (`work/`, `weights/`, `output/` as v2 left them), about 45 GB free disk, a GPU, ≥ 60 GB RAM.

```bash
# 1. put the v3 code in place (overwrites code/ only; work/, weights/, output/ are untouched)
cd ~/.amlc && unzip -o amazon_er_v3.zip
cd amazon_er/code/business_entity_resolution && source .venv/bin/activate   # the same env as v2

# 2. BEFORE the clock: check and dry run (not timed)
python src/run.py v3check       # v2 caches, disk, RAM, GPU, validator                        (~10 s)
python src/run.py smoke3        # v2 + v3 on a tiny sample; must end with "smoke3 passed"      (~10-15 min)

# 3. THE TIMED RUN: files are final by start + 5 h 30 at the latest
bash run_v3.sh
```

**Why it cannot overrun:**
- **From the first minute,** `output/matching_results.tsv` is a valid submission: the v2 file, also kept in `output/v2/`.
- **`run_v3.sh` kills the v3 process 15 minutes before the deadline.** Then `assemble` writes the best *finished* variant per country and runs the validator. That takes 1–2 minutes, and falls back to v2 if anything is wrong.
- **Every stage checks the clock before it starts** and is skipped if it would not finish in time.
- To use a shorter deadline, set it explicitly, e.g. `ER_DEADLINE_MIN=300 bash run_v3.sh`.

**What it does and when (estimates for the v2 machine; the log prints real times):**

| min | Phase | Result |
|---|---|---|
| 0–1 | Fallback | v2 submission backed up and kept in `output/` |
| 1–25 | V0 candidate search | Train queries v2 never searched (46% of train S1, US + India), searched with the frozen v2 models |
| 25–65 | **Phase 1** | v2 models scored on held-out buckets and test, then the **v3 decision layer**: per-country calibration, per-country prior-shift correction (test has ~1.7× more decoys per true match than train), per-country rule. **Variant B** is assembled into `output/` if it beats v2 |
| 65–170 | **Phase 2** | v3 features and tables, France label-free tables, GBDT1/GBDT2 refit on hard-negative-weighted rows, cross-encoder on new uncertain edges only. **Variant C**, then the India-as-France check |
| end | Gates + assemble | Per country, the variant with the best held-out F0.5 at test decoy density |

**What to send back:**
- `output/matching_results.tsv` (the file to upload);
- `eval/report_v3.md`;
- `work/run.log`;
- `work/v3/choice.json`.

### 0.1 v4: decision layer on top of a finished v3 run (frozen models, CPU only, ~30–60 min)

v4 retrains nothing and runs no neural model. It reads the v3 state (`work/v3/`: `results.pkl`, `choice.json`,
`p2_v3.pkl` with the v3 model probabilities for the train universe and test) and changes only which edges are selected.
Three changes, each chosen per country on CAL at the test decoy density, and kept only if held-out EVAL improves at test
density without dropping plain EVAL. France gets a change only if both US and India kept it.

1. **Split prior shift.** The EM prior-shift correction runs separately for queries with and without an address. In train,
   97.8% of empty-address queries are true matches, against 71.6% of addressed ones. The decoys, of which test has ~1.7×
   more, all carry addresses, so the one-rate shift wrongly deflated empty-address edges.
2. **Lone-claimant threshold.** An S1 claimed by a single non-negligible edge gets its own threshold. A singleton's false
   merge nearly always comes from one lone decoy.
3. **Singleton filter.** A LightGBM classifier at S1 level (trained on CAL S1s with ≥ 1 predicted match, out-of-fold
   threshold) predicts "this S1 has no true match". Its features are the number of claimants, their sources, their
   probabilities and each claimant's pull to another S1. Every match of an S1 it is sure about is removed: an empty S1
   scores 1.0 if it is a singleton.

```bash
python src/run.py v4check                  # v3 state present; must print "v4 check passed"
python src/run.py smoke4                   # optional, ~20 min: v2 + v3 + v4 on tiny data, must print "smoke4 passed"
ER_DEADLINE_AT=22:45 bash run_v4.sh        # files final by 22:45 India time (default without it: 150 min)
```

- **Fallback.** `run_v4.sh` first copies the v3 submission to `output/v3/`. If `postfix` fails or runs out of time,
  `choice.json` is left as v3 wrote it, and `assemble` writes the v3 submission again.
- **Reruns.** `postfix` can be rerun at any time: it always starts from the v3 choice, saved as `work/v3/choice_v3.json`.
- **Send back:** `work/run.log` (the `[C+]` lines) and `work/v3/choice.json`.

---

## 1. Requirements

| | Minimum | Notes |
|---|---|---|
| OS | Linux | Windows also works; the scripts are plain Python |
| Python | 3.11, 3.12 or 3.13 | |
| GPU | NVIDIA, 16 GB+ VRAM (24 GB+ recommended) | Batch sizes shrink automatically on out-of-memory |
| GPU driver | supports CUDA 12.x | Check with `nvidia-smi` |
| RAM | 32 GB | The pipeline is written to stay under it (memmaps, chunking) |
| Free disk | 50 GB | Peak use is ~20–25 GB. Large train caches are deleted after training |
| CPU | 8+ cores | Feature building and TF-IDF search use all cores |
| Internet | at the first run only | Downloads two MIT-licensed models from Hugging Face (~1.6 GB) |

**Models used.** Both are MIT licensed and far below the 8B-parameter limit:
- `intfloat/multilingual-e5-small` (118M parameters) as the retrieval bi-encoder;
- `intfloat/multilingual-e5-base` (278M parameters) as the cross-encoder;
- LightGBM for everything else.

No external data, APIs or geocoding is used.

---

## 2. Folder layout

Unzip anywhere. The code finds everything relative to its own location.

```
amazon_er/                                    <- the unzipped folder (any path)
├── code/business_entity_resolution/          <- this folder: src/, README.md, requirements.txt, run_all.sh
├── data/student_resource/                    <- PUT THE COMPETITION DATA HERE (same layout as it was given)
│   ├── dataset/train/train_source1.tsv  train_source2.tsv  train_source3.tsv  train_ground_truth.tsv
│   ├── dataset/test/test_source1.tsv    test_source2.tsv   test_source3.tsv
│   └── utils/validate_submission.py
├── work/      <- created: caches and feature matrices (resume points), run.log, timings.json
├── weights/   <- created: bienc/best.pt, ce_a/best.pt, ce_b/best.pt, gbdt*.txt, tables.pkl, decision.pkl, manifest.json
├── eval/      <- created: report.md, val_candidate_pairs.tsv, val_matching_results.tsv
└── output/    <- created: candidate_pairs.tsv, matching_results.tsv   (the submission files)
```

If the data or the cache must live elsewhere, set environment variables before running:
- `ER_DATA=/path/to/dataset` (the folder containing `train/` and `test/`);
- `ER_WORK=/big/disk/work`;
- `ER_WEIGHTS`, `ER_EVAL` and `ER_OUT` likewise.

---

## 3. Setup (once)

```bash
cd amazon_er/code/business_entity_resolution
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

If `torch.cuda.is_available()` is False after installing, the driver is older than the default CUDA 12.8 build. Install the build that matches it:

```bash
pip install torch==2.9.1 --index-url https://download.pytorch.org/whl/cu126
```

---

## 4. Run

```bash
bash run_all.sh
```

It stops at the first failure. Running it again resumes where it stopped. The steps it runs:

| Step | Command | Time | What it does |
|---|---|---|---|
| 1 | `python src/run.py check` | ~1 min | Checks the 7 data files and their columns, the validator, GPU and VRAM, RAM, free disk, write access to every output folder, and the model download. Anything to fix is marked `FAIL` |
| 2 | `python src/run.py smoke` | ~10 min | Runs the **whole** pipeline on a tiny sample in `work/smoke/`. If this passes, the long run will not die on a code error |
| 3 | `python src/run.py train` | ~4.5–5 h | Fits everything. Prints validation macro-F0.5 and writes `eval/report.md` |
| 4 | `python src/run.py test` | ~1.5–2 h | Writes `output/candidate_pairs.tsv` and `output/matching_results.tsv`, then runs the validator (must print `PASS`) |
| opt | `python src/run.py diagnose` | ~5 min | t-SNE of cross-encoder embeddings: true match vs decoy vs another S1's record. Writes `eval/tsne.csv`, and `tsne.png` if matplotlib is installed |

**Follow progress:** `tail -f ../../work/run.log`. Per-stage minutes are recorded in `work/timings.json`.

**What to send back:**
- `output/` (both TSVs);
- `eval/report.md`;
- `work/run.log` and `work/timings.json`;
- `weights/manifest.json`.

---

## 5. Resume, checkpoints and budgets

- **Every stage is cached** in `work/`. After a crash or Ctrl-C, run the same command again and it continues from the last finished stage. To recompute a stage, delete its file in `work/`.
- **Neural checkpoints** (`weights/<model>/`), for the bi-encoder `bienc` and the two cross-encoder fold models `ce_a` / `ce_b`:
  - The model is validated on a fixed validation sample every 100 optimiser steps (bi-encoder) or every 500 (cross-encoder).
  - Nothing is saved during the first 30% of planned steps, while the loss is still falling fast.
  - After that, `best.pt` is **overwritten only when validation loss improves by ≥ 0.5%**. The write goes to a temp file and is then renamed, so a crash can never leave a corrupt `best.pt`.
  - `last.pt` (model + optimiser + step) is written at each validation so an interrupted run resumes mid-training. It is deleted when training finishes.
  - `weights/manifest.json` records the step and validation loss of each saved best model.
- **LightGBM** early-stops on the validation region and saves its best iteration (`weights/gbdt{1,2}_fold{0-3}.txt`).
- **Time caps.** Each neural training loop stops at a wall-clock cap and keeps its best checkpoint: bi-encoder 30 min, each cross-encoder fold 30 min. The caps are in `src/config.py` (`BIENC_MINUTES`, `CE_MINUTES`).
- **Disk.** Features are stored as float16 memmaps and embeddings are never kept for queries. When `train` finishes it deletes its large caches (~10–20 GB); set `ER_KEEP_WORK=1` to keep them.
- **RAM.** Records are loaded once, feature workers receive explicit chunks, and GBDTs fit on ≤ 3M sampled rows. Set `ER_PROCS=8` to use fewer worker processes if RAM is tight.

---

## 6. Pipeline (what the code does)

| # | Stage | File | Method |
|---|---|---|---|
| A | Normalise | `text.py` | Lower-case; strip accents on Latin letters only (Indic matras survive); keep letters, marks and digits. Collapse dotted acronyms (`L.L.C.` → `llc`), drop `NULL` address pieces, fold zero-padding (`007168` → `7168`), strip web domains, fix OCR digits inside words (`Ta1ent`). Split addresses into comma components. Numbers keep their suffix (`593a`, `42rd`). |
| A | Tables learned from train only | `text.py` | Indic → Latin word dictionary (Dice alignment). State vocabulary from S1 (label-free, so France works). Query-side state spellings (`MH`, `Pennsylvania`, `महाराष्ट्र`). States that true pairs swap (Telangana ↔ Andhra Pradesh) are merged. Place-name aliases. |
| B | Candidates | `blocking.py`, `bienc.py` | Search the **full** S1 index inside (country, state) buckets. A country is bucketed only if confident matches agree on state ≥ 99%, a label-free check that also runs for France. Two channels: **char 3-gram TF-IDF** (name without spaces + address) and a **fine-tuned multilingual bi-encoder** (in-batch-negative InfoNCE with large batches, same-region batches, mined hard negatives and false-negative masking; exact GPU search). The union of both top-6 lists is `candidate_pairs.tsv`. |
| C | Pair features (65) | `features.py` | RapidFuzz name/address similarities; token log-likelihood tables learned against **decoys** (not arbitrary wrong candidates). Signed house-number shift and whether it is a known decoy shift. Ordinal and letter-suffix mismatches, legal-form conflicts, edits at word edges. Per-level address comparison (state relation, place conflict vs one side missing, street tokens, landmarks). Co-located S1 count, name-sharing count, both channels' scores and ranks. |
| D | GBDT stage 1 | `gbdt.py` | LightGBM, 4 folds grouped by the query's top-1 S1. The validation region and test use the mean of the fold models. |
| D | Cross-encoder | `crossenc.py` | multilingual-e5-base reads query + S1 together, with one token per digit. It scores only each query's top-2 edges inside the uncertain band 0.02 < p₁ < 0.98. Two fold models give out-of-fold scores. |
| E | Sibling features | `features.py` | One synchronous, leave-one-out round over each (S1, source) star. Checks whether a confident same-source sibling repeats the record's extra numbers or address tokens (e.g. landmarks), or contradicts them. Also the best address similarity to a sibling and the competing S1's p. The result does not depend on row order. |
| F | GBDT stage 2 + decision | `gbdt.py`, `decide.py` | Stage-1 features + p₁ + cross-encoder logit + sibling features, isotonic calibration. Each record goes to its best S1. Per S1, the set with the exact expected F0.5 is chosen (the empty set is allowed, so singletons score 1). This rule is compared with fixed thresholds on the validation region, and the better one is kept. |

**Training data design.** Candidate search always runs against the **full** index, so every decoy meets its parent S1 exactly as on test. Models are fitted on whole (country, state) regions: 40% of S1 for training and 12% for validation. A region keeps every S1's matched records and every decoy's parent together, and keeps the 5-hour budget.

Module self-checks: `python src/<module>.py` for `text`, `blocking`, `features`, `decide`, `gbdt`, `nnutil` and `bienc`.

---

## 7. Troubleshooting

| Symptom | Fix |
|---|---|
| `check` FAIL on a data file | The data is not at `data/student_resource/dataset/...`. Move it there or set `ER_DATA` |
| `check` FAIL on a model | No internet on the first run. Run once with internet, or copy `~/.cache/huggingface` from another machine (`HF_HOME` sets its location) |
| `CUDA out of memory` in the log | Handled automatically (the batch halves). If it repeats, lower `BIENC_BATCH` / `CE_BATCH` in `src/config.py` |
| Killed by the OS (RAM) | Run `ER_PROCS=6 python src/run.py train`. It resumes from the cache |
| Training slower than expected | `work/timings.json` shows which stage. The neural stages are capped, so reduce `BIENC_MINUTES` / `CE_MINUTES` if needed |
| Validator FAIL | Send `work/run.log`. The outputs are written atomically, so a partial file is never left behind |
