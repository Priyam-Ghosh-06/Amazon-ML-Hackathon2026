#!/usr/bin/env bash
# check -> smoke -> train -> test. Stops at the first failure; rerunning resumes from the cached stages.
set -euo pipefail
cd "$(dirname "$0")"
python src/run.py check
python src/run.py smoke
python src/run.py train
python src/run.py test
