# amazon_er v4: run on top of the finished v3 folder (frozen models, deadline-safe)

v4 retrains nothing and runs no neural model. It re-decides which matches to keep, using the v3 model probabilities
already in work/v3/. The work is CPU-only: LightGBM plus numpy. It needs RAM like the v3 run (the 150-200 GB box is plenty).

1. Unzip OVER the existing folder. This replaces code/ and Documentation_template.md only; work/, weights/,
   output/ and data/ are untouched:
       cd ~/.amlc && unzip -o amazon_er_v4.zip
2. Checks:
       cd amazon_er/code/business_entity_resolution && source .venv/bin/activate
       python src/run.py v4check     # must print "v4 check passed" (~1 min)
       python src/run.py smoke4      # optional, ~20 min on tiny data; must print "smoke4 passed"
3. The timed run. Give the ABSOLUTE time the files must be final (24-hour, India time):
       ER_DEADLINE_AT=22:45 bash run_v4.sh
   Time: ~10 min to load the v3 state, plus ~1.5-2x the "v3: phase 2 decision layer" stage time in the v3
   work/run.log (usually 30-60 min in total). It first copies the v3 submission to output/v3/. If anything fails or time runs out,
   output/ gets the v3 submission back, validated.
4. Upload output/matching_results.tsv. Send back:
   - work/run.log   (the "[C+]" lines show what was kept and the held-out scores)
   - work/v3/choice.json

If nothing passes its held-out gate, output/matching_results.tsv is identical to the v3 file. In that case, don't
spend a leaderboard submission on it.
